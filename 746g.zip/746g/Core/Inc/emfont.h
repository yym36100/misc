#pragma once 
#include <stdint.h>

typedef struct glyphmetrics{
	uint8_t w, h;
	int8_t ax, bx, by;
	uint16_t of;
}glyphmetrics;

typedef struct emfnthead{
	uint8_t ver;
	uint8_t size;
	uint8_t start, stop;

	uint8_t bpp, bpc;

	uint8_t encoding;
	int8_t  wo, ho, axo, bxo, byo, go;
	uint8_t wl, hl, axl, bxl, byl, ol;
	uint8_t gv;

	const uint8_t *ctrl;
	const uint8_t *data;
	uint8_t (*pgetmetrics)(glyphmetrics, uint8_t);
}emfnthead;
