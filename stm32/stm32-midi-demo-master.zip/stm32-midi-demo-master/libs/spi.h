#ifndef SPI_H_
#define SPI_H_

void init_spi (void);
void spi_send( uint8_t out );

#endif 
