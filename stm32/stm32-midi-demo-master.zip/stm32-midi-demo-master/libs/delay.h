#ifndef _DELAY_H
#define _DELAY_H

#include "main.h"

void DELAY_Init(void);
void DELAY_Wait_uS(uint16_t uS);

#endif
