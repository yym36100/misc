# stm32-midi-demo

use stm32f4 as (client) usb midi device 
