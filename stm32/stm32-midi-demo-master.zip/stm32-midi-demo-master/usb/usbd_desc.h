// $Id: usbd_desc.h 1800 2013-06-02 22:09:03Z tk $

// Dummy file which only exists, since it's referenced in the STM32 device library (usbd_req.c)

#ifndef __USB_DESC_H
#define __USB_DESC_H

#endif /* __USB_DESC_H */
