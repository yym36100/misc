// w25q64jv
// 64Mbit serial flash

/*

 - 32.768 pages of 256 byte (=8MB)
 - up to 256 bytes can be programmed at a time

 + ERASE

 - in groups of 16  (4KB sector erase)
 - in groups of 128 (32KB block erase)
 - in groups of 256 (64KB block erase)
 - chip erase

 - 2048 sectors (of 4KB)
 - 128 blocks   (of 64KB)
 - 1 block = 16 sector

 - standard/dual/quad SPI
 - 133 MHz max
 - 100K program-erase cycles (20 year retention)

 - 48 instructions 34 + 8 (single + dual/quad)

 */
#include "main.h"
#include "stm32f4xx_hal.h"

extern SPI_HandleTypeDef hspi1;

// read device id
uint32_t w25_ReadId(void){
// 90h + 24 bit 0
	uint8_t cmd[6] = {0x90,0,0,0,0,0,0};
	uint8_t rx[6];
	HAL_GPIO_WritePin(SPI1_SS_GPIO_Port, SPI1_SS_Pin, 0);
	HAL_SPI_TransmitReceive(&hspi1, cmd, rx, 6, 10);
	HAL_GPIO_WritePin(SPI1_SS_GPIO_Port, SPI1_SS_Pin, 1);
	return (rx[4]<<8) + rx[5];
}

void w25_ReadUniqueId(void){
// 90h + 24 bit 0
	uint8_t cmd[5+8] = {0x4b,0,0,0,0,  0,0,0,0,0,0,0,0};
	uint8_t rx[5+8];
	HAL_GPIO_WritePin(SPI1_SS_GPIO_Port, SPI1_SS_Pin, 0);
	HAL_SPI_TransmitReceive(&hspi1, cmd, rx, 13, 10);
	HAL_GPIO_WritePin(SPI1_SS_GPIO_Port, SPI1_SS_Pin, 1);
	printf("%02x%02x%02x%02x%02x%02x%02x%02x\n",rx[5],rx[6],rx[7],rx[8],rx[9],rx[10],rx[11],rx[12]);
}

void w25_ReadJEDECId(void){
// 90h + 24 bit 0
	uint8_t cmd[4] = {0x9f,0,0,0,0,  0,0,0,0,0,0,0,0};
	uint8_t rx[4];
	HAL_GPIO_WritePin(SPI1_SS_GPIO_Port, SPI1_SS_Pin, 0);
	HAL_SPI_TransmitReceive(&hspi1, cmd, rx, 4, 10);
	HAL_GPIO_WritePin(SPI1_SS_GPIO_Port, SPI1_SS_Pin, 1);
	printf("%02x%02x%02x\n",rx[1],rx[2],rx[3]);
}

void w25_ReadData(uint32_t addr, uint32_t count){
// 90h + 24 bit 0
	uint8_t cmd[4] = {0x03,addr>>16,addr>>8,0};
	uint8_t rx[1];
	HAL_GPIO_WritePin(SPI1_SS_GPIO_Port, SPI1_SS_Pin, 0);
	HAL_SPI_TransmitReceive(&hspi1, cmd, rx, 4, 10);
	printf("Addr %03x : ", addr);
	for(int i=0;i<count;i++){
		HAL_SPI_TransmitReceive(&hspi1, cmd, rx, 1, 10);
		printf("%02x ",rx[0]);
	}
	HAL_GPIO_WritePin(SPI1_SS_GPIO_Port, SPI1_SS_Pin, 1);
	printf("\n");
}


