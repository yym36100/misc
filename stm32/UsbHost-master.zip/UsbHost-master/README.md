Just another STM32F105 DevKit for MIDI usage.

Zhiyuan Wan August 2015
