stm32f4-synth
=============

### Features ###

+ MIDI
+ AUDIO
