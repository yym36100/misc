// bin2hex.cpp : Defines the entry point for the console application.
//

#include "stdio.h"
#include "string.h"


int main(int argc, char* argv[])
{
	if(argc!=3)
	{
		printf("usage bin2hex.exe binfile startaddresshex\n");
		return 0;
	}
	FILE *f;
	unsigned char bigbuffer[10*1024];
	if((f = fopen(argv[1],"rb"))==NULL) return 1;
	int rb = fread(bigbuffer,1,10*1024,f);
	fclose(f);
	unsigned int startaddr ; sscanf(argv[2],"%x",&startaddr);
	char newname[1024];
	strcpy(newname,argv[1]);
	strcat(newname,".hex");
	f = fopen(newname,"wt");

	int wb;
	char *p = (char*)bigbuffer;
	rb-=4;
	while(rb>0)
	{
		int cs=0;
		if(rb>16)
			wb = 16;		
		else
			wb = rb;
		fprintf(f,":%02X%04X%02X",wb,startaddr,0);
		rb-=wb;
		cs += wb + (startaddr&0xff) + (startaddr>>8);
		startaddr+=wb;
		while(wb-->0)
		{
			fprintf(f,"%02X",(unsigned char)*p);
			cs+=*p++;
		}
		fprintf(f,"%02X\n",(unsigned char)(cs^0xff)+1);
	}
	fprintf(f,":00000001FF");
}

