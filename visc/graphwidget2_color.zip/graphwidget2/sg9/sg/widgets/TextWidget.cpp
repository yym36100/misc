#pragma once
#include "TextWidget.h"

namespace sg{
	namespace wg{


	};// wg
};// sg
