#pragma once
#include "TWidget.h"
#include "TStaticText.h"

struct TButton : public TWidget {
	char *text;
	u8 attr;
	u8 cmd;
	u8 state;

	TButton(u8 x, u8 y, char *_text, u8 _cmd = 0, u8 flgs = focusable, u8 _attr = 0x7) : 
	TWidget(x, y, flgs), text(_text), attr(_attr),cmd(_cmd),state(0) {}

	void UpdateData() { if (g_always_redraw()) s_redraw(1); }

	virtual u8 GetWidth() const { return strlen(text)+2; }
	//virtual u8 GetHeight()const { return 1; }

	void HandleEvent(TEvent &e) {
		TWidget::HandleEvent(e);
		if(!elock.locked()){
			if (e.what == TEvent::emouse && e.mouse.buttons !=0 && contains(e.mouse.x,e.mouse.y) ) {
				state= 1;
				s_redraw(1);				
				elock.lock(this,lx,ly);
			}
		} else {
			//locked
			if(elock.owner==this){
				s_redraw(1);	
				if(e.what == TEvent::emouse){
					if(e.mouse.buttons !=0) {
						// button still pressed
						if(contains(e.mouse.x,e.mouse.y)){
							state = 1;
						}else{
							state = 0;
						}

					} else {
						// button released
						elock.unlock();
						state = 0;
						if(contains(e.mouse.x,e.mouse.y)){
							// event;
							e.makeUpward(this,cmd);
						}
					}
				}
			}
		}
	}

	void Draw() {
		u8 l = strlen(text);
		l+=2;
		if(state==0){
			//normal
			con->SetCurosrPos(lx + s.x, ly + s.y); //todo add this offset inside the func
			u8 c= attr;
			if(g_focused())				
			c = (0xcf);
			


			ctext::Draw(c,0x3a,text);
			con->WriteAlign(ctext::ttext,ctext::tattr,l,c);

			char shadow[20];
			u8 i;
			for(i=0;i<l;i++){
				shadow[i]=0xdf;
			}
			shadow[i]=0;
			con->SetCurosrPos(lx + s.x+1, ly + s.y+1); //todo add this offset inside the func
			con->SetColor(0x80);
			con->Write(shadow);

			con->SetCurosrPos(lx + s.x+l, ly + s.y); //todo add this offset inside the func
			con->Write("\xdc");
		}
		else
		{
			//pressed
			con->SetCurosrPos(lx + s.x, ly + s.y); //todo add this offset inside the func

			con->SetColor(0x80);
			con->Write(" ");
			con->SetCurosrPos(lx + s.x+1, ly + s.y); //todo add this offset inside the func
			//con->SetColor(attr);
			//con->WriteAlign(text,l);

			ctext::Draw(attr,0x3a,text);
			con->WriteAlign(ctext::ttext,ctext::tattr,l,attr);

			char shadow[20];
			u8 i;
			for(i=0;i<l;i++){
				shadow[i]=' ';
			}
			shadow[i]=0;
			con->SetCurosrPos(lx + s.x+1, ly + s.y+1); //todo add this offset inside the func
			con->SetColor(0x80);
			con->Write(shadow);
		}
	}
};
