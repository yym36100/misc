#pragma once
#include "TSymbol.h"

struct TList : public TSymbol {
	//    u8 h;

	TList(u8 x, u8 y, u8 _w, u8 _h, u8 *_idx, TObject &ee, char _hotkey = 0) : TSymbol(x, y, _idx, ee, _hotkey) {
		w = _w;
		//h = _h;
	}

	void HandleEvent(TEvent &e) {
		if(e.type == TEvent::direct){
			*idx = e.msg.data2;
			e.Consume();
			return;
		}
		if(e.what == TEvent::ekey) TSymbol::HandleEvent(e);
		if (e.what == TEvent::emouse && (e.mouse.event >= 0x40 || e.mouse.buttons!=0) ){
			TPoint mp(e.mouse.x, e.mouse.y);
			makeLocal(mp);

			if (mp.x < w && mp.y < noItems()){
				if(g_focused() == 1){
					if(e.mouse.buttons == 1) {*idx = mp.y;e.Consume(); return;}
					if(e.mouse.event==0x80){(*idx)++; if (*idx >= noItems())*idx = 0; /*Draw();*/e.Consume();}
					if(e.mouse.event==0x40){(*idx)--; if (*idx >= noItems())*idx = noItems() - 1; /*Draw();*/e.Consume(); return;}

				} else {
					//if(e.mouse.buttons == 1) {*idx = mp.y;} //not sure why this doesn't work, investigate it later
					if(e.mouse.buttons == 1) {
						//try to get focus						
						e.makeUpward(this,TMsgEvent::getfocus);

						// also set pend msg to change value
						// can not change the value directly here because list value is used in visibilty controller, 
						// changing it will change the tree, upward message can not propagate back to root
						pend.makeDirect(this,mp.y);
						return ;
					}
				}
			}
		}
	}

	void Draw() {
		u8 i;
		for (i = 0; i < noItems(); i++){
			con->SetCurosrPos(lx + s.x, ly + s.y + i);
			con->SetColor(i != *idx ? 0x17 : g_focused() ? 0x2e : 0x4e);
			con->WriteAlign(((TSymElem*)first->GetAt(i))->text, w, TConsole::right);
		}
	}

	u8 GetWidth() const { return w; }
	u8 GetHeight() const { return noItems(); }
};
