#pragma once
#include <stdlib.h>
#include "TWidget.h"

#define pattern2 "\xb0\xb1\xb2\xb1"
#define pattern ".   ,    .   ,.   "

struct TBackground : public TWidget {
	char *pat;
	u8 attr;

	TPoint size;
	TBackground(u8 x, u8 y, u8 w, u8 h, char *_pat = pattern2, u8 _attr = 0x02) : TWidget(x, y), pat(_pat), attr(_attr), size(w, h) {}

	void Draw(){
		u16 w = size.x;
		u16 h = size.y;
		u16 xs = lx + s.x, ys = ly + s.y;
		char linebuff[81];

		//con->SetColor(random());
		con->SetColor(attr);

		char *pp = pat;
		int pl = strlen(pat);
		int pi = 0;

		for (int i = 0; i < h; i++){
			for (int j = 0; j < w; j++){
				linebuff[j] = pp[pi++];
				if (pi == pl) pi = 0;
			}
			linebuff[w] = 0;
			con->SetCurosrPos(xs, ys + i);
			con->Write(linebuff);
		}
	}

	u8 GetWidth() const { return size.x; }
	u8 GetHeight()const { return size.y; }
};

struct TMatrixBackground : public TWidget {

	TPoint size;
	char *d;
	TMatrixBackground(u8 x, u8 y, u8 w, u8 h) :
	TWidget(x, y), size(w, h) {
		d = new char[w*h*2];
		memset(d,0,w*h*2);
	}	

	void Draw(){
		u16 w = size.x;
		u16 h = size.y;
		u16 xs = lx + s.x, ys = ly + s.y;
		char linebuff[81];
		char linebuffa[81];


		dx_move_matrix_in(d,random(size.x/2)*2);	
		dx_move_matrix_in(d,random(size.x/4)*4);	
		dx_move_matrix_in(d,random(size.x/8)*8);	
		

		//con->SetColor(random());

		for (int i = 0; i < h; i++){
			for (int j = 0; j < w; j++){
				linebuff[j] = d[2*(i*size.x+j)]+1;
				linebuffa[j] = d[2*(i*size.x+j)+1];				
				//linebuff[j] = '1';
				//linebuffa[j] = 0x1f;				
			}
			linebuff[w] = 0;
			con->SetCurosrPos(xs, ys + i);
			con->Write(linebuff,linebuffa);
		}
	}

	int random(int a){ return rand()%a;}

	void dx_move_matrix_in(char *V,char i) {
		i8 j,kk;
		kk=random(2);
		V[2*(0*size.x+i)]=  random(128);
		V[2*(0*size.x+i)+1]=2+8*random(2);

		for(j=size.y-2;j>=0;j--) {
			V[2*((j+1)*size.x+i)]=V[2*(j*size.x+i)];
			V[2*((j+1)*size.x+i)+1]=V[2*(j*size.x+i)+1];

		}

		V[2*(0*size.x+i)]= '0' + random(9);
		V[2*(0*size.x+i)+1]=2+8*random(2);
	}


	u8 GetWidth() const { return size.x; }
	u8 GetHeight()const { return size.y; }
};