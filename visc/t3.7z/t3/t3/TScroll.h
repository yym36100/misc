#pragma once
#include "TWidget.h"
#include "TValue.h"

#define sb_simple "<-*->"
#define sb_simple1 "\x11\xc4\xf0\xc4\x10"
#define sb_simple2 "\x11\xcd\xf0\xcd\x10"

#define sb_classic1 "\x11\xb0\xfe\xb0\x10"
#define sb_classic1f "\x11\xdb\xdb\xb0\x10"
#define sb_classic2 "\x11\xb1\xfe\xb1\x10"
#define sb_classic3 "\x11\xb2\xfe\xb2\x10"
#define sb_arrowy   "\x1b\xc4\x7f\xc4\x1a"

struct TScroll : public TWidget {

	static const char *art_set[];
	u8 arti;
	//char* art;
	u8 *val;
	u8 copy;	
	u8 w;

	TScroll(u8 x, u8 y, u8 *pdata, char _hotkey = 0, char ai = 3) :TWidget(x, y, focusable), val(pdata), arti(ai) {
		w = 30; //todo
	}

	void UpdateData() { if (copy != *val){ s_redraw(1); copy = *val; } }

	void HandleEvent(TEvent &e) {
		TWidget::HandleEvent(e);

		//check folloging cases
		// "<" "-x" "x" "x-" ">"
		if(elock.locked()){
			if(elock.owner==this){
				s_redraw(1);	
				if(e.what == TEvent::emouse){
					if(e.mouse.buttons !=0) {
						//drag cursor
						TPoint mp(e.mouse.x, e.mouse.y);
						makeLocal(mp);

						if(mp.x <0 ) mp.x =0;
						if(mp.x >28) mp.x = 28;

						(*val) = 100*mp.x/28;e.Consume();s_redraw(1);


					} else {						
						// button released
						elock.unlock();
					}
				}
			}
		}else{
			if(e.isMouse()){			
				if(contains(e.mouse.x,e.mouse.y)){
					TPoint mp(e.mouse.x, e.mouse.y);
					makeLocal(mp);
					if(e.mouse.buttons!=0){
						if(mp.x == 0) {(*val)--;e.Consume();s_redraw(1);}
						if(mp.x>0 && mp.x < GetPointerPos()) {(*val)-=10;e.Consume(); s_redraw(1);}
						if(mp.x ==  GetPointerPos()) {elock.lock(this,lx,ly);}
						if(mp.x>GetPointerPos() && mp.x < 29) {(*val)+=10;e.Consume(); s_redraw(1);}
						if(mp.x == 29) {(*val)++;e.Consume();s_redraw(1);}
					}
				}
			}
		}
	}

	u8 GetPointerPos(){
		u32 val2 = *val % 101;
		u16 i = 1+28 * val2 / 100;
		if (i > 28) i = 28;
		return i;
	}
	void Draw() {
		TWidget::Draw();
		if (g_focused())con->SetColor(0x02);
		else con->SetColor(0x12);

		u8 i=GetPointerPos();

		char text[81];
		const char *art = art_set[arti];

		text[0] = art[0];
		for (int ii = 1; ii < i; ii++) text[ii] = art[1];
		text[i] = art[2];
		for (int ii = i + 1; ii < w-1; ii++) text[ii] = art[3];
		text[w - 1] = art[4];
		text[w] = 0;

		con->Write(text);
	}
	u8 GetWidth() const { return w; }
};
