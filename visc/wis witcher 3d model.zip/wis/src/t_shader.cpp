#include <windows.h>
#define GLEW_STATIC
#include "../include/gl/glew.h"
#include <GL/gl.h>

#include "t_shader.h"

int t_shader::fgetsize(FILE *f){
	int sz;
	fseek(f, 0L, SEEK_END);
	sz = ftell(f);
	fseek(f, 0L, SEEK_SET);
	return sz;
}

char* t_shader::GetFile(char *file){
	FILE* f = fopen(file, "r");
	int sz = fgetsize(f);
	char *pText = (char*)malloc(sz+1);
	fread(pText,sz,1,f);
	pText[sz] = 0;
	return pText;
}

bool t_shader::CompileShader(GLuint shader, const char* shaderSource){
	glShaderSource(shader, 1, &shaderSource, NULL);
	glCompileShader(shader);
	GLint status;
	glGetShaderiv(shader, GL_COMPILE_STATUS, &status);

	if (status == 0)
	{
		printf("Failed to create a shader.\n");
		GLint length;
		glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &length);
		if (length > 0) 
		{
			char* log = (char*)malloc(length);
			glGetShaderInfoLog(shader, length, NULL, log);
			printf("%s\n", log);
			free(log);
		}
		return false;
	}
	return true;
}

void t_shader::Load(char *vsfn, char *psfn){	
	char *vs_source = GetFile(vsfn);
	char *fs_source = GetFile(psfn);

	GLuint vs = glCreateShader(GL_VERTEX_SHADER);
	GLuint fs = glCreateShader(GL_FRAGMENT_SHADER);

	CompileShader(vs, vs_source);
	CompileShader(fs, fs_source);

	GLuint po = glCreateProgram();
	glAttachShader(po, vs);
	glAttachShader(po, fs);
	glLinkProgram(po);
	GLint status;
	glGetProgramiv(po, GL_LINK_STATUS, &status);
	if (status == 0) 
	{
		printf("Failed to link shader program.\n");

		GLint length;
		glGetProgramiv(po, GL_INFO_LOG_LENGTH, &length);
		if (length > 0) 
		{
			char* log = (char *)malloc(length);
			glGetProgramInfoLog(po, length, NULL, log);
			printf("%s\n", log);
			free(log);
		}

		return;
	}
	prog = po;
}
