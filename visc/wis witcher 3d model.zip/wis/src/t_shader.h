#pragma once
#include <windows.h>
#include <gl/gl.h>
#include <stdio.h>

class t_shader {
public:
	GLint prog;

	GLint vert;    
	GLint light;
	GLint normal;
	GLint texcoord;    

	void Load(char *vsfn, char *psfn);

private:
	int fgetsize(FILE *f);
	char *GetFile(char *file);
	bool CompileShader(GLuint shader, const char* shaderSource);
};