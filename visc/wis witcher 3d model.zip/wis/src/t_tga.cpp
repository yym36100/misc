#include "t_tga.h"

int t_tga::fgetsize(FILE *f){
	int sz;
	fseek(f, 0L, SEEK_END);
	sz = ftell(f);
	fseek(f, 0L, SEEK_SET);
	return sz;
}

void t_tga::Load(std::string fname){

	FILE *f;
	int s;

	f=fopen(fname.c_str(),"rb");
	s = fgetsize(f);

	char *data = new char[s];
	fread(data,1,s,f);
	fclose(f);

	memcpy(&head,data,sizeof(head));

	char *d = data + sizeof(head);

	char r,g,b,a;
	char *newmem = new char[head.width*head.height*4];

	for(int y=0;y<head.height;y++){
		for(int x=0;x<head.width;x++){
			r = *d++;
			g = *d++;
			b = *d++;
			a = *d++;

			newmem[((head.height-1-y)*head.width+x)*4+0] = b*1.0;
			newmem[((head.height-1-y)*head.width+x)*4+1] = g*1.0;
			newmem[((head.height-1-y)*head.width+x)*4+2] = r*1.0;
			newmem[((head.height-1-y)*head.width+x)*4+3] = a;

		}
	}
	pData = newmem;
}



