#pragma once

#include <string>
#include <vector>

#include "t_tga.h"

#include <windows.h>
#include <gl\gl.h>
#pragma comment (lib,"opengl32.lib")

class t_matlib {
public:
	std::string matlib_filename;
	std::vector<std::string> mat_name;
	std::vector<std::string> file_name;
	std::vector<t_tga*> tgas;
	std::vector<GLuint> tex_id;

	void load(std::string fname);
	void load_images();
	void load_textures();

	int get_texid(std::string name);

	t_matlib(void){}
	~t_matlib(void){}

private:
	std::string get_path();
	std::string make_full_fname(std::string path, std::string tga_name);
};

namespace c6{
}