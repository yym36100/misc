#pragma once
#include <string>

typedef unsigned char u8;
typedef unsigned short u16;

struct tga_header{
	u8 id, comaty,imty;
	u8 cms[5];
	u16 xorig,yorig;
	u16 width, height;
	u8 pide;
	u8 imde;
};

class t_tga
{
public:
	tga_header head;
	char *pData;

	void Load(std::string fname);
	t_tga(void){}
	~t_tga(void){}

private: 
	int fgetsize(FILE *f);
};
