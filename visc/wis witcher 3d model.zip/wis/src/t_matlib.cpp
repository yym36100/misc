#include "t_matlib.h"


void t_matlib::load(std::string fname){
	FILE *f;
	char buff[255];
	char tmp[255];
	strcpy(tmp, fname.c_str());
	f = fopen(fname.c_str(),"rt");
	if (!f) return;
	matlib_filename = fname;

	while(!feof(f)){
		buff[0] = 0;
		fgets(buff,255,f);
		switch(buff[0]){
			case 'n': //newmtl
				{
					std::string s = buff;
					size_t r = s.find("newmtl",0);
					if(r>=0){
						sscanf(buff+r+7,"%s",tmp);
						s = tmp;
						mat_name.push_back(s);
					}
				}break;
			case 'm': //map_kd
				{
					std::string s = buff;
					size_t r = s.find("map_Kd",0);
					if(r>=0){
						sscanf(buff+r+7,"%s",tmp);
						s = tmp;
						file_name.push_back(s);
					}
				}break;
		}
	}
}

std::string t_matlib::get_path(){
	std::string res;
	int p;
	static char tmp[255];
	p = matlib_filename.find_last_of('/');
	matlib_filename.copy(tmp,p);
	tmp[p] = 0;
	return tmp;
}

std::string t_matlib::make_full_fname(std::string path, std::string tga_name){
	std::string res;
	res = path + '/' + tga_name;
	return res;
}

void t_matlib::load_images(){
	std::string path;	
	path = get_path();
	t_tga *tga;

	for(int i=0;i<file_name.size();i++){		
		printf("%s\n",make_full_fname(path,file_name[i]).c_str());
		tga = new t_tga;
		tga->Load(make_full_fname(path,file_name[i]));		
		tgas.push_back(tga);
	}

	for(int i=0;i<tgas.size();i++){		
		printf("%dx%d\n",tgas[i]->head.width,tgas[i]->head.height);

	}
}

void t_matlib::load_textures(){

	GLuint *ids = new GLuint[tgas.size()];
	glGenTextures(tgas.size(), ids);
	for(int i=0;i<tgas.size();i++){
		tex_id.push_back(ids[i]);
		glBindTexture(GL_TEXTURE_2D, ids[i]);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tgas[i]->head.width, tgas[i]->head.height, 0,
			GL_RGBA, GL_UNSIGNED_BYTE, tgas[i]->pData);

		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, (GLfloat)GL_LINEAR);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, (GLfloat)GL_LINEAR);
	}
}

int t_matlib::get_texid(std::string name){	
	for(int i = 0;i<mat_name.size();i++){
		if(!name.compare(mat_name[i])){
			return tex_id[i];
		}
	}
	return -1;
}
