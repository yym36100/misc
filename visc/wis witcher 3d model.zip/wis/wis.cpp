#include <windows.h>
#define GLEW_STATIC
#include "./include/gl/glew.h"
#include <GL/gl.h>

#include <stdio.h>
#include <math.h>

#include "t_matlib.h"
#include "t_shader.h"

#include "wis.h"
//#include "one.h"

#define www 1000
#define hhh 800

#pragma comment (lib,"opengl32.lib")
#pragma comment (lib,"glew32s.lib")

struct t_modeldata{
	int texid;
	int no_triangles;
	GLfloat *vertices;
	GLfloat *normals;
	GLfloat *texmaps;
	char *mat_name;
};

struct t_objinfo{
	int no_objects;
	t_modeldata *pmodeldata;
	char *matlib;
};

#include "witcher.h"
t_objinfo *pobj  = &objinfo;


// Global Variables:
HINSTANCE hInst;								// current instance
HWND hWnd;

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

VOID EnableOpenGL( HWND hWnd, HDC * hDC, HGLRC * hRC )
{
	PIXELFORMATDESCRIPTOR pfd;
	int iFormat;

	// get the device context (DC)
	*hDC = GetDC( hWnd );

	// set the pixel format for the DC
	ZeroMemory( &pfd, sizeof( pfd ) );
	pfd.nSize = sizeof( pfd );
	pfd.nVersion = 1;
	pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER ;
	pfd.iPixelType = PFD_TYPE_RGBA;
	pfd.cColorBits = 24;
	pfd.cDepthBits = 16;
	pfd.iLayerType = PFD_MAIN_PLANE;
	iFormat = ChoosePixelFormat( *hDC, &pfd );
	SetPixelFormat( *hDC, iFormat, &pfd );
	// create and enable the render context (RC)
	*hRC = wglCreateContext( *hDC );
	wglMakeCurrent( *hDC, *hRC );
	GLenum err = glewInit();
	printf("%d",err);
}

int APIENTRY WinMain(HINSTANCE hInstance,
					 HINSTANCE hPrevInstance,
					 LPTSTR    lpCmdLine,
					 int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	// TODO: Place code here.
	MSG msg;
	HDC hDC;
	HGLRC hRC;  

	// Initialize global strings	
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	EnableOpenGL( hWnd, &hDC, &hRC );
	glClearColor(0.15f, 0.25f, 0.35f, 1.0f);
	glViewport(0, 0, www,hhh);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	float nearp = 1.0f;
	float farp = 500.0f;
	float hht = nearp * (float)tan(45 / 2.0 / 180.0 * 3.141592);
	float hwd = hht * (float)www / (float)hhh;

	glFrustum(-hwd, hwd, -hht, hht, nearp, farp);
	glMatrixMode(GL_MODELVIEW);


	glEnable(GL_DEPTH_TEST);  
	glFrontFace(GL_CCW); 
	glEnable(GL_CULL_FACE);  
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);


	t_matlib matlib;
	matlib.load(pobj->matlib);
	matlib.load_images();
	matlib.load_textures();

	t_shader myshader;
	myshader.Load("shader/flat_vs.c","shader/flat_fs.c");
	char binprog[1500];
	GLsizei length = 1500;
	GLenum format = 0;
	int res;

	//glUseProgram(myshader.prog);
	//glGetProgramBinary(myshader.prog,1500,&length,&format,&binprog);

	int u=10;
	glGetIntegerv(0x8E21, &u);
	//glGetProgramiv(myshader.prog, GL_PROGRAM_BINARY_LENGTH, &amp;binaryLength);


	float theta = 0;
	bool bQuit = 0;

	// Main message loop:
	while (!bQuit)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) 
		{
			// handle or dispatch messages
			if (msg.message == WM_QUIT) 
			{
				bQuit = TRUE;
			} 
			else 
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
		else
		{

			glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  
			//glUseProgram(myshader.prog);

			glLoadIdentity();
			glScalef(2,2,1);
			glTranslatef(-0.5,-0.5,-1);

			glEnableClientState( GL_VERTEX_ARRAY );
			glEnableClientState( GL_NORMAL_ARRAY );
			glEnableClientState(GL_TEXTURE_COORD_ARRAY);

			glLoadIdentity();
			glScalef(2,2,1);
			glTranslatef(0,0,-5);
			glRotatef(theta,0,1,0);
			theta +=0.5;


			for(int i=0;i<pobj->no_objects;i++){
				// set texture
				if(pobj->pmodeldata[i].texid==-1){
					int id = matlib.get_texid(pobj->pmodeldata[i].mat_name);
					if(id>0){
						pobj->pmodeldata[i].texid = id;
						glBindTexture(GL_TEXTURE_2D, id);
					}
				} else {
					//activate texture
					glBindTexture(GL_TEXTURE_2D, pobj->pmodeldata[i].texid);
				}

				glVertexPointer( 3, GL_FLOAT, 0, pobj->pmodeldata[i].vertices );
				glNormalPointer(GL_FLOAT,0,pobj->pmodeldata[i].normals);
				glTexCoordPointer(2, GL_FLOAT, 0,  pobj->pmodeldata[i].texmaps);

				glDrawArrays( GL_TRIANGLES, 0, pobj->pmodeldata[i].no_triangles*3);
				//glDrawArrays( GL_POINTS, 0, pobj->pmodeldata[i].no_triangles*3);

			}		
			SwapBuffers( hDC );
			Sleep(14);
		}
	}
	return (int) msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon( NULL, IDI_APPLICATION );
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;
	wcex.hIconSm		= LoadIcon( NULL, IDI_APPLICATION );
	wcex.lpszClassName = "GLSample";

	return RegisterClassEx(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	hInst = hInstance; // Store instance handle in our global variable

	RECT rr={0,0,www,hhh};
	AdjustWindowRect(&rr, WS_OVERLAPPEDWINDOW ,FALSE);
	hWnd = CreateWindow("GLSample", "some title", WS_OVERLAPPEDWINDOW,
		10, 800, rr.right-rr.left,rr.bottom-rr.top, NULL, NULL, hInstance, NULL);

	if (!hWnd)
	{
		return FALSE;
	}

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message)
	{	
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		// TODO: Add any drawing code here...
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}
