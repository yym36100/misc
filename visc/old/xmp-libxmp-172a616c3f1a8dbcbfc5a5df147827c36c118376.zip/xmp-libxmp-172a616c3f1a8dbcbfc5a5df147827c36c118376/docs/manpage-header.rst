======
libxmp 
======
-------------------------------
A tracker module player library
-------------------------------

:Author: Claudio Matsuoka and Hipolito Carraro Jr.
:Date: Nov 2013
:Version: 4.2
:Manual section: 3
:Manual group: Extended Module Player

