/****************************************************************************
 *
 * Filename:    ps2000aApi.h
 * Copyright:   Pico Technology Limited 2010
 * Author:      MAS
 * Description:
 *
 * This header defines the interface to driver routines for the 
 *	PicoScope2000a series of PC Oscilloscopes.
 *
 ****************************************************************************/
#ifndef __PS2000AAPI_H__
#define __PS2000AAPI_H__

#include "picoStatus.h"

#ifdef __cplusplus
	#define PREF0 extern "C"
	#define TYPE_ENUM
#else
	#define PREF0
	#define TYPE_ENUM enum
#endif

#ifdef WIN32
	typedef unsigned __int64 u_int64_t;
	#ifdef PREF1
	  #undef PREF1
	#endif
	#ifdef PREF2
	  #undef PREF2
	#endif
	#ifdef PREF3
	  #undef PREF3
	#endif
	/*	If you are dynamically linking PS2000A.DLL into your project #define DYNLINK here
	 */
	#ifdef DYNLINK
	  #define PREF1 typedef
		#define PREF2
		#define PREF3(x) (__stdcall *x)
	#else
	  #define PREF1
		#ifdef _USRDLL
			#define PREF2 __declspec(dllexport) __stdcall
		#else
			#define PREF2 __declspec(dllimport) __stdcall
		#endif
	  #define PREF3(x) x
	#endif
#else
	/* Define a 64-bit integer type */
	#include <stdint.h>
	typedef int64_t __int64;

	#ifdef DYNLINK
		#define PREF1 typedef
		#define PREF2
		#define PREF3(x) (*x)
	#else
		#ifdef _USRDLL
			#define PREF1 __attribute__((visibility("default")))
		#else
			#define PREF1
		#endif
		#define PREF2
		#define PREF3(x) x
	#endif
	#define __stdcall
#endif

/* Depending on the adc; oversample (collect multiple readings at each time) by up to 256.
 * the results are therefore ALWAYS scaled up to 16-bits, even if
 * oversampling is not used.
 *
 * The maximum and minimum values returned are therefore as follows:
 */

#define PS2208_MAX_ETS_CYCLES	500
#define PS2208_MAX_INTERLEAVE	 20

#define PS2207_MAX_ETS_CYCLES	500
#define PS2207_MAX_INTERLEAVE	 20

#define PS2206_MAX_ETS_CYCLES	250
#define PS2206_MAX_INTERLEAVE	 10

#define PS2000A_EXT_MAX_VALUE  32767
#define PS2000A_EXT_MIN_VALUE -32767

#define PS2000A_MAX_LOGIC_LEVEL	 32767
#define PS2000A_MIN_LOGIC_LEVEL -32767

#define MIN_SIG_GEN_FREQ 0.0f
#define MAX_SIG_GEN_FREQ 20000000.0f

#define PS2000A_MAX_SIG_GEN_BUFFER_SIZE 8192
#define PS2000A_MIN_SIG_GEN_BUFFER_SIZE 1
#define PS2000A_MIN_DWELL_COUNT				10
#define PS2000A_MAX_SWEEPS_SHOTS				((1 << 30) - 1)

#define PS2000A_MAX_ANALOGUE_OFFSET_50MV_200MV	 0.250f
#define PS2000A_MIN_ANALOGUE_OFFSET_50MV_200MV	-0.250f
#define PS2000A_MAX_ANALOGUE_OFFSET_500MV_2V		 2.500f
#define PS2000A_MIN_ANALOGUE_OFFSET_500MV_2V		-2.500f
#define PS2000A_MAX_ANALOGUE_OFFSET_5V_20V			 20.f
#define PS2000A_MIN_ANALOGUE_OFFSET_5V_20V			-20.f

typedef enum enPS2000AChannelBufferIndex
{
	PS2000A_CHANNEL_A_MAX,
	PS2000A_CHANNEL_A_MIN,
	PS2000A_CHANNEL_B_MAX,
	PS2000A_CHANNEL_B_MIN,
	PS2000A_CHANNEL_C_MAX,
	PS2000A_CHANNEL_C_MIN,
	PS2000A_CHANNEL_D_MAX,
	PS2000A_CHANNEL_D_MIN,
	PS2000A_MAX_CHANNEL_BUFFERS
} PS2000A_CHANNEL_BUFFER_INDEX;

typedef enum enPS2000AChannel
{
	PS2000A_CHANNEL_A,
	PS2000A_CHANNEL_B,
	PS2000A_CHANNEL_C,
	PS2000A_CHANNEL_D,
	PS2000A_EXTERNAL,	
	PS2000A_MAX_CHANNELS = PS2000A_EXTERNAL,
	PS2000A_TRIGGER_AUX,
	PS2000A_MAX_TRIGGER_SOURCES

}	PS2000A_CHANNEL;

typedef enum enPS2000ATriggerOperand
{
	PS2000A_OPERAND_NONE,
	PS2000A_OPERAND_OR,
	PS2000A_OPERAND_AND,
	PS2000A_OPERAND_THEN
} PS2000A_TRIGGER_OPERAND;

typedef enum enPS2000DigitalPort
{
	PS2000A_DIGITAL_PORT0 = 0x80, // digital channel 0 - 7
	PS2000A_DIGITAL_PORT1,			 // digital channel 8 - 15
	PS2000A_DIGITAL_PORT2,			 // digital channel 16 - 23
	PS2000A_DIGITAL_PORT3,			 // digital channel 24 - 31
	PS2000A_MAX_DIGITAL_PORTS = (PS2000A_DIGITAL_PORT3 - PS2000A_DIGITAL_PORT0) + 1
}	PS2000A_DIGITAL_PORT;

typedef enum enPS2000ADigitalChannel
{
	PS2000A_DIGITAL_CHANNEL_0,
	PS2000A_DIGITAL_CHANNEL_1,
	PS2000A_DIGITAL_CHANNEL_2,
	PS2000A_DIGITAL_CHANNEL_3,
	PS2000A_DIGITAL_CHANNEL_4,
	PS2000A_DIGITAL_CHANNEL_5,
	PS2000A_DIGITAL_CHANNEL_6,
	PS2000A_DIGITAL_CHANNEL_7,
	PS2000A_DIGITAL_CHANNEL_8,
	PS2000A_DIGITAL_CHANNEL_9,
	PS2000A_DIGITAL_CHANNEL_10,
	PS2000A_DIGITAL_CHANNEL_11,
	PS2000A_DIGITAL_CHANNEL_12,
	PS2000A_DIGITAL_CHANNEL_13,
	PS2000A_DIGITAL_CHANNEL_14,
	PS2000A_DIGITAL_CHANNEL_15,
	PS2000A_DIGITAL_CHANNEL_16,
	PS2000A_DIGITAL_CHANNEL_17,
	PS2000A_DIGITAL_CHANNEL_18,
	PS2000A_DIGITAL_CHANNEL_19,
	PS2000A_DIGITAL_CHANNEL_20,
	PS2000A_DIGITAL_CHANNEL_21,
	PS2000A_DIGITAL_CHANNEL_22,
	PS2000A_DIGITAL_CHANNEL_23,
	PS2000A_DIGITAL_CHANNEL_24,
	PS2000A_DIGITAL_CHANNEL_25,
	PS2000A_DIGITAL_CHANNEL_26,
	PS2000A_DIGITAL_CHANNEL_27,
	PS2000A_DIGITAL_CHANNEL_28,
	PS2000A_DIGITAL_CHANNEL_29,
	PS2000A_DIGITAL_CHANNEL_30,
	PS2000A_DIGITAL_CHANNEL_31,
	PS2000A_MAX_DIGTIAL_CHANNELS
} PS2000A_DIGITAL_CHANNEL;

typedef enum enPS2000ARange
{
	PS2000A_10MV,
	PS2000A_20MV,
	PS2000A_50MV,
	PS2000A_100MV,
	PS2000A_200MV,
	PS2000A_500MV,
	PS2000A_1V,
	PS2000A_2V,
	PS2000A_5V,
	PS2000A_10V,
	PS2000A_20V,
	PS2000A_50V,
	PS2000A_MAX_RANGES,
} PS2000A_RANGE;

typedef enum enPS2000ACoupling
{
	PS2000A_AC,
	PS2000A_DC
} PS2000A_COUPLING;

typedef enum enPS2000AChannelInfo
{
	PS2000A_CI_RANGES,
} PS2000A_CHANNEL_INFO;

typedef enum enPS2000AEtsMode
  {
  PS2000A_ETS_OFF,             // ETS disabled
  PS2000A_ETS_FAST,
	PS2000A_ETS_SLOW,
  PS2000A_ETS_MODES_MAX
  }	PS2000A_ETS_MODE;

typedef enum enPS2000ATimeUnits
  {
  PS2000A_FS,
  PS2000A_PS,
  PS2000A_NS,
  PS2000A_US,
  PS2000A_MS,
  PS2000A_S,
  PS2000A_MAX_TIME_UNITS,
  }	PS2000A_TIME_UNITS;

typedef enum enPS2000ASweepType
{
	PS2000A_UP,
	PS2000A_DOWN,
	PS2000A_UPDOWN,
	PS2000A_DOWNUP,
	PS2000A_MAX_SWEEP_TYPES
} PS2000A_SWEEP_TYPE;

typedef enum enPS2000AWaveType
{
	PS2000A_SINE,
	PS2000A_SQUARE,
	PS2000A_TRIANGLE,
	PS2000A_RAMP_UP,
	PS2000A_RAMP_DOWN,
	PS2000A_SINC,
	PS2000A_GAUSSIAN,
	PS2000A_HALF_SINE,
	PS2000A_DC_VOLTAGE,
	PS2000A_MAX_WAVE_TYPES
} PS2000A_WAVE_TYPE;

typedef enum enPS2000AExtraOperations
{
	PS2000A_ES_OFF,
	PS2000A_WHITENOISE,
	PS2000A_PRBS // Pseudo-Random Bit Stream 
} PS2000A_EXTRA_OPERATIONS;


#define PS2000A_SINE_MAX_FREQUENCY				1000000.f
#define PS2000A_SQUARE_MAX_FREQUENCY			1000000.f
#define PS2000A_TRIANGLE_MAX_FREQUENCY		1000000.f
#define PS2000A_SINC_MAX_FREQUENCY				1000000.f
#define PS2000A_RAMP_MAX_FREQUENCY				1000000.f
#define PS2000A_HALF_SINE_MAX_FREQUENCY		1000000.f
#define PS2000A_GAUSSIAN_MAX_FREQUENCY		1000000.f
#define PS2000A_PRBS_MAX_FREQUENCY				1000000.f
#define PS2000A_PRBS_MIN_FREQUENCY					 0.03f
#define PS2000A_MIN_FREQUENCY			  				 0.03f

typedef enum enPS2000ASigGenTrigType
{
	PS2000A_SIGGEN_RISING,
	PS2000A_SIGGEN_FALLING,
	PS2000A_SIGGEN_GATE_HIGH,
	PS2000A_SIGGEN_GATE_LOW
} PS2000A_SIGGEN_TRIG_TYPE;

typedef enum enPS2000ASigGenTrigSource
{
	PS2000A_SIGGEN_NONE,
	PS2000A_SIGGEN_SCOPE_TRIG,
	PS2000A_SIGGEN_AUX_IN,
	PS2000A_SIGGEN_EXT_IN,
	PS2000A_SIGGEN_SOFT_TRIG
} PS2000A_SIGGEN_TRIG_SOURCE;

typedef enum enPS2000AIndexMode
{
	PS2000A_SINGLE,
	PS2000A_DUAL,
	PS2000A_QUAD,
	PS2000A_MAX_INDEX_MODES
} PS2000A_INDEX_MODE;

typedef enum enPS2000A_ThresholdMode
{
	PS2000A_LEVEL,
	PS2000A_WINDOW
} PS2000A_THRESHOLD_MODE;

typedef enum enPS2000AThresholdDirection
{
	PS2000A_ABOVE, //using upper threshold
	PS2000A_BELOW, 
	PS2000A_RISING, // using upper threshold
	PS2000A_FALLING, // using upper threshold
	PS2000A_RISING_OR_FALLING, // using both threshold
	PS2000A_ABOVE_LOWER, // using lower threshold
	PS2000A_BELOW_LOWER, // using lower threshold
	PS2000A_RISING_LOWER,			 // using upper threshold
	PS2000A_FALLING_LOWER,		 // using upper threshold

	// Windowing using both thresholds
	PS2000A_INSIDE = PS2000A_ABOVE, 
	PS2000A_OUTSIDE = PS2000A_BELOW,
	PS2000A_ENTER = PS2000A_RISING, 
	PS2000A_EXIT = PS2000A_FALLING, 
	PS2000A_ENTER_OR_EXIT = PS2000A_RISING_OR_FALLING,
	PS2000A_POSITIVE_RUNT = 9,
  PS2000A_NEGATIVE_RUNT,

	// no trigger set
  PS2000A_NONE = PS2000A_RISING 
} PS2000A_THRESHOLD_DIRECTION;

typedef enum enPS2000ADigitalDirection
{
	PS2000A_DIGITAL_DONT_CARE,
	PS2000A_DIGITAL_DIRECTION_LOW,	
	PS2000A_DIGITAL_DIRECTION_HIGH,
	PS2000A_DIGITAL_DIRECTION_RISING,
	PS2000A_DIGITAL_DIRECTION_FALLING,
	PS2000A_DIGITAL_DIRECTION_RISING_OR_FALLING,
	PS2000A_DIGITAL_MAX_DIRECTION
} PS2000A_DIGITAL_DIRECTION;

typedef enum enPS2000ATriggerState
{
  PS2000A_CONDITION_DONT_CARE,
  PS2000A_CONDITION_TRUE,
  PS2000A_CONDITION_FALSE,
	PS2000A_CONDITION_MAX
} PS2000A_TRIGGER_STATE;

#pragma pack(1)
typedef struct tPS2000ATriggerConditions
{
  PS2000A_TRIGGER_STATE channelA;
  PS2000A_TRIGGER_STATE channelB;
  PS2000A_TRIGGER_STATE channelC;
  PS2000A_TRIGGER_STATE channelD;
  PS2000A_TRIGGER_STATE external;
  PS2000A_TRIGGER_STATE aux;
	PS2000A_TRIGGER_STATE pulseWidthQualifier;
	PS2000A_TRIGGER_STATE digital;
} PS2000A_TRIGGER_CONDITIONS;
#pragma pack()

#pragma pack(1)
typedef struct tPS2000APwqConditions
{
  PS2000A_TRIGGER_STATE channelA;
  PS2000A_TRIGGER_STATE channelB;
  PS2000A_TRIGGER_STATE channelC;
  PS2000A_TRIGGER_STATE channelD;
  PS2000A_TRIGGER_STATE external;
  PS2000A_TRIGGER_STATE aux;
	PS2000A_TRIGGER_STATE digital;
} PS2000A_PWQ_CONDITIONS;
#pragma pack()

#pragma pack(1)
typedef struct tPS2000ADigitalChannelDirections
{
	PS2000A_DIGITAL_CHANNEL channel;
	PS2000A_DIGITAL_DIRECTION direction;
} PS2000A_DIGITAL_CHANNEL_DIRECTIONS;
#pragma pack()

#pragma pack(1)
typedef struct tPS2000ATriggerChannelProperties
{
  short										thresholdUpper;
	unsigned short					thresholdUpperHysteresis; 
  short										thresholdLower;
	unsigned short					thresholdLowerHysteresis;
	PS2000A_CHANNEL					channel;
  PS2000A_THRESHOLD_MODE	thresholdMode;
} PS2000A_TRIGGER_CHANNEL_PROPERTIES;
#pragma pack()
	
typedef enum enPS2000ARatioMode
{
	PS2000A_RATIO_MODE_NONE,
	PS2000A_RATIO_MODE_AGGREGATE = 1,	
	PS2000A_RATIO_MODE_DECIMATE = 2,
	PS2000A_RATIO_MODE_AVERAGE = 4,
} PS2000A_RATIO_MODE;

typedef enum enPS2000APulseWidthType
{
	PS2000A_PW_TYPE_NONE,
  PS2000A_PW_TYPE_LESS_THAN,
	PS2000A_PW_TYPE_GREATER_THAN,
	PS2000A_PW_TYPE_IN_RANGE,
	PS2000A_PW_TYPE_OUT_OF_RANGE
} PS2000A_PULSE_WIDTH_TYPE;

typedef enum enPS2000AHoldOffType
{
	PS2000A_TIME,
	PS2000A_MAX_HOLDOFF_TYPE
} PS2000A_HOLDOFF_TYPE;

typedef void (__stdcall *ps2000aBlockReady)
	(
		short											handle,
		PICO_STATUS								status,
		void										*	pParameter
	); 

typedef void (__stdcall *ps2000aStreamingReady)
	(
		short    									handle,
		long     									noOfSamples,
		unsigned long							startIndex,
		short    									overflow,
		unsigned long							triggerAt,
		short    									triggered,
		short    									autoStop,
		void										*	pParameter
	); 

typedef void (__stdcall *ps2000aDataReady)
	(
		short    									handle,
		PICO_STATUS								status,
		unsigned long     				noOfSamples,
		short    									overflow,
		void										*	pParameter
	); 

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aOpenUnit) 
  (
	  short											* handle,
		char											* serial
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aOpenUnitAsync)
  (
	  short											* status,
		char											* serial
	);


PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aOpenUnitProgress)
	(
	  short 										* handle,
	  short 										* progressPercent,
	  short 										* complete
	); 

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetUnitInfo)
 	(
	  short     								  handle, 
	  char      								* string,
	  short     								  stringLength,
	  short     								* requiredSize,
	  PICO_INFO 								  info
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aFlashLed)
	(
	  short 											handle,
		short 											start
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aCloseUnit)
	(
	  short												handle
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aMemorySegments)
	(
	  short												handle,
		unsigned short							nSegments,
		long											* nMaxSamples
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetChannel)
 	(
	  short												handle,
		PS2000A_CHANNEL							channel,
	  short												enabled,
	  PS2000A_COUPLING						type, 
		PS2000A_RANGE								range,
		float												analogOffset
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetDigitalPort)
 	(
	  short												handle,
		PS2000A_DIGITAL_PORT				port,
	  short												enabled,
		short									      logicLevel
	);


PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetNoOfCaptures) 
	(
	short handle,
	unsigned short nCaptures
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetTimebase)
	(
	   short											handle,
	   unsigned long							timebase,
	   long												noSamples,
	   long											* timeIntervalNanoseconds,
	   short											oversample,
		 long											* maxSamples,
		 unsigned short							segmentIndex
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetTimebase2)
	(
	   short											handle,
	   unsigned long							timebase,
	   long												noSamples,
	   float										* timeIntervalNanoseconds,
	   short											oversample,
		 long											* maxSamples,
		 unsigned short							segmentIndex
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetSigGenArbitrary)
	(
	 	short												handle,
	 	long												offsetVoltage,
	 	unsigned long								pkToPk,
	 	unsigned long								startDeltaPhase,
	 	unsigned long								stopDeltaPhase,
	 	unsigned long								deltaPhaseIncrement, 
	 	unsigned long								dwellCount,
	 	short											*	arbitraryWaveform, 
	 	long												arbitraryWaveformSize,
		PS2000A_SWEEP_TYPE					sweepType,
		PS2000A_EXTRA_OPERATIONS		operation,
		PS2000A_INDEX_MODE					indexMode,
		unsigned long								shots,
		unsigned long								sweeps,
		PS2000A_SIGGEN_TRIG_TYPE		triggerType,
		PS2000A_SIGGEN_TRIG_SOURCE	triggerSource,
		short												extInThreshold
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3(ps2000aSetSigGenBuiltIn)
	(
		short												handle,
		long												offsetVoltage,
		unsigned long								pkToPk,
		short												waveType,
		float												startFrequency,
		float												stopFrequency,
		float												increment,
		float												dwellTime,
		PS2000A_SWEEP_TYPE					sweepType,
		PS2000A_EXTRA_OPERATIONS		operation,
		unsigned long								shots,
		unsigned long								sweeps,
		PS2000A_SIGGEN_TRIG_TYPE		triggerType,
		PS2000A_SIGGEN_TRIG_SOURCE	triggerSource,
		short												extInThreshold
		);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSigGenSoftwareControl)
	(
		short												handle,
		short												state
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetEts)
  (
		short												handle,
		PS2000A_ETS_MODE						mode,
		short												etsCycles,
		short												etsInterleave,
		long											* sampleTimePicoseconds
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetSimpleTrigger)
	(
		short handle,
		short enable,
		PS2000A_CHANNEL source,
		short threshold,
		PS2000A_THRESHOLD_DIRECTION direction,
		unsigned long delay,
		short autoTrigger_ms
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetTriggerDigitalPortProperties)
(
	short handle,
	PS2000A_DIGITAL_CHANNEL_DIRECTIONS * directions,
	short															   nDirections
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetDigitalAnalogTriggerOperand)
(
	short handle,
	PS2000A_TRIGGER_OPERAND operand
);



PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetTriggerChannelProperties)
	(
		short																	handle,
		PS2000A_TRIGGER_CHANNEL_PROPERTIES	*	channelProperties,
		short																	nChannelProperties,
		short																	auxOutputEnable,
		long																	autoTriggerMilliseconds
	);


PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetTriggerChannelConditions)
	(
		short													handle,
		PS2000A_TRIGGER_CONDITIONS	*	conditions,
		short													nConditions
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetTriggerChannelDirections)
	(
		short													handle,
		PS2000A_THRESHOLD_DIRECTION		channelA,
		PS2000A_THRESHOLD_DIRECTION		channelB,
		PS2000A_THRESHOLD_DIRECTION		channelC,
		PS2000A_THRESHOLD_DIRECTION		channelD,
		PS2000A_THRESHOLD_DIRECTION		ext,
		PS2000A_THRESHOLD_DIRECTION		aux
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetTriggerDelay)
	(
		short									handle,
		unsigned long					delay
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetPulseWidthQualifier)
	(
		short													handle,
		PS2000A_PWQ_CONDITIONS			*	conditions,
		short													nConditions,
		PS2000A_THRESHOLD_DIRECTION		direction,
		unsigned long									lower,
		unsigned long									upper,
		PS2000A_PULSE_WIDTH_TYPE			type
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aIsTriggerOrPulseWidthQualifierEnabled)
	(
		short 								handle,
		short 							* triggerEnabled,
		short 							* pulseWidthQualifierEnabled
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetTriggerTimeOffset)
	(
		short									handle,
		unsigned long 			* timeUpper,
		unsigned long 			* timeLower,
		PS2000A_TIME_UNITS	*	timeUnits,
		unsigned short				segmentIndex	
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetTriggerTimeOffset64)
	(
		short									handle,
		__int64							* time,
		PS2000A_TIME_UNITS	*	timeUnits,
		unsigned short				segmentIndex	
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetValuesTriggerTimeOffsetBulk)
	(
	  short									handle,
		unsigned long				*	timesUpper,
		unsigned long				* timesLower,
		PS2000A_TIME_UNITS	*	timeUnits,
		unsigned short				fromSegmentIndex,
		unsigned short				toSegmentIndex
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetValuesTriggerTimeOffsetBulk64)
	(
	  short									handle,
		__int64							*	times,
		PS2000A_TIME_UNITS	*	timeUnits,
		unsigned short				fromSegmentIndex,
		unsigned short				toSegmentIndex
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetNoOfCaptures)
	(
	  short								handle,
		unsigned long			*	nCaptures
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetNoOfProcessedCaptures)
	(
	  short								handle,
		unsigned long			*	nProcessedCaptures
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetDataBuffer)
(
   short								 handle,
	 int						 			 channelOrPort,
	 short							*  buffer,
   long									 bufferLth,
	 unsigned short				 segmentIndex,
	 PS2000A_RATIO_MODE		 mode
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetDataBuffers)
(
   short								 handle,
	 int						 			 channelOrPort,
	 short							 * bufferMax,
	 short							 * bufferMin,
   long									 bufferLth,
	 unsigned short				 segmentIndex,
	 PS2000A_RATIO_MODE		 mode
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetEtsTimeBuffer)
(
   short									handle,
	 __int64 *							buffer,
	 long										bufferLth
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aSetEtsTimeBuffers)
(
   short									handle,
	 unsigned long				* timeUpper,
	 unsigned long				* timeLower,
	 long										bufferLth
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aIsReady)
	(
		short handle,
		short * ready
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aRunBlock)
	(
		short									handle,
		long									noOfPreTriggerSamples,
		long									noOfPostTriggerSamples,
		unsigned long					timebase,
		short									oversample,
		long								* timeIndisposedMs,
		unsigned short				segmentIndex,
		ps2000aBlockReady			lpReady,
		void								* pParameter
	);


PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aRunStreaming)
  (
	  short									handle,
		unsigned long				* sampleInterval,	
		PS2000A_TIME_UNITS		sampleIntervalTimeUnits,
	  unsigned long					maxPreTriggerSamples,
	  unsigned long					maxPostPreTriggerSamples,
		short									autoStop,
		unsigned long					downSampleRatio,
		PS2000A_RATIO_MODE		downSampleRatioMode,
    unsigned long					overviewBufferSize
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetStreamingLatestValues)
  (
    short									handle, 
    ps2000aStreamingReady	lpPs2000aReady,
		void								* pParameter
  );  

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aNoOfStreamingValues)
	(
	  short								handle,
		unsigned long			*	noOfValues
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetMaxDownSampleRatio)
	(
	  short								handle,
		unsigned long 			noOfUnaggreatedSamples,
		unsigned long 		* maxDownSampleRatio,
		PS2000A_RATIO_MODE	downSampleRatioMode,
		unsigned short			segmentIndex
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetValues)
	(
	  short								handle,
		unsigned long 			startIndex,
	  unsigned long			*	noOfSamples,
	  unsigned long				downSampleRatio,
		PS2000A_RATIO_MODE	downSampleRatioMode,
		unsigned short			segmentIndex,
		short							* overflow
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetValuesBulk)
	(
	  short								handle,
		unsigned long			*	noOfSamples,
		unsigned short			fromSegmentIndex,
		unsigned short			toSegmentIndex,
	  unsigned long				downSampleRatio,
		PS2000A_RATIO_MODE 	downSampleRatioMode,
		short							* overflow
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetValuesAsync)
	(
	  short								handle,
		unsigned long				startIndex,
	  unsigned long				noOfSamples,
	  unsigned long				downSampleRatio,
		short								downSampleRatioMode,
		unsigned short			segmentIndex,
	  void							*	lpDataReady,
		void							*	pParameter
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetValuesOverlapped)
	(
	  short								handle,
	  unsigned long 			startIndex,
	  unsigned long			*	noOfSamples,
	  unsigned long				downSampleRatio,
	  PS2000A_RATIO_MODE	downSampleRatioMode,
		unsigned short      segmentIndex,
	  short				*       overflow
	);


PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetValuesOverlappedBulk)
	(
	  short								handle,
		unsigned long				startIndex,
  	unsigned long 	 	*	noOfSamples,
	  unsigned long				downSampleRatio,
	  PS2000A_RATIO_MODE	downSampleRatioMode,
	  unsigned short			fromSegmentIndex,
	  unsigned short			toSegmentIndex,
	  short							*	overflow
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aStop)
	(
	  short handle
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aHoldOff)
	(
	  short								handle,	
		u_int64_t						holdoff,
		PS2000A_HOLDOFF_TYPE	type
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetChannelInformation) 
	(
		short handle, 
		PS2000A_CHANNEL_INFO info, 
		int probe, 
		int * ranges,
		int * length,
		int channels
  );

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aEnumerateUnits)
	(
	short * count,
	char * serials,
	short * serialLth
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aPingUnit)
	(
	short handle
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aMaximumValue)
	(
	short		handle,
	short * value
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aMinimumValue)
	(
	short		handle,
	short * value
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetAnalogueOffset)
	(
	short handle, 
	PS2000A_RANGE range,
	PS2000A_COUPLING	coupling,
	float * maximumVoltage,
	float * minimumVoltage
	);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (ps2000aGetMaxSegments)
	(
	short		handle,
	unsigned short * maxSegments
	);

#endif