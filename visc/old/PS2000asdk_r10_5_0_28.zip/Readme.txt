PS2000A SDK
===========

Contents
========
1) Products supported
2) Console example
3) Excel example
4) Labview examples
5) Wrapper code




1) Products supported by this SDK
=================================
PS2205MSO
PS2206
PS2207
PS2208

---------------------------------------------------------------------------------------------------------------------------

2) Console example
==================
Files required....

picoStatus.h
ps2000aApi.h
ps2000Acon.c
ps2000a.lib (or ps2000abc.lib, a borland C version of the ps2000a.lib file)
ps2000a.dll




To build the Windows Console application from the Microsoft Visual Studio IDE...
File, New -> Project...
Visual C++, Win32 Console Application

At the Win32 Application Wizard, select Next
At the Application Settings screen, make sure 'Console application' is selected, and tick the 'Empty project' box

Select Finish

In the 'Solution Explorer' payne, add...

PS2000Acon.c to Source Files

picoStatus.h & ps2000aApi.h to Header Files

ps2000a.lib to Resource Files.

Make sure ps2000a.dll is in the search path.

(If you don't have the PicoScope application installed on your PC, you will need to install the Kernel drivers.
 Please see the kernelDrivers.txt for more details)

---------------------------------------------------------------------------------------------------------------------------

3) Excel example
================
Files required....
ps2000a.xls
ps2000a.dll
ps2000awrapper.dll

The Excel example uses VBA macro code to call the API.
Some API functions cannot be called directly the VBA code, and so a wrapper dll is proved as an interface to these functions.

---------------------------------------------------------------------------------------------------------------------------

4) Labview examples
===================
Three different examples are provided to demonstrate different modes of operation of the scope.
PicoScope20000aExampleBlock.vi
PicoScope20000aExampleRapidBlock.vi
PicoScope20000aExampleStreaming.vi
PicoScope20000aExampleBlockMSO.vi
PicoScope20000aExampleStreamingMSO.vi



To use these examples, you will also need....
PicoScope2000a.llb
ps2000a.dll

The examples supplied can be used with Labview version 8.5 onwards.


---------------------------------------------------------------------------------------------------------------------------

5) Wrapper Code 
===============
Some programming languages are not able to handle pointers, or function callbacks, and so cannot call some API functions directly.

To overcome this limitation, a set of wrapper functions are supplied, which should be called in place of some of the API functions.

The wrapper source code is included in the SDK, to show users how the wrapper dll is implemented.

