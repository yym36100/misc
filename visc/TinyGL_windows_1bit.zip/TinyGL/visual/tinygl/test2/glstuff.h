#pragma once


#ifdef __cplusplus
extern "C" {
#endif

void draw1( void );
void init1(void);
void reshape1( int width, int height );
void idle1( void );

void draw2( void );
void init2(void);
void reshape2( int width, int height );
void idle2( void );

void draw3( void );
void init3(void);
void reshape3( int width, int height );
void idle3( void );

#ifdef __cplusplus
};
#endif 