// testtinygl.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "test2.h"

#include <math.h>
#include <stdio.h>


#include "GL/gl.h"

#include "GL/oscontext.h"
#pragma comment(lib, "tinygl")

#include "glstuff.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name
HWND hWnd;
// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

unsigned short buffer[320*240];
void *buffers[1] = {buffer};


HDC hDC;
int *pData;

void CWinSurface(int  w, int h){

	BITMAPINFO BitInfo;

	HBITMAP hBitmap;

	ZeroMemory(&BitInfo,sizeof(BitInfo));
	BitInfo.bmiHeader.biBitCount = 32;			// rgb 8 bytes for each component(3)
	BitInfo.bmiHeader.biCompression = BI_RGB;	// rgb = 3 components
	BitInfo.bmiHeader.biPlanes = 1;
	BitInfo.bmiHeader.biSize = sizeof(BitInfo.bmiHeader); // size of this struct
	BitInfo.bmiHeader.biWidth = w;		// width of window
	BitInfo.bmiHeader.biHeight = -h;	// height of window

	hDC = CreateCompatibleDC(0);
	void *p;
	hBitmap = CreateDIBSection(hDC, &BitInfo, DIB_RGB_COLORS, &p, 0, 0); // create a dib section for the dc
	pData = (int*)p;

	int *p2=(int*)pData;
	for(int i=0;i<w*h;i++){ *p2++=0x12345678;}
	SelectObject(hDC, hBitmap); // assign the dib section to the dc
}

#define rgba32(r,g,b,a) ((a<<24)|(r<<16)|(g<<8)|(b))
//#define RGB2COLOR(r, g, b) ((((r>>3)<<11) | ((g>>2)<<5) | (b>>3)))

#define GetPixel(x,y) in[(y)*320+x]
#define SetPixel(x,y,v) out[(y)*320+x]=v

#define GetPixel2(x,y) copy[(y)*320+x]
#define UpdatePixel2(x,y,v) copy[(y)*320+x] = copy[(y)*320+x] + (v)

typedef unsigned char u8;
typedef unsigned short u16;
typedef signed short i16;

void dither_img(u8* in, u8* out){					
	u16 copy[320*242];
	u16 *p = copy;

	i16 oldpix, newpix,error;
	for(int y=0;y<240;y++) for(int x=0;x<320;x++) *p++=GetPixel(x,y);

	for(int y=0;y<240;y++)
		for(int x=0;x<320;x++){
			oldpix = GetPixel2(x,y);
			newpix = oldpix <128?0:255;						

			error = oldpix-newpix;

			SetPixel(x,y,newpix ?255:0 );

			UpdatePixel2(x+1,y, error *8.0/32.0);
			UpdatePixel2(x+2,y,error *4.0/32.0);

			UpdatePixel2(x-2,y+1, error *2.0/32.0);
			UpdatePixel2(x-1,y+1, error *4.0/32.0);
			UpdatePixel2(x  ,y+1, error *8.0/32.0);
			UpdatePixel2(x+1,y+1, error *4.0/32.0);
			UpdatePixel2(x+2,y+1, error *2.0/32.0);
		}
}

void Paint(HDC hdc) {
	//copy openglsurface
	unsigned short incolor;
	unsigned long outcolor;

	unsigned char r,g,b;

	u8 dthin[320*240];
	u8 dthout[320*240];

	for(int y=0;y<240;y++)
		for(int x=0;x<320;x++){
			incolor = buffer[y*320+x];
			r = incolor>>11;
			g = (incolor>>5)&0x3f;
			b = incolor&0x1f;

			r<<=3;
			g<<=2;
			b<<=3;

			outcolor = rgba32(r,g,b,0xff);

			pData[y*320+x]=outcolor;
			dthin[y*320+x]=(r+g+b)/3;
		}
#if 1
		dither_img(dthin,dthout);		
		for(int y=0;y<240;y++)
		for(int x=0;x<320;x++){
			r = dthout[y*320+x];
			pData[y*320+x] = rgba32(r,r,r,0xff);
		}
#endif

		//	BitBlt(hdc, 0, 0, 320, 240, hDC, 0, 0, SRCCOPY); // copy hdc to their hdc	
		StretchBlt(hdc,0,0,320*3,240*3,hDC,0,0,320,240,SRCCOPY);

}

int APIENTRY _tWinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPTSTR    lpCmdLine,int       nCmdShow){

	CWinSurface(320,240);

	OutputDebugString("My output string.\n");
	ostgl_context *mycontext = ostgl_create_context(320,240,16,buffers,1);
	ostgl_make_current(mycontext,0);

	init1();
	reshape1(320,240);
	draw1();


	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_TEST2, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)){return FALSE;}

	SetTimer(hWnd,0,16,0);
	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TEST2));

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)){
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)){
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
	return (int) msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance){
	WNDCLASSEX wcex;
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TEST2));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_TEST2);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));
	return RegisterClassEx(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow){
	hInst = hInstance; // Store instance handle in our global variable

	hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW, 100, 100,320*3+20,  240*3+60, NULL, NULL, hInstance, NULL);

	if (!hWnd){return FALSE;}
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message)
	{
	case WM_TIMER:
		idle1();
		InvalidateRect(hWnd,0,0);
		break;
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{		
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);		
		Paint(hdc);
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}
