#include "stdafx.h"
#include <stdio.h>

#include "GL/gl.h"
#include "glu.h"

#include "glstuff.h"


static GLfloat Xrot, Xstep;
static GLfloat Yrot, Ystep;
static GLfloat Zrot, Zstep;
static GLfloat Step = 1.0;
static GLfloat Scale = 1.0;
static GLuint Object;

GLuint textureIDs[6];


#define teapot_count 5184 

extern "C" const float teapot[teapot_count];

static const float quadx[6*4*3] = {
   /* FRONT */
   -1, -1,  1,
   1, -1,  1,
   -1,  1,  1,
   1,  1,  1,

   /* BACK */
   -1, -1, -1,
   -1,  1, -1,
   1, -1, -1,
   1,  1, -1,

   /* LEFT */
   -1, -1,  1,
   -1,  1,  1,
   -1, -1, -1,
   -1,  1, -1,

   /* RIGHT */
   1, -1, -1,
   1,  1, -1,
   1, -1,  1,
   1,  1,  1,

   /* TOP */
   -1,  1,  1,
   1,  1,  1,
   -1,  1, -1,
   1,  1, -1,

   /* BOTTOM */
   -1, -1,  1,
   -1, -1, -1,
   1, -1,  1,
   1, -1, -1,
};

static const float texCoords[6 * 4 * 2] = {
    0.f,  0.f,
   0.f,  1.f,
   1.f,  0.f,
   1.f,  1.f,

   0.f,  0.f,
   0.f,  1.f,
   1.f,  0.f,
   1.f,  1.f,

   0.f,  0.f,
   0.f,  1.f,
   1.f,  0.f,
   1.f,  1.f,

   0.f,  0.f,
   0.f,  1.f,
   1.f,  0.f,
   1.f,  1.f,

   0.f,  0.f,
   0.f,  1.f,
   1.f,  0.f,
   1.f,  1.f,

   0.f,  0.f,
   0.f,  1.f,
   1.f,  0.f,
   1.f,  1.f
};
static GLuint make_object( void ) {
	//GLuint list;
	//list = glGenLists( 1 );

	//glNewList( list, GL_COMPILE );
	glEnableClientState(GL_VERTEX_ARRAY);
	


	//glVertexPointer(3,GL_FLOAT,0,teapot);
	//glBegin(GL_TRIANGLE_STRIP);for(int i=0;i<1000;i++)glArrayElement(i);glEnd();

#if 1
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);

	glVertexPointer(3,GL_FLOAT,0,quadx);
	glTexCoordPointer(2,GL_FLOAT,0,texCoords);

	
	glBindTexture(GL_TEXTURE_2D, textureIDs[0]);
	glBegin(GL_TRIANGLE_STRIP);for(int i=0;i<4;i++)glArrayElement(i);glEnd();

	glBindTexture(GL_TEXTURE_2D, textureIDs[1]);
	glBegin(GL_TRIANGLE_STRIP);for(int i=0;i<4;i++)glArrayElement(4+i);glEnd();

	glBindTexture(GL_TEXTURE_2D, textureIDs[2]);
	glBegin(GL_TRIANGLE_STRIP);for(int i=0;i<4;i++)glArrayElement(8+i);glEnd();

	glBindTexture(GL_TEXTURE_2D, textureIDs[3]);
	glBegin(GL_TRIANGLE_STRIP);for(int i=0;i<4;i++)glArrayElement(12+i);glEnd();

	glBindTexture(GL_TEXTURE_2D, textureIDs[4]);
	glBegin(GL_TRIANGLE_STRIP);for(int i=0;i<4;i++)glArrayElement(16+i);glEnd();

	glBindTexture(GL_TEXTURE_2D, textureIDs[5]);
	glBegin(GL_TRIANGLE_STRIP);for(int i=0;i<4;i++)glArrayElement(20+i);glEnd();
#endif
/*
	glBegin( GL_TRIANGLE_STRIP );
	glColor3f( 0.0, 0.0, 1.0 );glTexCoord2f(0,1);glVertex3f( -1,  1, -1 );
	glColor3f( 1.0, 1.0, 1.0 );glTexCoord2f(0,0);glVertex3f( -1, -1, -1 );
	glColor3f( 0.0, 1.0, 0.0 );glTexCoord2f(1,1);glVertex3f(  1,  1, -1 );
	glColor3f( 1.0, 0.0, 0.0 );glTexCoord2f(1,0);glVertex3f(  1, -1, -1 );
	
	glEnd();

	glColor3f( 1.0, 1.0, 1.0 );

	glBindTexture(GL_TEXTURE_2D, textureIDs[1]);
	glBegin( GL_TRIANGLE_STRIP );
	
	glTexCoord2f(0,1);glVertex3f(  -1,  1, 1 );
	glTexCoord2f(0,0);glVertex3f(  -1, -1, 1 );
	glTexCoord2f(1,1);glVertex3f( 1, 1, 1 );
	glTexCoord2f(1,0);glVertex3f( 1, -1, 1 );
	glEnd();

	glBegin( GL_LINES );
	glVertex3f(  1.0,  1, -1 );   glVertex3f(  1.0,  1, 1 );
	glVertex3f(  1.0, -1, -1 );   glVertex3f(  1.0, -1, 1 );
	glVertex3f( -1.0, -1, -1 );   glVertex3f( -1.0, -1, 1 );
	glVertex3f( -1.0,  1, -1 );   glVertex3f( -1.0,  1, 1 );
	glEnd();
*/
	//glEndList();
	return 0;
}
char texturedata[256*256*3];

char f1[256*256*3];
char f2[256*256*3];
char f3[256*256*3];
char f4[256*256*3];
char f5[256*256*3];


	//"u:\arm2\proj\f767zi nucleo\tool\ppm2bin\test\texture.ppm" 
#define RGB2COLOR(r, g, b) ((((r>>3)<<11) | ((g>>2)<<5) | (b>>3)))

void load_texture(char *p, char *name){
	unsigned char tmpbuff[256*256*3];
	unsigned char *s = tmpbuff;

	FILE *f=fopen(name,"rb");
	if(!f) return;
	fread(s,0x36,1,f); // dummy
	fread(s,256*256*3,1,f);
	fclose(f);

	unsigned char c;
	unsigned short color2;
	for(int y=0;y<256;y++)
		for(int x=0;x<256;x++){
			c = *s; s+=3;			
			p[(y*256+x)*3+0] = c;
			p[(y*256+x)*3+1] = c;
			p[(y*256+x)*3+2] = c;
		}	
}

void init1(void) {
	//load_texture(texturedata,"u:/arm2/proj/f767zi nucleo/tool/ppm2bin/test/texture.ppm");
	load_texture(texturedata,"u:/visc/TinyGL/textures/cortex.ppm");
	load_texture(texturedata,"u:/work/2023/rareprojcopy/_old/remote repos/TinyGL/textures/cortex.ppm");
	
	load_texture(f1,"u:/work/2023/rareprojcopy/_old/remote repos/TinyGL/textures/f3.ppm");
	load_texture(f2,"u:/work/2023/rareprojcopy/_old/remote repos/TinyGL/textures/f4.ppm");
	load_texture(f3,"u:/work/2023/rareprojcopy/_old/remote repos/TinyGL/textures/f5.ppm");
	load_texture(f4,"u:/work/2023/rareprojcopy/_old/remote repos/TinyGL/textures/f3.ppm");
	load_texture(f5,"u:/work/2023/rareprojcopy/_old/remote repos/TinyGL/textures/f4.ppm");

	

	Object = make_object();
	glCullFace( GL_BACK );
	 glEnable( GL_CULL_FACE );
	glDisable( GL_DITHER );
	glShadeModel( GL_SMOOTH );
	glEnable( GL_DEPTH_TEST );
	glEnable( GL_TEXTURE_2D);

	glGenTextures(6, textureIDs);

	glBindTexture(GL_TEXTURE_2D, textureIDs[0]);
	glTexImage2D(GL_TEXTURE_2D, 0,3, 256, 256, 0, GL_RGB, GL_UNSIGNED_BYTE, f1);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glBindTexture(GL_TEXTURE_2D, textureIDs[1]);
	glTexImage2D(GL_TEXTURE_2D, 0,3, 256, 256, 0, GL_RGB, GL_UNSIGNED_BYTE, f2);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glBindTexture(GL_TEXTURE_2D, textureIDs[2]);
	glTexImage2D(GL_TEXTURE_2D, 0,3, 256, 256, 0, GL_RGB, GL_UNSIGNED_BYTE, f3);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glBindTexture(GL_TEXTURE_2D, textureIDs[3]);
	glTexImage2D(GL_TEXTURE_2D, 0,3, 256, 256, 0, GL_RGB, GL_UNSIGNED_BYTE, f4);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glBindTexture(GL_TEXTURE_2D, textureIDs[4]);
	glTexImage2D(GL_TEXTURE_2D, 0,3, 256, 256, 0, GL_RGB, GL_UNSIGNED_BYTE, texturedata);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glBindTexture(GL_TEXTURE_2D, textureIDs[5]);
	glTexImage2D(GL_TEXTURE_2D, 0,3, 256, 256, 0, GL_RGB, GL_UNSIGNED_BYTE, f5);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	Xrot = Yrot = Zrot = 0.4;
	Xstep = Step;
	Ystep = Zstep = 0.4;
}

void reshape1( int width, int height ) {
	float ar=width/(float)height;
	glViewport(0, 0, (GLint)width, (GLint)height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustum( -1.0, 1.0, -1.0/ar, 1.0/ar, 5.0, 50 );
	glMatrixMode(GL_MODELVIEW);
}



void idle1( void ) {
	Xrot += Xstep;
	Yrot += Ystep;
	Zrot += Zstep;

	if (Xrot>=360.0) {
		Xrot = Xstep = 0.4;
		Ystep = Step;
	}
	else if (Yrot>=360.0) {
		Yrot = Ystep = 0.4;
		Zstep = Step;
	}
	else if (Zrot>=360.0) {
		Zrot = Zstep = 0.4;
		Xstep = Step;
	}
	draw1();
}

void draw1( void ) {
	glClearColor(0.15,0.15,0.15,1.0);
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		


	glPushMatrix();

	glTranslatef( 0.0, 0.0, -7 );
	glScalef( Scale, Scale, Scale );
	if (Xstep) {
		glRotatef( Xrot, 1.0, 0.0, 0.0 );
	}
	 if (Ystep) {
		glRotatef( Yrot, 0.0, 1.0, 0.0 );
	}
	 if (Zstep) {
		glRotatef( Zrot, 0.0, 0.0, 1.0 );
	}

	make_object();	
//	glCallList( Object );
	//gluSphere(0,1,23,23);
	//drawTorus(.5,30,2,30);
	//gluDisk(0,0,3,5,5);
	glPopMatrix();
	glFlush();
}



























