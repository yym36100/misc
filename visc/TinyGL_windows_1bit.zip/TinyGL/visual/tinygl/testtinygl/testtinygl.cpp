// testtinygl.cpp : Defines the entry point for the application.
//



#include <math.h>
#include <stdio.h>


#include "stdafx.h"
#include "testtinygl.h"


#include "GL/gl.h"

#include "GL/oscontext.h"
#pragma comment(lib, "tinygl")

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);


static GLfloat Xrot, Xstep;
static GLfloat Yrot, Ystep;
static GLfloat Zrot, Zstep;
static GLfloat Step = 5.0;
static GLfloat Scale = 1.0;
static GLuint Object;

static GLuint make_object( void )
{
	GLuint list;
	list = glGenLists( 1 );

	glNewList( list, GL_COMPILE );

	glBegin( GL_LINE_LOOP );
	glColor3f( 1.0, 1.0, 1.0 );
	glVertex3f(  1.0,  0.5, -0.4 );
	glColor3f( 1.0, 0.0, 0.0 );
	glVertex3f(  1.0, -0.5, -0.4 );
	glColor3f( 0.0, 1.0, 0.0 );
	glVertex3f( -1.0, -0.5, -0.4 );
	glColor3f( 0.0, 0.0, 1.0 );
	glVertex3f( -1.0,  0.5, -0.4 );
	glEnd();

	glColor3f( 1.0, 1.0, 1.0 );

	glBegin( GL_LINE_LOOP );
	glVertex3f(  1.0,  0.5, 0.4 );
	glVertex3f(  1.0, -0.5, 0.4 );
	glVertex3f( -1.0, -0.5, 0.4 );
	glVertex3f( -1.0,  0.5, 0.4 );
	glEnd();

	glBegin( GL_LINES );
	glVertex3f(  1.0,  0.5, -0.4 );   glVertex3f(  1.0,  0.5, 0.4 );
	glVertex3f(  1.0, -0.5, -0.4 );   glVertex3f(  1.0, -0.5, 0.4 );
	glVertex3f( -1.0, -0.5, -0.4 );   glVertex3f( -1.0, -0.5, 0.4 );
	glVertex3f( -1.0,  0.5, -0.4 );   glVertex3f( -1.0,  0.5, 0.4 );
	glEnd();

	glEndList();
	return list;
}

void init(void)
{
	Object = make_object();
	glCullFace( GL_BACK );
	/*   glEnable( GL_CULL_FACE );*/
	glDisable( GL_DITHER );
	glShadeModel( GL_FLAT );
	/*   glEnable( GL_DEPTH_TEST ); */

	Xrot = Yrot = Zrot = 0.0;
	Xstep = Step;
	Ystep = Zstep = 0.0;
}

void reshape( int width, int height )
{
	glViewport(0, 0, (GLint)width, (GLint)height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustum( -1.0, 1.0, -1.0, 1.0, 5.0, 15.0 );
	glMatrixMode(GL_MODELVIEW);
}

void draw( void )
{
	glClear( GL_COLOR_BUFFER_BIT );

	glPushMatrix();

	glTranslatef( 0.0, 0.0, -10.0 );
	glScalef( Scale, Scale, Scale );
	if (Xstep) {
		glRotatef( Xrot, 1.0, 0.0, 0.0 );
	}
	else if (Ystep) {
		glRotatef( Yrot, 0.0, 1.0, 0.0 );
	}
	else {
		glRotatef( Zrot, 0.0, 0.0, 1.0 );
	}

	glCallList( Object );

	glPopMatrix();

	glFlush();
	//tkSwapBuffers();
}

void idle( void )
{
   Xrot += Xstep;
   Yrot += Ystep;
   Zrot += Zstep;

   if (Xrot>=360.0) {
      Xrot = Xstep = 0.0;
      Ystep = Step;
   }
   else if (Yrot>=360.0) {
      Yrot = Ystep = 0.0;
      Zstep = Step;
   }
   else if (Zrot>=360.0) {
      Zrot = Zstep = 0.0;
      Xstep = Step;
   }
   draw();
}



int APIENTRY _tWinMain(HINSTANCE hInstance,
					   HINSTANCE hPrevInstance,
					   LPTSTR    lpCmdLine,
					   int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	// TODO: Place code here.
	//OutputDebugString(L"My output string.\n");
//	ostgl_create_context(320,240,16,buffers,2);

//	init();
	

	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_TESTTINYGL, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TESTTINYGL));

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TESTTINYGL));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_TESTTINYGL);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	HWND hWnd;

	hInst = hInstance; // Store instance handle in our global variable

	hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	if (!hWnd)
	{
		return FALSE;
	}

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message)
	{
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		// TODO: Add any drawing code here...
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

#if 0

/* spin.c */


/*
* Spinning box.  This program is in the public domain.
*
* Brian Paul
*/


#include <math.h>
#include <stdio.h>

#include <GL/glx.h> 
#include <GL/gl.h> 
#include "ui.h"




static GLfloat Xrot, Xstep;
static GLfloat Yrot, Ystep;
static GLfloat Zrot, Zstep;
static GLfloat Step = 5.0;
static GLfloat Scale = 1.0;
static GLuint Object;




static GLuint make_object( void )
{
	GLuint list;

	list = glGenLists( 1 );

	glNewList( list, GL_COMPILE );

	glBegin( GL_LINE_LOOP );
	glColor3f( 1.0, 1.0, 1.0 );
	glVertex3f(  1.0,  0.5, -0.4 );
	glColor3f( 1.0, 0.0, 0.0 );
	glVertex3f(  1.0, -0.5, -0.4 );
	glColor3f( 0.0, 1.0, 0.0 );
	glVertex3f( -1.0, -0.5, -0.4 );
	glColor3f( 0.0, 0.0, 1.0 );
	glVertex3f( -1.0,  0.5, -0.4 );
	glEnd();

	glColor3f( 1.0, 1.0, 1.0 );

	glBegin( GL_LINE_LOOP );
	glVertex3f(  1.0,  0.5, 0.4 );
	glVertex3f(  1.0, -0.5, 0.4 );
	glVertex3f( -1.0, -0.5, 0.4 );
	glVertex3f( -1.0,  0.5, 0.4 );
	glEnd();

	glBegin( GL_LINES );
	glVertex3f(  1.0,  0.5, -0.4 );   glVertex3f(  1.0,  0.5, 0.4 );
	glVertex3f(  1.0, -0.5, -0.4 );   glVertex3f(  1.0, -0.5, 0.4 );
	glVertex3f( -1.0, -0.5, -0.4 );   glVertex3f( -1.0, -0.5, 0.4 );
	glVertex3f( -1.0,  0.5, -0.4 );   glVertex3f( -1.0,  0.5, 0.4 );
	glEnd();


	glEndList();

	return list;
}



void reshape( int width, int height )
{
	glViewport(0, 0, (GLint)width, (GLint)height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustum( -1.0, 1.0, -1.0, 1.0, 5.0, 15.0 );
	glMatrixMode(GL_MODELVIEW);
}


GLenum key(int k, GLenum mask)
{
	switch (k) {
   case KEY_ESCAPE:
	   exit(0);
	}
	return GL_FALSE;
}


void draw( void )
{
	glClear( GL_COLOR_BUFFER_BIT );

	glPushMatrix();

	glTranslatef( 0.0, 0.0, -10.0 );
	glScalef( Scale, Scale, Scale );
	if (Xstep) {
		glRotatef( Xrot, 1.0, 0.0, 0.0 );
	}
	else if (Ystep) {
		glRotatef( Yrot, 0.0, 1.0, 0.0 );
	}
	else {
		glRotatef( Zrot, 0.0, 0.0, 1.0 );
	}

	glCallList( Object );

	glPopMatrix();

	glFlush();
	tkSwapBuffers();
}


void idle( void )
{
	Xrot += Xstep;
	Yrot += Ystep;
	Zrot += Zstep;

	if (Xrot>=360.0) {
		Xrot = Xstep = 0.0;
		Ystep = Step;
	}
	else if (Yrot>=360.0) {
		Yrot = Ystep = 0.0;
		Zstep = Step;
	}
	else if (Zrot>=360.0) {
		Zrot = Zstep = 0.0;
		Xstep = Step;
	}
	draw();
}

void init(void)
{
	Object = make_object();
	glCullFace( GL_BACK );
	/*   glEnable( GL_CULL_FACE );*/
	glDisable( GL_DITHER );
	glShadeModel( GL_FLAT );
	/*   glEnable( GL_DEPTH_TEST ); */

	Xrot = Yrot = Zrot = 0.0;
	Xstep = Step;
	Ystep = Zstep = 0.0;
}


int main( int argc, char *argv[] )
{
	return ui_loop(argc, argv, "spin");
}

#endif