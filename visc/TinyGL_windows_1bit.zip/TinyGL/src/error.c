#include <windows.h>

#include <stdarg.h>
#include "zgl.h"

extern char buff[];
void gl_fatal_error(char *format, ...)
{
  va_list ap;

  va_start(ap,format);

  sprintf(buff,"TinyGL: fatal error: ");OutputDebugString(buff);
  sprintf(buff,format,ap);OutputDebugString(buff);
  sprintf(buff,"\n");OutputDebugString(buff);
  exit(1);

  va_end(ap);
}
