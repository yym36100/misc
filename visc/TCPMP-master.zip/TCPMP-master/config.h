//#define SERIES60
//#define SERIES80
//#define SERIES90
//#define UIQ

//#define CONFIG_SKIN
#define CONFIG_GPL
//#define CONFIG_DEMO

#define CONFIG_AVC
#define CONFIG_AAC
#define CONFIG_MP4
#define CONFIG_AMR
#define CONFIG_AC3
#define CONFIG_FFMPEG
#define CONFIG_MPC
