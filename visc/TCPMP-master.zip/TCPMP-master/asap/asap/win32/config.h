/* config.h for Win32 / x86 / Microsoft Compilers  */

#define STEREO_SOUND 1

#define WORDS_UNALIGNED_OK 1
