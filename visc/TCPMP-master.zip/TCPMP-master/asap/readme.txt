ASAP plugin for The Core Pocket Media Player

using ASAP (Another Slight Atari Player)
http://asap.sourceforge.net

TCPMP plugins:
http://www.tcpmp.com
