#include <stdio.h>
#include <stdint.h>
#include "stm32f4xx_hal.h"


extern UART_HandleTypeDef huart1;


struct __FILE { int handle;  };
FILE __stdout= {0};
FILE __stdin = {1};

FILE __stduart2 = {2};
FILE __stdspi2 = {3};


int fputc(int ch, FILE *f) {
	uint8_t a = ch;	
	switch(f->handle)
	{
		case 0:
		case 2:
			HAL_UART_Transmit(&huart1,&a,1,20);
			break;		
	}	
	return ch;
}

int fgetc( FILE *f){
	uint8_t res = 0;
	switch(f->handle){
		case 1:
		case 2:
			HAL_UART_Receive(&huart1,&res,1,HAL_MAX_DELAY);
		    //HAL_UART_Transmit(&huart1,&res,1,20);
	}
	return res;
}
