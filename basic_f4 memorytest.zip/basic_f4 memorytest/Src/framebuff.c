#include <stdint.h>

uint32_t frame_buffer_ram[320*240];