#include <stdint.h>

uint32_t ccm_ram[64 * 1024/4];