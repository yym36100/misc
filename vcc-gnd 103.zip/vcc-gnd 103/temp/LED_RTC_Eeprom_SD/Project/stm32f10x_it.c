
#include "stm32f10x_it.h"
#include "RTC_Time.h" 
#include "led.h"

void NMI_Handler(void) {}

void HardFault_Handler(void) {
    while (1);
}

void MemManage_Handler(void) {
    while (1);
}

void BusFault_Handler(void){
    while (1);
}

void UsageFault_Handler(void) {
    while (1);
}

void SVC_Handler(void) {}

void DebugMon_Handler(void) {}

void PendSV_Handler(void) {}

void SysTick_Handler(void) {}

void RTC_IRQHandler(void) {
    static uint8_t Display;
    if (RTC_GetITStatus(RTC_IT_SEC) != RESET) {
        RTC_ClearITPendingBit(RTC_IT_SEC);

        if (Display)  {

            LED1_ONOFF(Bit_RESET);
            LED2_ONOFF(Bit_RESET);
            LED3_ONOFF(Bit_RESET);
        }
        else {

            LED1_ONOFF(Bit_SET);
            LED2_ONOFF(Bit_SET);
            LED3_ONOFF(Bit_SET);
        }
        Display = ~Display;
        Time_Display();
    }
}
