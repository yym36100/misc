
#include "stm32f10x.h"
#include "led.h"
#include "usart.h"
#include "i2c.h"
#include "RTC_Time.h"
#include "sdio_sdcard.h"
#include <stdio.h>

void Delay_ms(uint16_t time_ms);

int main(void) {
    uint16_t Addr;
    uint8_t WriteBuffer[256], ReadBuffer[256];
    SD_Error Status = SD_OK;
    USART1_Config();
    I2C_Configuration();
    NVIC_Configuration();
    Status = SD_Init();
    for (Addr = 0; Addr < 256; Addr++) {
        WriteBuffer[Addr] = Addr;	 /* ���WriteBuffer */
    }
    /* Start writing data to the EEPROM */
    printf("\r\n Fill in the data \r\n");
    for (Addr = 0; Addr < 256; Addr++)
        while (!I2C_WriteByte(WriteBuffer[Addr], Addr, ADDR_24C08));
    printf("\r\n EEPROM write data \r\n");

    /* EEPROM read data */
    I2C_ReadByte(ReadBuffer, sizeof(WriteBuffer), 0, ADDR_24C08);
    printf("\r\n EEPROM read data \r\n");

    if (memcmp(WriteBuffer, ReadBuffer, 256) == 0) {
        printf("\r\n EEPROM 24C08 test OK\r\n");
        LED_GPIO_Config();// init LED
    } else {
        printf("\r\n EEPROM 24C08 Read Test False\r\n");
    }
    if (Status == SD_OK) {
        printf(" \r\n SD_Init Initialized successfully \r\n ");
        RTC_Init();
    }

    while (1);    
}

void Delay_ms(uint16_t time_ms) {
    uint16_t i, j;
    for (i = 0; i < time_ms; i++) {
        for (j = 0; j < 10309; j++);
    }
}
