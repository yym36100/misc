
#include "RTC_Time.h" 

void Time_Set(u32 t);

struct tm Time_ConvUnixToCalendar(time_t t) {
    struct tm *t_tm;
    t_tm = localtime(&t);
    t_tm->tm_year += 1900;
    return *t_tm;
}

time_t Time_ConvCalendarToUnix(struct tm t){
    t.tm_year -= 1900;
    return mktime(&t);
}

time_t Time_GetUnixTime(void) { return (time_t)RTC_GetCounter(); }

struct tm Time_GetCalendarTime(void) {
    time_t t_t;
    struct tm t_tm;

    t_t = (time_t)RTC_GetCounter();
    t_tm = Time_ConvUnixToCalendar(t_t);
    return t_tm;
}

void Time_SetUnixTime(time_t t) {
    RTC_WaitForLastTask();
    RTC_SetCounter((u32)t);
    RTC_WaitForLastTask();
    return;
}

void Time_SetCalendarTime(struct tm t) { Time_SetUnixTime(Time_ConvCalendarToUnix(t)); }


static void NVIC_Configuration(void) {
    NVIC_InitTypeDef NVIC_InitStructure;

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);

    NVIC_InitStructure.NVIC_IRQChannel = RTC_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

static void RTC_Configuration(void) {

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);

    PWR_BackupAccessCmd(ENABLE);
    BKP_DeInit();
    RCC_LSEConfig(RCC_LSE_ON);
    while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET);

    RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
    RCC_RTCCLKCmd(ENABLE);
    RTC_WaitForSynchro();
    RTC_WaitForLastTask();
    RTC_ITConfig(RTC_IT_SEC, ENABLE);
    RTC_WaitForLastTask();
    RTC_SetPrescaler(32767); /* RTC period = RTCCLK/RTC_PR = (32.768 KHz)/(32767+1) */
    RTC_WaitForLastTask();
}

static uint16_t USART_Scanf(uint32_t min_value, uint32_t max_value, uint8_t lenght) {
    uint16_t index = 0;
    uint32_t tmp[4] = { 0, 0, 0, 0 };

    while (index < lenght) {
        while (USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == RESET);

        tmp[index++] = (USART_ReceiveData(USART1));

        if (tmp[index - 1] == 0x0D) { index--; continue; }

        if ((tmp[index - 1] < 0x30) || (tmp[index - 1] > 0x39)) {
            printf("Please enter valid number between 0 and 9\r\n");
            index--;
        }
    }

    if (lenght == 2)
        index = (tmp[1] - 0x30) + ((tmp[0] - 0x30) * 10);

    else
        index = (tmp[3] - 0x30) + ((tmp[2] - 0x30) * 10) + ((tmp[1] - 0x30) * 100) + ((tmp[0] - 0x30) * 1000);

    if (index > max_value || index < min_value) {
        printf("Please enter valid number between %d and %d\r\n", min_value, max_value);
        return 0;
    }
    return index;
}

void Time_Regulate(void) {
    struct tm time;

    memset(&time, 0, sizeof(time));

    printf("=======================RTC time date setting ==========================\r\n");
    printf("Please enter the year between 1970 and 2037\r\n");
    time.tm_year = 2013;
    time.tm_mon = 10;
    time.tm_mday = 13;
    time.tm_hour = 02;
    time.tm_min = 30;
    time.tm_sec = 21;

    //  while ( time.tm_year>2037  || time.tm_year<1970)
    //  {   
    //    time.tm_year = USART_Scanf(1970,2037,4);
    //  }
    //  printf("�趨�����Ϊ:  %d\r\n", time.tm_year);

    //  printf("�������·���01 �� 12֮��\r\n");
    //  while (time.tm_mon >12 || time.tm_mon < 1 )
    //  {
    //    time.tm_mon= USART_Scanf(1,12,2)-1;
    //  }
    //  printf("�趨���·�:  %d\r\n", time.tm_mon);

    //  printf("������������01 �� 31֮��\r\n");
    //  while (time.tm_mday >31 ||time.tm_mday <1 )
    //  {
    //    time.tm_mday = USART_Scanf(1,31,2);
    //  }
    //  printf("�趨������Ϊ:  %d\r\n", time.tm_mday);

    //  printf("������Сʱ�� 01 �� 23֮��\r\n");
    //  while (time.tm_hour >23 ||time.tm_hour <1 )
    //  {
    //    time.tm_hour = USART_Scanf(1,23,2);
    //  }
    //  printf("���õ�СʱΪ:  %d\r\n", time.tm_hour);

    //  printf("����������� 01 �� 59\r\n");
    //  while (time.tm_min >59 || time.tm_min <1 )
    //  {
    //    time.tm_min = USART_Scanf(1,59,2);
    //  }
    //  printf("���õķ���Ϊ:  %d\r\n", time.tm_min);

    //  printf("������������ 01 �� 59֮��\r\n");
    //  while (time.tm_sec >59 || time.tm_sec <1 )
    //  {
    //    time.tm_sec = USART_Scanf(1,59,2);
    //  }
    //  printf("���õ�����Ϊ:  %d\r\n", time.tm_sec);
    /* Return the value to store in RTC counter register */
    Time_SetCalendarTime(time);
}

void RTC_Init(void) {

    if (BKP_ReadBackupRegister(BKP_DR1) != 0xA5A5)  {

        printf("RTC has not been set ...\r\n");
        RTC_Configuration();
        Time_Regulate();
        printf("RTC initialization....\r\n");
        BKP_WriteBackupRegister(BKP_DR1, 0xA5A5);
    }
    else {

        if (RCC_GetFlagStatus(RCC_FLAG_PORRST) != RESET){
            printf("A power-on restart occurs ...\r\n");
        }
        else if (RCC_GetFlagStatus(RCC_FLAG_PINRST) != RESET) {
            printf("An external reset occurs ...\r\n");
        }

        printf("Do not need to set up RTC ...\r\n");

        RTC_WaitForSynchro();
        RTC_ITConfig(RTC_IT_SEC, ENABLE);
        RTC_WaitForLastTask();
    }

    NVIC_Configuration();

#ifdef RTCClockOutput_Enable

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
    PWR_BackupAccessCmd(ENABLE);
    BKP_TamperPinCmd(DISABLE);
    BKP_RTCOutputConfig(BKP_RTCOutputSource_CalibClock);
#endif

    RCC_ClearFlag();
    return;
}

void Time_Display(void) {
    struct tm time;
    time = Time_GetCalendarTime();
    printf("Time: %d-%d-%d   %02d:%02d:%02d \r\n", time.tm_year, time.tm_mon + 1, time.tm_mday, time.tm_hour, time.tm_min, time.tm_sec);
}
