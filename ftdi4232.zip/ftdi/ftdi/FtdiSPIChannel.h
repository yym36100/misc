#pragma once

#include <string>
//#include <afx.h>

class CFtdiSPIChannel
{
public:
	CFtdiSPIChannel(void);
	~CFtdiSPIChannel(void);
	std::string m_cstr_ChannelName;
	unsigned long m_ul_ChannelIndex;
};
