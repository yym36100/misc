// ftdi.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

typedef long int32_t;
typedef unsigned long uint32_t;

#include <windows.h>
#include "FTD2XX.H"
//#include "libMPSSE_spi.h"
#include "ftdi4232.h"

#define FOO(...) printf(__VA_ARGS__)

int _tmain(int argc, _TCHAR* argv[])
{
	DWORD n;
	FT_CreateDeviceInfoList(&n);
	printf("n= %d\n",n);

	FT_DEVICE_LIST_INFO_NODE devInfo[4];
	FT_GetDeviceInfoList(devInfo,&n);
	for(int i=0;i<4;i++){
		FOO("Dev %d:			\n"			,i);
		printf(" Flags=0x%x			\n",devInfo[i].Flags);
		printf(" Type=0x%x			\n",devInfo[i].Type);			
		printf(" ID=0x%x			\n",devInfo[i].ID);
		printf(" LocId=0x%x			\n",devInfo[i].LocId);
		printf(" SerialNumber=%s			\n",devInfo[i].SerialNumber);
		printf(" Description=%s			\n",devInfo[i].Description);
		printf(" ftHandle=0x%x			\n",devInfo[i].ftHandle); 
	}
	uint32_t noChan = 0;
//	SPI_GetNumChannels(&noChan);
	printf("no spi = %d\n",noChan);

	CFTDI4232 myftdi;
	myftdi.AcquireSPIChannel(0);
	myftdi.ConfigureChannel(4,5,1000000);

	unsigned char buffer[]="abcdabcdefghijkl";

	for(int i=0;i<1;i++){
	printf("write...\n");
	myftdi.Write((unsigned char*)(buffer+4),10);
	//Sleep(3);
	}
	//myftdi.SetCSandRead(buffer,3);
	
#if 0
	for(int i=0;i<10;i++){
	myftdi.SetCS();
	//Sleep(1);
	myftdi.ClearCS();
//	Sleep(1);

	}
#endif	
	//Sleep(3);
	myftdi.ReleaseSPIChannel();

	return 0;
}

