#include "StdAfx.h"
#include "FTDI4232.h"

#define MAXWRITEBYTES 65536
#define MAXREADBYTES 65536

CFTDI4232::CFTDI4232(void)
{
	m_fth_ChannelHandle = NULL;
	m_bo_ChannelAcquired = false;
	m_uc_CSPinMask = 0;
	m_uc_RDYPinMask = 0;
	m_uc_DirectionMask = 0;
	m_cstr_LastError = "No error";
}

CFTDI4232::~CFTDI4232(void)
{
}

void CFTDI4232::GetAvailableChannels(vector<CFtdiSPIChannel*>* list)
{
	DWORD dwNumDevs = 0;
	FT_DEVICE_LIST_INFO_NODE* devInfo;
	CFtdiSPIChannel* newchannel = NULL;

	list->clear(); //clear list

	if(FT_CreateDeviceInfoList(&dwNumDevs) != FT_OK)
	{
		return;
	}
	
	devInfo = new FT_DEVICE_LIST_INFO_NODE[dwNumDevs];
	
	if(FT_GetDeviceInfoList(devInfo, &dwNumDevs) != FT_OK)
	{
		delete[] devInfo;
		return;
	}

	for(unsigned long index = 0; index < dwNumDevs; index++)
	{
		/*if(devInfo[index].SerialNumber[0] == 'A' || devInfo[index].SerialNumber[0] == 'B')
		{*/
			newchannel = new CFtdiSPIChannel();
			list->push_back(newchannel);
						
			newchannel->m_cstr_ChannelName = devInfo[index].Description;			
			newchannel->m_ul_ChannelIndex = index;
		/*}*/
	}

	delete[] devInfo;
}

bool CFTDI4232::AcquireSPIChannel(unsigned long channelindex)
{
	if(m_bo_ChannelAcquired)
	{
		m_cstr_LastError = "Channel was not released";
		return false;
	}
	if(FT_Open(channelindex, &m_fth_ChannelHandle) != FT_OK)
	{
		m_cstr_LastError = "Could not acquire SPI channel";
		return false;
	}

	FT_STATUS ftstatus = FT_OK;
	DWORD dwNumBytesInBuffer = 0;
	DWORD dwNumBytesRead = 0;
	DWORD dwNumBytesWrite = 0;
	unsigned char chByteRead = 0;
	unsigned long uiIndex;
	unsigned char chCommandBuffer[6];

	ftstatus |= FT_ResetDevice(m_fth_ChannelHandle);
	ftstatus |= FT_Purge(m_fth_ChannelHandle, FT_PURGE_RX | FT_PURGE_TX);
	ftstatus |= FT_GetQueueStatus(m_fth_ChannelHandle, &dwNumBytesInBuffer);
	for(uiIndex = 0; (uiIndex < dwNumBytesInBuffer) && (FT_SUCCESS(ftstatus)); uiIndex)
	{
		ftstatus |= FT_Read(m_fth_ChannelHandle, &chByteRead, 1, &dwNumBytesRead);
	}
	ftstatus |= FT_SetUSBParameters(m_fth_ChannelHandle, 65536, 65535);
	ftstatus |= FT_SetChars(m_fth_ChannelHandle, 0, 0, 0, 0);
	ftstatus |= FT_SetTimeouts(m_fth_ChannelHandle, 5000, 5000);
	ftstatus |= FT_SetLatencyTimer(m_fth_ChannelHandle, 1);
	ftstatus |= FT_SetFlowControl(m_fth_ChannelHandle, FT_FLOW_NONE, 0, 0);
	ftstatus |= FT_SetBitMode(m_fth_ChannelHandle, 0x00, 0x00);  //Reset controller
	Sleep(100);
	ftstatus |= FT_SetBitMode(m_fth_ChannelHandle, 0x00, 0x02);  //Configure MPSSE mode
	Sleep(100);

	chCommandBuffer[0] = 0x8A; //disable CLK divide by 5
	chCommandBuffer[1] = 0x8D; //disable 3 phase data clocking
	chCommandBuffer[2] = 0x97; //disable adaptive clocking
	chCommandBuffer[3] = 0x80; //configure pins
	chCommandBuffer[4] = 0x00; //set all pins to 0 (must give a value but the pins will be configured as inputs)
	chCommandBuffer[5] = 0x00; //set all pins as inputs
	ftstatus |= FT_Write(m_fth_ChannelHandle, chCommandBuffer, 6, &dwNumBytesWrite);
	ftstatus |= FT_Purge(m_fth_ChannelHandle, FT_PURGE_RX | FT_PURGE_TX);

	if(!FT_SUCCESS(ftstatus))
	{
		m_cstr_LastError = "Could not initialize the SPI channel";
		FT_Close(m_fth_ChannelHandle);
		m_fth_ChannelHandle = NULL;
		return false;
	}
	m_bo_ChannelAcquired = true;
	return true;
}
bool CFTDI4232::ReleaseSPIChannel(void)
{
	if(!m_bo_ChannelAcquired)
	{
		m_cstr_LastError = "No channel was acquired";
		return false;
	}

	unsigned char chCommandBuffer[3];
	DWORD dwNumBytesWrite = 0;
	chCommandBuffer[0] = 0x80; //configure pins
	chCommandBuffer[1] = 0x00; //set all pins to 0 (must give a value but the pins will be configured as inputs)
	chCommandBuffer[2] = 0x00; //set all pins as inputs
	FT_Write(m_fth_ChannelHandle, chCommandBuffer, 3, &dwNumBytesWrite);

	m_bo_ChannelAcquired = false;

	if(!FT_SUCCESS(FT_Close(m_fth_ChannelHandle)))
	{
		m_cstr_LastError = "Could not release SPI channel";
		return false;
	}
	return true;
}

bool CFTDI4232::ConfigureChannel(unsigned long cspin, unsigned long rdypin, unsigned long baudrate)
{
	/*if(!m_bo_ChannelAcquired)
	{
		m_cstr_LastError = "No channel was acquired";
		return false;
	}*/
	//ToDo: verify that the pin values are valid
	m_uc_CSPinMask = ((unsigned char) 1) << (cspin);
	m_uc_RDYPinMask = ((unsigned char) 1) << (rdypin);
	m_uc_DirectionMask = 0x03 | m_uc_CSPinMask; //direction 0=input 1=output

	unsigned char chCommandBuffer[6];
	double dDivisor = (((double)60000000) / ((double)((double)(baudrate) * (double)2))) - 1;
	DWORD dwNumBytesWrite = 0;

	chCommandBuffer[0] = 0x80; //MPSSE command to configure low byte port pins
	chCommandBuffer[1] = m_uc_CSPinMask | 0x01; //low byte pins state=High or Low	
	chCommandBuffer[2] = m_uc_DirectionMask; //low byte pins direction=Input or Output
	chCommandBuffer[3] = 0x86; //set clock divisor
	chCommandBuffer[4] = (unsigned char)(((DWORD)dDivisor >> 0) & 0xFF);
	chCommandBuffer[5] = (unsigned char)(((DWORD)dDivisor >> 8) & 0xFF);

	if((!FT_SUCCESS(FT_Write(m_fth_ChannelHandle, chCommandBuffer, 6, &dwNumBytesWrite))) || (dwNumBytesWrite != 6))
	{
		m_cstr_LastError = "Could not configure baudrate, CS and RDY pins";
		return false;
	}
	return true;
}

bool CFTDI4232::SetCS(void)
{
	/*if(!m_bo_ChannelAcquired)
	{
		m_cstr_LastError = "No channel was acquired";
		return false;
	}*/

	BYTE chCommandBuffer[3];
	DWORD dwNumBytesWrite;

	chCommandBuffer[0] = 0x80;//MPSSE command to configure low byte port pins
	chCommandBuffer[1] = 0x01;//low byte pins state=High or Low	
	chCommandBuffer[2] = m_uc_DirectionMask; //low byte pins direction=Input or Output
	if((!FT_SUCCESS(FT_Write(m_fth_ChannelHandle, chCommandBuffer, 3, &dwNumBytesWrite))) || (dwNumBytesWrite != 3))
	{
		m_cstr_LastError = "Could not set CS line";
		return false;
	}
	return true;
}
bool CFTDI4232::ClearCS(void)
{
	/*if(!m_bo_ChannelAcquired)
	{
		m_cstr_LastError = "No channel was acquired";
		return false;
	}*/

	BYTE chCommandBuffer[3];
	DWORD dwNumBytesWrite;	
	
	chCommandBuffer[0] = 0x80;//MPSSE command to configure low byte port pins
	chCommandBuffer[1] = m_uc_CSPinMask | 0x01;//low byte pins state=High or Low	
	chCommandBuffer[2] = m_uc_DirectionMask;    //low byte pins direction=Input or Output
	
	if((!FT_SUCCESS(FT_Write(m_fth_ChannelHandle, chCommandBuffer, 3, &dwNumBytesWrite))) || (dwNumBytesWrite != 3))
	{
		m_cstr_LastError = "Could not clear CS line";
		return false;
	}

	return true;
}

bool CFTDI4232::WaitClearRDY_ClearCS(void)
{
	BYTE chCommandBuffer[4];
	DWORD dwNumBytesWrite;	
	
	chCommandBuffer[0] = 0x89;//wait RDY low
	chCommandBuffer[1] = 0x80;//MPSSE command to configure low byte port pins
	chCommandBuffer[2] = m_uc_CSPinMask | 0x01;//low byte pins state=High or Low	
	chCommandBuffer[3] = m_uc_DirectionMask;    //low byte pins direction=Input or Output
	
	if((!FT_SUCCESS(FT_Write(m_fth_ChannelHandle, chCommandBuffer, 4, &dwNumBytesWrite))) || (dwNumBytesWrite != 4))
	{
		m_cstr_LastError = "Could not wait for RDY and clear CS line";
		return false;
	}

	return true;
}

bool CFTDI4232::WaitSetRDY(void)
{
	BYTE chCommandBuffer[4];
	DWORD dwNumBytesWrite;	
	
	chCommandBuffer[0] = 0x88;//wait RDY high
	
	if((!FT_SUCCESS(FT_Write(m_fth_ChannelHandle, chCommandBuffer, 1, &dwNumBytesWrite))) || (dwNumBytesWrite != 1))
	{
		m_cstr_LastError = "Could not wait for RDY line";
		return false;
	}

	return true;
}
bool CFTDI4232::WaitClerRDY_SetCS_WaitSetRDY(void)
{
	BYTE chCommandBuffer[4];
	DWORD dwNumBytesWrite;	
		
	chCommandBuffer[3] = 0x89;//wait RDY low
	chCommandBuffer[0] = 0x80;//MPSSE command to configure low byte port pins
	chCommandBuffer[1] = 0x01;//low byte pins state=High or Low	
	chCommandBuffer[2] = m_uc_DirectionMask;    //low byte pins direction=Input or Output
	chCommandBuffer[3] = 0x88;//wait RDY high
	
	if((!FT_SUCCESS(FT_Write(m_fth_ChannelHandle, chCommandBuffer, 4, &dwNumBytesWrite))) || (dwNumBytesWrite != 4))
	{
		m_cstr_LastError = "Could not wait for RDY and clear CS line";
		return false;
	}

	return true;
}

bool CFTDI4232::GetRDY(unsigned char* value)
{
	/*if(!m_bo_ChannelAcquired)
	{
		m_cstr_LastError = "No channel was acquired";
		return false;
	}*/

	unsigned char chCommandBuffer;
	DWORD dwBytesProcessed = 0;

	chCommandBuffer = 0x81;//MPSSE command to read low byte pins states	
	
	if((!FT_SUCCESS(FT_Write(m_fth_ChannelHandle, &chCommandBuffer,1, &dwBytesProcessed))) || (dwBytesProcessed != 1))
	{
		m_cstr_LastError = "Could not read RDY line";
		return false;
	}

	dwBytesProcessed = 0;
		
	while((dwBytesProcessed != 1))
	{
		if(!FT_SUCCESS(FT_Read(m_fth_ChannelHandle, &chCommandBuffer, 1, &dwBytesProcessed)))
		{
			m_cstr_LastError = "Could not read RDY line";
			return false;
		}
	}
	*value = (unsigned char)((chCommandBuffer & m_uc_RDYPinMask) == m_uc_RDYPinMask);
	return true;
}

bool CFTDI4232::Write(unsigned char* data, unsigned long length)
{
	/*if(!m_bo_ChannelAcquired)
	{
		m_cstr_LastError = "No channel was acquired";
		return false;
	}*/
	
	DWORD save = 0;
	DWORD dwBytesProcessed = 0;
	/*unsigned long datathistime = length;
	while(length)
	{
		datathistime = length;
		if(datathistime > MAXWRITEBYTES)
		{
			datathistime = MAXWRITEBYTES;
		}*/
		
		save = *((DWORD*)(data - 4)); //save the bytes that is in front of the data buffer (save 4 bytes)

		*(data - 3) = 0x34; //write only - BYTES - positive clock edge
		*(data - 2) = (unsigned char)(length - 1);
		*(data - 1) = (unsigned char)((length - 1) >> 8);
		/**(data - 2) = (unsigned char)(datathistime - 1);
		*(data - 1) = (unsigned char)((datathistime - 1) >> 8);*/
		//wait ! what ? write outside the buffer ? but how ?
		//Elementary my dear Watson... we need a way to also send the write command to the FTDI device (in only
		//one call to FT_Write - because of the speed) and for that we need to put the control bytes somewhere.
		//Why not in front of the data ? Before the segment data in the PRG there is anoter one (or the PRG header)
		//so we know that the memory is allocated and writable. We can use it and then restore it.
		//I know that this is a "hack" but it saves time by not copying data from one buffer to another one

		//Send the data

		if((!FT_SUCCESS(FT_Write(m_fth_ChannelHandle, (data - 3), length /* datathistime*/ + 3, &dwBytesProcessed))) || (dwBytesProcessed != (/*datathistime*/ length + 3)))
		{
			m_cstr_LastError = "Could not write to SPI channel";
			*((DWORD*)(data - 4)) = save; //restore the bytes
			return false;
		}
		DWORD res = 0;
		FT_SetTimeouts(m_fth_ChannelHandle, 5, 5);
		FT_Read(m_fth_ChannelHandle,RxBuffer,20,&res);
		RxBuffer[res] = 0;
		printf("no bytes =%d rec =%s\n",res,RxBuffer);

		*((DWORD*)(data - 4)) = save; //restore the bytes

		/*length -= datathistime;
		data += datathistime;*/
	/*}*/
	return true;
}

bool CFTDI4232::ComplexWrite(unsigned char* data, unsigned long length)
{
	BYTE chCommandBuffer[16];
	DWORD dwBytesProcessed = 0;

	chCommandBuffer[0] = 0x89;
	chCommandBuffer[1] = 0x80;
	chCommandBuffer[2] = 0x01;//low byte pins state=High or Low
	chCommandBuffer[3] = m_uc_DirectionMask;    //low byte pins direction=Input or Output
	chCommandBuffer[4] = 0x88; //wait RDY line high
	chCommandBuffer[5] = 0x10; //write only - BYTES - positive clock edge
	chCommandBuffer[6] = (unsigned char)(length - 1);
	chCommandBuffer[7] = (unsigned char)((length - 1) >> 8);

	//Send the command
	if((!FT_SUCCESS(FT_Write(m_fth_ChannelHandle, chCommandBuffer, 8, &dwBytesProcessed))) || (dwBytesProcessed != 8))
	{
		m_cstr_LastError = "Could not write to SPI channel";		
		return false;
	}
	//Send the data
	if((!FT_SUCCESS(FT_Write(m_fth_ChannelHandle, data, length, &dwBytesProcessed))) || (dwBytesProcessed != length))
	{
		m_cstr_LastError = "Could not write to SPI channel";		
		return false;
	}

	chCommandBuffer[0] = 0x89; //wait RDY line low
	chCommandBuffer[1] = 0x80;//MPSSE command to configure low byte port pins
	chCommandBuffer[2] = m_uc_CSPinMask | 0x01;//low byte pins state=High or Low
	chCommandBuffer[3] = m_uc_DirectionMask;    //low byte pins direction=Input or Output
	Sleep(2);
	//Send the command
	if((!FT_SUCCESS(FT_Write(m_fth_ChannelHandle, chCommandBuffer, 4, &dwBytesProcessed))) || (dwBytesProcessed != 4))
	{
		m_cstr_LastError = "Could not write to SPI channel";		
		return false;
	}	
	return true;
}

bool CFTDI4232::ComplexRead(unsigned char* data, unsigned long length, unsigned long timeout)
{	
	BYTE chCommandBuffer[16];
	DWORD dwBytesProcessed =0;

	chCommandBuffer[0] = 0x88;   //wait RDY 1
	chCommandBuffer[1] = 0x80;   //Set CS
	chCommandBuffer[2] = 0x01;   //Set CS
	chCommandBuffer[3] = m_uc_DirectionMask; //Set CS
	chCommandBuffer[4] = 0x20; //read only - BYTES - positive clock edge
	chCommandBuffer[5] = (BYTE)((length - 1));  //read
	chCommandBuffer[6] = (BYTE)(((length - 1) >> 8));  //read
	chCommandBuffer[7] = 0x89;  //wait RDY 0
	chCommandBuffer[8] = 0x80;  //Clear CS
	chCommandBuffer[9] = m_uc_CSPinMask | 0x01; //Clear CS
	chCommandBuffer[10] = m_uc_DirectionMask;  //Clear CS

	
	if((!FT_SUCCESS(FT_Write(m_fth_ChannelHandle, chCommandBuffer, 11, &dwBytesProcessed))) ||
		(dwBytesProcessed != 11))
	{
		m_cstr_LastError = "Could not send WRITE command to SPI channel";
		return false;
	}
	FT_SetTimeouts(m_fth_ChannelHandle, timeout, timeout);
	if((!FT_SUCCESS(FT_Read(m_fth_ChannelHandle, data, length, &dwBytesProcessed))) ||
		(dwBytesProcessed != length))
	{
		m_cstr_LastError = "Could not read from SPI channel";
		return false;
	}
	return true;
}

bool CFTDI4232::SetCSandRead(unsigned char* data, unsigned long length)
{
	//if(!m_bo_ChannelAcquired)
	//{
	//	m_cstr_LastError = "No channel was acquired";
	//	return false;
	//}
	
	BYTE chCommandBuffer[7];
	DWORD dwBytesProcessed =0;
	unsigned long lengththistime = length;
	unsigned long uiCSnotset = 1;

	chCommandBuffer[0] = 0x80;
	chCommandBuffer[1] = 0x01;
	chCommandBuffer[2] = m_uc_DirectionMask;

	while(length)
	{
		lengththistime = length;
		if(lengththistime > MAXREADBYTES)
		{
			lengththistime = MAXREADBYTES;
		}

		chCommandBuffer[uiCSnotset * 3 + 0] = 0x20; //read only - BYTES - positive clock edge
		chCommandBuffer[uiCSnotset * 3 + 1] = (BYTE)((lengththistime - 1) & 0xFF);
		chCommandBuffer[uiCSnotset * 3 + 2] = (BYTE)(((lengththistime - 1) >> 8));
		
		if((!FT_SUCCESS(FT_Write(m_fth_ChannelHandle, chCommandBuffer, uiCSnotset * 3 + 3, &dwBytesProcessed))) ||
			(dwBytesProcessed != (uiCSnotset * 3 + 3)))
		{
			m_cstr_LastError = "Could not send WRITE command to SPI channel";
			return false;
		}

		uiCSnotset ^= uiCSnotset; //set uiCSnotset to 0; (faster than an if)
		
		if((!FT_SUCCESS(FT_Read(m_fth_ChannelHandle, data, lengththistime, &dwBytesProcessed))) ||
			(dwBytesProcessed != lengththistime))
		{
			m_cstr_LastError = "Could not read from SPI channel";
			return false;
		}

		data += lengththistime;
		length -= lengththistime;
	}
	
	return true;
}


std::string CFTDI4232::GetLastError(void)
{
	return m_cstr_LastError;
}
