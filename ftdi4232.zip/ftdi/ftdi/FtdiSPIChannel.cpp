#include "StdAfx.h"
#include "FtdiSPIChannel.h"

CFtdiSPIChannel::CFtdiSPIChannel(void)
{
}

CFtdiSPIChannel::~CFtdiSPIChannel(void)
{
}
