#pragma once

#include "..\CDM_v2.10.00_WHQL_Certified\ftd2xx.h"
#include "FtdiSPIChannel.h"
#include <vector>

using namespace std;

class CFTDI4232
{
public:
	CFTDI4232(void);
	~CFTDI4232(void);
	bool AcquireSPIChannel(unsigned long channelindex);
	bool ReleaseSPIChannel(void);
	bool ConfigureChannel(unsigned long cspin, unsigned long rdypin, unsigned long baudrate);
	bool SetCS(void);
	bool ClearCS(void);
	bool GetRDY(unsigned char* value);
	bool Write(unsigned char* data, unsigned long length);
	bool SetCSandRead(unsigned char* data, unsigned long length);
	bool ComplexWrite(unsigned char* data, unsigned long length);
	bool ComplexRead(unsigned char* data, unsigned long length, unsigned long timeout);
	bool WaitClearRDY_ClearCS(void);
	bool WaitSetRDY(void);
	bool WaitClerRDY_SetCS_WaitSetRDY(void);
	static void GetAvailableChannels(vector<CFtdiSPIChannel*>* list);

	CString GetLastError(void);

private:
	FT_HANDLE m_fth_ChannelHandle;
	bool m_bo_ChannelAcquired;
	unsigned char m_uc_CSPinMask;
	unsigned char m_uc_RDYPinMask;
	unsigned char m_uc_DirectionMask;
	CString m_cstr_LastError;
};
