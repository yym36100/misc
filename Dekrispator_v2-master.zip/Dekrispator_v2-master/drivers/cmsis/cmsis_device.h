//
// This file is part of the µOS++ III distribution.
// Copyright (c) 2014 Liviu Ionescu.
//

#ifndef STM32F4_CMSIS_DEVICE_H_
#define STM32F4_CMSIS_DEVICE_H_

#include "stm32f4xx.h"

#endif // STM32F4_CMSIS_DEVICE_H_
