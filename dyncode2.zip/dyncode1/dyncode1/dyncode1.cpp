#include <stdio.h>


typedef unsigned char u8;
typedef unsigned short u16;

//user data, this can be changed
u8 data[][2]={{3,1},{20,5},{7,4},{1,1}};


// the program demonstrates simple addition and subtraction
// start WTF -------------------------------------------------------
char wtf_text[] = "open source  ;-)";
char wtf_code[] = ":\373\211a\2266gz\304.i#\341f\356)\0";

#define wtf_init() for(u8 i=0;i<sizeof(wtf_text);i++)i[wtf_text]^=i[wtf_code]
#define wtf_setoperation(ch) '\13'[wtf_text]=(ch-'\53')*'\24'|'\3';
#define wtf_evaluate(a,b) ((u16(*)(u8,u8))(&0[wtf_text]))(a,b)
// end WTF -------------------------------------------------------

void myfunc(char a)
{
	printf("%c\n",a);
}

int addr = 0x004113b0;
// back to simple C
int main(int argc, char* argv[])
{
	wtf_init();

	// perform additions and subtracitons on the data array
	wtf_setoperation('+'); 
	for(u8 i=0;i<sizeof(data)/2;i++)
		printf("%d+%d=%d\n",data[i][0],data[i][1],wtf_evaluate(data[i][0],data[i][1]));
	wtf_setoperation('-'); 
	for(u8 i=0;i<sizeof(data)/2;i++)
		printf("%d-%d=%d\n",data[i][0],data[i][1],wtf_evaluate(data[i][0],data[i][1]));

	//myfunc(1);
	(*(void(*)(char))(0x004113b0))('B');

	return 0;
}

/*
Output:
3+1=4
20+5=25
7+4=11
1+1=2
3-1=2
20-5=15
7-4=3
1-1=0
*/

