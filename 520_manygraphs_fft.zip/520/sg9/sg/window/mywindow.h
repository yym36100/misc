#pragma once
#include "window5.h"

//widgets
#include "textwidget.h"
#include "GraphWidget.h"
#include "GraphWidget2.h"
#include "slider.h"
#include "button.h"

#include "Sound.h"

namespace sg{

	class Cmywindow;
	class CFFTSound : public  snd::CWaveSound {
	private:
		typedef snd::CWaveSound super;
	public:
		Cmywindow *w;
		double skval;

		CFFTSound() :CWaveSound(),skval(200) {}

		virtual bool GetSignal(void) {
			bool res = true;

			res = super::GetSignal();			
			return res;
		}

		void UpdateGraph(void);		
	};

	class complex{
	public:
		double r,i;
		complex():r(0),i(0){}
		complex(double a,double b) : r(a),i(b){}

		complex& operator=(complex a ){
			r=a.r;
			i=a.i;
			return *this;
		}

		complex& operator+=(complex a ){
			return operator+(a);
		}

		complex operator+ (complex &a){			
			r = a.r+r;
			i = a.i+i;
			return *this;
		}

		complex operator* (complex &a){
			complex res;			
			res.r = a.r*r-a.i*i;
			res.i = a.i*r+a.r*i;
			r=res.r;
			i=res.i;
			return *this;
		}
	};

	class Cmywindow : public CWindow {
	public:
		wg::CWidget *w;
		double *signal;
		double *pwr;
		complex *fft_res;
		double *rr,*ii, *phase;

		void SigGen2(double *buf,double freq = 1,double phase = 0, int len = 100) {

			for(int i=0;i<len;i++) {


				buf[i] = .25*sin(2*3.1415*i*(freq)/(double)len+phase);
				buf[i] +=.0125*sin(2*3.1415*i*16.0/(double)len+ phase/2);
				buf[i] +=.0125*sin(2*3.1415*i*32.0/(double)len+phase+3.1415);
				buf[i] +=.025*sin(2*3.1415*i*48.0/(double)len+phase*1.5);
				buf[i] +=.025*sin(2*3.1415*i*64.0/(double)len+phase*.5);

				buf[i] +=.025*sin(2*3.1415*i*80/(double)len+phase+3.1415);
				buf[i] +=.0125*sin(2*3.1415*i*96.0/(double)len+phase*3.5);
				buf[i] +=.0125*sin(2*3.1415*i*112.0/(double)len+phase*2.5);

				buf[i] +=.25*rand()/RAND_MAX;

				if(buf[i]>.95) buf[i]*=.95;
				//if(i<len/4) buf[i] = 0;
				//else if(i>3*len/4) buf[i] = 0;
				//else buf[i] = 1;
				/*buf[i] +=.25*sin(2*3.1415*i*10/(double)len);
				buf[i] +=.25*sin(2*3.1415*i*20/(double)len);
				buf[i] +=.25*sin(2*3.1415*i*40/(double)len);*/
				//if(buf[i]>0) buf[i] = 1; else buf[i] = -1;

			}
		}

		void naive_fft(double *in, complex *out, int len=100){

			for(int k=0;k<len;k++){
				complex xk;
				for(int n=0;n<len;n++){
					complex xn(in[n],0);
					complex wn(cos(2*3.1415*k*n/len),-sin(2*3.1415*k*n/len));
					xk+= xn * wn;
				}
				out[k]=xk;
			}
		}

		double powerspec(complex *in,double *out, int len=100){
			double max = 0;
			for(int n=0;n<len;n++){
				out[n] = 20*log(0.0000001+in[n].r*in[n].r + in[n].i*in[n].i);
				if (out[n]<0) out[n] = 0;
				max = out[n]>max ? out[n] : max;
			}

			for(int n=0;n<len;n++){
				out[n] = -out[n]/max*2 + 1;
			}
			return max/len;
		}

		double pphase(complex *in,double *outr, int len=100){

			double maxr = -1000;
			double minr = 1000;

			for(int n=0;n<len;n++){
				outr[n] = atan2(in[n].r,in[n].i);

				maxr = outr[n]>maxr ? outr[n] : maxr;				
				minr = outr[n]<minr ? outr[n] : minr;
			}

			for(int n=0;n<len;n++){
				outr[n] = -(outr[n]-minr)/(maxr-minr)*2 + 1;				
			}
			return 0;			
		}


		double realimag(complex *in,double *outr, double *outi, int len=100){
			double maxr = -1000;
			double minr = 1000;

			double maxi = -1000;
			double mini = 1000;

			for(int n=0;n<len;n++){
				outr[n] = in[n].r;
				outi[n] = in[n].i;

				maxr = outr[n]>maxr ? outr[n] : maxr;
				maxi = outi[n]>maxi ? outi[n] : maxi;

				minr = outr[n]<minr ? outr[n] : minr;
				mini = outi[n]<mini ? outi[n] : mini;
			}

			for(int n=0;n<len;n++){
				outr[n] = -(outr[n]-minr)/(maxr-minr)*2 + 1;
				outi[n] = -(outi[n]-mini)/(maxi-mini)*2 + 1;
			}
			return 0;
		}



		Cmywindow(Rect r, u32 style,HWND parent_hWnd,u16 *name) :
		CWindow( r, style, parent_hWnd, name),w(0)
		{
			wg::CGraphWidget2 *w1,*w2,*w3,*w4,*w5;
#define lll	(256)
			signal = new double[lll];
			pwr = new double [lll];
			SigGen2(signal,49,lll);
			fft_res = new complex[lll];
			naive_fft(signal, fft_res,lll);
			double m=powerspec(fft_res,pwr,lll);

			rr = new double[lll];
			ii = new double[lll];
			phase = new double[lll];

			realimag(fft_res,rr,ii,lll);
			pphase(fft_res,phase,lll);


			w1=new wg::CGraphWidget2(surf,30,10,400,200);
			w2=new wg::CGraphWidget2(surf,30,10+200+10,400,200);		

			w3=new wg::CGraphWidget2(surf,30+410,10,400,200);
			w4=new wg::CGraphWidget2(surf,30+410,10+200+10,400,200);		

			w5=new wg::CGraphWidget2(surf,30+410+410,10+200+10,400,200);		


			w = w1;
			w->Add(w2);

			w->Add(w3);
			w->Add(w4);
			w->Add(w5);

			w1->signal = signal;
			w1->siglen = lll;
			w1->MaxX = lll;
			w1->LabelX = "signal";

			w2->signal = pwr;
			w2->siglen = lll/2;
			w2->MaxX = lll/2;
			w2->MaxY = m;
			w2->LabelX = "power";


			w3->signal = rr;
			w3->siglen = lll/2;
			w3->MaxX = lll/2;
			w3->LabelX = "real";

			w4->signal = ii;
			w4->siglen = lll/2;
			w4->MaxX = lll/2;
			w4->LabelX = "imag";

			w5->signal = phase;
			w5->siglen = lll/2;
			w5->MaxX = lll/2;
			w5->LabelX = "phase";


			//w2f=(new wg::CGraphWidget(surf,10,100+2+10+10,1024+2,100+2,512,"Spectrum"));		
			//((wg::CGraphWidget*)w2f)->style  = wg::CGraphWidget::filled;

			//w->Add(w2f);
			//w->Add(new wg::CGraphWidget2(surf,30+460+20,10,460,220));	
			//w->Add(new wg::CGraphWidget2(surf,30+460+20,10+220+4,230,220));	
			//w->Add(new wg::CGraphWidget2(surf,30+460+20+220+4,10+220+4,230,120));	


			//end ctor
			ShowWindow(hWnd, SW_SHOWNORMAL);
			UpdateWindow(hWnd);
			SetTimer(hWnd,9000,1,0);

		}

		virtual void Paint(HDC dc) {			
			w->DrawAll();
			surf->Paint(dc);		
		}
		virtual LRESULT CALLBACK WndProc(UINT Msg,WPARAM wParam, LPARAM lParam)
		{
			static bool playing = true;
			LRESULT res = 0;
			switch(Msg)
			{
			case WM_TIMER:

				{
					static int f = 40;
					static double ph = 0;
					SigGen2(signal,f,ph,lll);
					complex fft_res[lll];
					naive_fft(signal, fft_res,lll);
					realimag(fft_res,rr,ii,lll);

					pphase(fft_res,phase,lll);

					((wg::CGraphWidget2*)w->next)->MaxY =  powerspec(fft_res,pwr,lll);

					//f++;
					//if(f>lll)f=0;
					ph +=0.01;
				}
				InvalidateRect(hWnd,0,0);
				break;

				/* mouse events*/
			case WM_MOUSEMOVE:
			case WM_LBUTTONDOWN:
			case WM_LBUTTONUP:
				{
					Events e;
					e.e=wParam==MK_LBUTTON?Events::mpress:Msg==WM_LBUTTONUP?Events::mrelease:Events::mmove;
					e.x = GET_X_LPARAM(lParam);
					e.y = GET_Y_LPARAM(lParam);

					wg::CWidget *tw = w;
					u16 res=0,res2=0;
					while(tw)
					{
						res=tw->OnEvent(&e);
						//if(res=tw->OnEvent(&e));//break;
						res2|=res;
						tw=(wg::CWidget*)tw->next;

						if(res == 11) {
							SetCapture(hWnd);
						}
						if(res == 22) {
							ReleaseCapture();
						}
						if(res == 33) {
							playing = false;
							//							snd->Puase();
						}
						if(res == 44) {
							playing = true;
							//		snd->Resume();
						}
					}


					if(res2!=0)
					{
						//if(!playing) 
						InvalidateRect(hWnd,0,0);
					}

				}
				break;
			}
			return 0;
		}


	};
};// sg
