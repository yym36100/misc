/*
 * platform.h
 *
 *  Created on: 21 jan 2012
 *      Author: benjamin
 */

#ifndef PLATFORM_H_
#define PLATFORM_H_

#include <stdint.h>

#define ARM_TEST

typedef long long Word64;
typedef uint32_t ULONG32;

#endif /* PLATFORM_H_ */
