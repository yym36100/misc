// helix.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "windows.h"

#include "mp3dec.h"

extern "C"
{
#include "Tread.c"
}

#define kb *1024

typedef unsigned long u32;
typedef unsigned short u16;

void writeWaveHeader(FILE *f,u32 samplelen);

int _tmain(int argc, _TCHAR* argv[])
{
	int o;
	unsigned char *buffer, *p;
	short *outbuff;
	int bufflen = 3839430;
	int outbuffoffset = 0;

	int err;
	int outOfData = 0;
	MP3FrameInfo info;

	HMP3Decoder d;

	FILE *f = fopen("out.wav","wb");
	if(!f) return 1;
	writeWaveHeader(f,42827618);

	buffer = (unsigned char*)Tread;
	outbuff = new short[100*1024*1024];
	p = buffer;

	LARGE_INTEGER freq, start,stop, delta, ms;
	QueryPerformanceFrequency(&freq);
	QueryPerformanceCounter(&start);

	d = MP3InitDecoder();

	while(!outOfData)
	{
		o = MP3FindSyncWord(p,bufflen);
		p+=o;
		err = MP3Decode(d, &p, &bufflen, outbuff+outbuffoffset, 0);

		switch (err) 
		{
		case ERR_MP3_NONE:
			MP3GetLastFrameInfo(d, &info);
			outbuffoffset+=info.outputSamps;
			//printf("%d\n",bufflen);
			//fwrite(outbuff,info.outputSamps,2,f);
			/*for(int i=0;i<info.outputSamps;i++)
			{
				putchar((outbuff[i] >> 0) & 0xff);
				putchar((outbuff[i] >> 8) & 0xff);				
			}*/
			break;
		case ERR_MP3_INDATA_UNDERFLOW:
			outOfData = 1;
			break;
		case ERR_MP3_MAINDATA_UNDERFLOW:
			/* do nothing - next call to decode will provide more mainData */
			break;
		case ERR_MP3_FREE_BITRATE_SYNC:
		default:
			outOfData = 1;
			break;
		}		
	}
	QueryPerformanceCounter(&stop);
	delta.QuadPart = stop.QuadPart - start.QuadPart;
	ms.QuadPart = delta.QuadPart*1000/(double)(freq.QuadPart);

	printf("conv time %d (ms)\n\n",ms.QuadPart);

	fwrite(outbuff,outbuffoffset,2,f);
	MP3FreeDecoder(d);
	fclose(f);

	return 0;
}

void writeWaveHeader(FILE *f,u32 samplelen){
	//header
	fwrite("RIFF",4,1,f);
	//chunk size
	u32 cksize = 4+24+8+ 2*2*samplelen; /*header size + 1sample len in bytes * no channels * no samples */ 
	fwrite(&cksize,4,1,f);
	//wave id ckid
	fwrite("WAVEfmt ",8,1,f);
	cksize = 16;
	fwrite(&cksize,4,1,f);
	//format tag
	u16 t16 = 1;
	fwrite(&t16,2,1,f);
	//no channels
	t16 = 2;
	fwrite(&t16,2,1,f);
	//samples/sec
	u32 t32 = 44100;
	fwrite(&t32,4,1,f);
	// average bytes/sec
	t32 = 44100*2*2;
	fwrite(&t32,4,1,f);
	// block align
	t16 = 2*2;
	fwrite(&t16,2,1,f);
	//bits/sample
	t16 = 8*2;
	fwrite(&t16,2,1,f);
	//ckid
	fwrite("data",4,1,f);
	//chunk size
	cksize = 2*2*samplelen;
	fwrite(&cksize,4,1,f);

	// and now follows the data...
}
