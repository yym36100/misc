
#ifndef _HELIX_LIBRARY_H_
#define _HELIX_LIBRARY_H_

#include <stdarg.h>

// public procedure prototypes

void*       HelixLibEntry(int fCode, int nparams, va_list args);


// library & procedure names
// library name
#define     HELIX_LIB_NAME           "Helix Library"

// library functions
#define     HELIX_LIB_ENTRY          "HelixLibEntry"


#endif  // _HELIX_LIBRARY_H_


