 
#include <stdarg.h>

#include "module_dyn_header.h"
#include "system_loader.h"

    
#include "helix_lib.h"

// private module data
static module_data_dcpt  module_data;

// private procedure prototypes
extern int      _HelixLibInit(void);
extern int      HelixLibClose(void);



int _HelixLibClose(void)
{
    volatile unsigned int save_gp;
    int  res;

    export_prologue(save_gp);

    res=HelixLibClose();

    export_epilogue(save_gp);

    return res;

}


void* _HelixLibEntry(int fCode, int nparams, ...)
{
    va_list args;
    volatile unsigned int save_gp;
    void*  res;

    export_prologue(save_gp);
    
    va_start( args, nparams );

    res=HelixLibEntry(fCode, nparams, args);

    va_end( args );

    export_epilogue(save_gp);


    return res;
}

static const module_init_dcpt HelixInit = 
{
    (export_proc)_HelixLibInit,   // proc_init;      // initialization procedure 
    (export_proc)_HelixLibClose   // proc_cleanup;    // de-initialization procedure 
};


static const export_dcpt HelixExports = 
{
    1,                                  // nexports
    {
        {(export_proc)_HelixLibEntry, HELIX_LIB_ENTRY},    // entry procedure
    },
};



// imports
#include "helix_imports.c"
#if (__C32_VERSION__ > 112)
const module_dyn_hdr __attribute__((__section__(".Module_Header_Section, code"))) _ModuleLoadHdr = 
#else
const module_dyn_hdr __attribute__((__section__(".Module_Header_Section"))) _ModuleLoadHdr = 
#endif
{
    _MCHP_DYN_HDR_SIGNATURE_,           // module_sign - signature
    HELIX_LIB_NAME,                     // module_name
    // init
    &HelixInit,                         // module init
    //
    &HelixExports,                      // exports
    //
    &_HelixModuleImports,               // imports
    //
    &module_data,                       // private data
    // 
	
	#if (__C32_VERSION__ > 112)
	_DefaultModuleInfoEx(0x0100,0,0,0,0), 
	#else
    _DefaultModuleInfo(0x0100),         // module info
	#endif
};
 



