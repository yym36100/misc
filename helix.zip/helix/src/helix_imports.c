
#include <string.h>

#include "system_loader.h"
#include "module_dyn_header.h"
#include "main_services.h"


// default imports, for every module

static import_proc _helix_import_tbl[] =
{
    0,      // malloc
    0,      // free
};

extern const module_dyn_hdr _ModuleLoadHdr;

// local copies of the Loader Library entries
void* malloc( size_t nbytes )
{
    void* (*hFunc)( size_t, const module_dyn_hdr* ) = (void* (*)( size_t, const module_dyn_hdr* ))_helix_import_tbl[0];
    return (*hFunc)(nbytes, &_ModuleLoadHdr); 
}

// get a symbol
void free( void* ptr )
{
    void (*hFunc)( void* , const module_dyn_hdr* ) = (void (*)( void*, const module_dyn_hdr* ))_helix_import_tbl[1];
    return (*hFunc)(ptr, &_ModuleLoadHdr); 
}

static const import_dcpt _HelixModuleImports = 
{
    2,          // nimports
    {
        { MAIN_SERVICES_LIB, MAIN_SERVICES_MALLOC,      _helix_import_tbl },
        { MAIN_SERVICES_LIB, MAIN_SERVICES_FREE,        _helix_import_tbl+1 },
    }
};



