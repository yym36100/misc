
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>


#include "system_loader.h"

#include "helix_lib.h"

#include "mp3dec.h"

//#pragma comment(linker, "--no-data-init")   

/*********************************************************************
 * Function:        int HelixLibInit(void)
 *
 * PreCondition:    None
 *
 * Input:			None
 *
 * Output:          0 if init failed,
 * 					1 if the init suceeded
 *
 * Side Effects:    None
 *
 * Overview:		Lib init
 *
 * Note:            None.
 ********************************************************************/
int HelixLibInit(void)
{
    // do whatever initialization needed for Helix here

    return 1;
}

/*********************************************************************
 * Function:        int HelixLibClose(void)
 *
 * PreCondition:    None
 *
 * Input:			None
 *
 * Output:          0 if close failed,
 * 					1 if the close suceeded
 *
 * Side Effects:    None
 *
 * Overview:		Lib close
 *
 * Note:            None.
 ********************************************************************/
int HelixLibClose(void)
{
    // do whatever clean-up needed for Helix here
    return 1;
}

/*********************************************************************
 * Function:        void* HelixLibEntry(int fCode)
 *
 * PreCondition:    None
 *
 * Input:			fCode   - function to be executed
 *
 * Output:          Depends on the fCode
 *
 * Side Effects:    None
 *
 * Overview:		Lib entry point.
 *
 * Note:            None.
 ********************************************************************/
void* HelixLibEntry(int fCode, int nparams, va_list args)
{
    void*   res = (void*)-1;

    // Library entry point
    switch(fCode)
    {
        case 0:
            if(nparams == 0)
            {
                res = MP3InitDecoder();
            }
            break;

        case 1:
            if(nparams == 1)
            {
                MP3FreeDecoder(va_arg(args, HMP3Decoder));
                res= 0;
            }
            break;

        case 2:
            if(nparams == 5)
            {
               res = (void*)MP3Decode(va_arg(args, HMP3Decoder),
                                      va_arg(args, unsigned char**),
                                      va_arg(args, int*), 
                                      va_arg(args, short*),
                                      va_arg(args, int));
            }
            break;

        case 3:
            if(nparams == 2)
            {
                MP3GetLastFrameInfo(va_arg(args, HMP3Decoder), 
                                    va_arg(args, MP3FrameInfo*));
                res = 0;
            }
            break;
            
        case 4:
            if(nparams == 3)
            {
                res = (void*)MP3GetNextFrameInfo(va_arg(args, HMP3Decoder),
                                                 va_arg(args, MP3FrameInfo*),
                                                 va_arg(args,  unsigned char*));
            }
            break;
            
        case 5:
            if(nparams == 2)
            {
                res = (void*)MP3FindSyncWord(va_arg(args, unsigned char*),
                                             va_arg(args, int));
            }
            break;

        default:
            break;
    }

    return res;
}


