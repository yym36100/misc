
#ifndef _MAIN_SERVICES_H_
#define _MAIN_SERVICES_H_



// Exposed libraries



/****************** Main Services *************************************/


// library & procedure names
// library name
#define     MAIN_SERVICES_LIB             "Main Library"

// library functions
#define     MAIN_SERVICES_MALLOC          "malloc"
#define     MAIN_SERVICES_FREE            "free"


// AD manipulation
#define     MAIN_SERVICES_WRITE_ACFG      "WriteACfgSamples"
#define     MAIN_SERVICES_READ_ACFG       "ReadACfgSamples"


// public procedure prototypes
void*	malloc(size_t nbytes);
void	free(void* ptr);
void    WriteACfgSamples(int samples);
int     ReadACfgSamples(void);




#endif	// _MAIN_SERVICES_H_

