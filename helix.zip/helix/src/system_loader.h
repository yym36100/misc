
#ifndef _SYSTEM_LOADER_H_
#define _SYSTEM_LOADER_H_

/****************** Loader Services *************************************/

#define     LOADER_VERIFY_PARAMETERS        // verify the passed parameters to be valid     
//#define     LOADER_OPT_ENTRIES              // optional loader functions implemented
                                              // not supported right now

// library & procedure names
// library name
#define     LOADER_LIB              "Loader Library"

// library functions
#define     LOADER_LIB_DLOPEN       "dlopen"
#define     LOADER_LIB_DLSYM        "dlsym"
#define     LOADER_LIB_DLCLOSE      "dlclose"
#define     LOADER_LIB_DLERROR      "dlerror"

#ifdef LOADER_OPT_ENTRIES
#define     LOADER_LIB_DLEXPORTS   "dlexports"
#define     LOADER_LIB_DORDINAL    "dlordinal"
#define     LOADER_LIB_DLNAME      "dlname"

#endif  // LOADER_OPT_ENTRIES


// public procedure prototypes

// open a library and get a handle
// returns 0 if error
// the error condition will be set to ENOENT if no such library
const void*     dlopen( const char* lib_name, int mode );

// get a handle to an exported symbol/procedure
// returns 0 if error
// the error condition will be set to EINVAL if invalid lib_handle 
// the error condition will be set to ENOENT if no such procedure name 
void*           dlsym( const void* lib_handle, const char* proc_name );

// close the library
// returns 0 if success (always)
int             dlclose( const void *lib_handle );

// get last error
// returns the latest error condition and clears it
int            dlerror(void);

// optional stuff
#ifdef LOADER_OPT_ENTRIES

// get the number of exported symbols
// 0 if error
// the error condition will be set to ENOENT if no such library
int         dlexports( const void* lib_handle);

// get a symbol by ordinal
// returns 0 if error
// the error condition will be set to EINVAL if invalid lib_handle 
// the error condition will be set to ENOENT if no such procedure index 
void*       dlordinal( const void* lib_handle, int n );

// get a symbol name by ordinal
// returns 0 if error
// the error condition will be set to EINVAL if invalid lib_handle 
// the error condition will be set to ENOENT if no such procedure index 
const char* dlname( const void* lib_handle, int n );

#endif  // LOADER_OPT_ENTRIES



#endif	// _SYSTEM_LOADER_H_

