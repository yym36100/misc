// wavegen2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "math.h"

void wave_gen(short *buff, int amp, float freq, int len)
{
	char *p = (char*)buff;
	short pp;
	int i;
	for(i=0;i<len/2;i++)
	{
		pp = amp * sin(2*3.1415*(float)freq*i/(float)44600.0);				
		//pp = amp * sin(2.0*3.1415*(float)freq*i/(float)(len/2.0));				

		//1
		*p++ = pp&0xff;
		*p++ = (pp>>8)&0xff;

		//2
		*p++ = pp&0xff;
		*p++ = (pp>>8)&0xff;
	}
}


int _tmain(int argc, _TCHAR* argv[])
{
#define blen	(512)
	short *buff = new short[blen];
	wave_gen(buff,10000,1742.188,blen);

	FILE *f;
	f = fopen("wave.raw","wb");
	fwrite(buff,blen,2,f);
	fclose(f);
	delete[] buff;
	return 0;
}

