#pragma once
#include "window5.h"

//widgets
#include "textwidget.h"
#include "GraphWidget.h"
#include "slider.h"
#include "button.h"
#include "autom2d.h"

namespace sg{

	class Cmywindow;

	class Cmywindow : public CWindow {
	public:
		wg::CWidget *w;

		Cmywindow(Rect r, u32 style,HWND parent_hWnd,u16 *name) :
		CWindow( r, style, parent_hWnd, name),w(0)
		{
			//w=(new wg::CGraphWidget(surf,10,10,1024+2,100+2,1024,"Wave"));
			w = new wg::CAutom2DWidget(surf,0,0,r.w,r.h);
			//end ctor
			ShowWindow(hWnd, SW_SHOWNORMAL);
			UpdateWindow(hWnd);
			SetTimer(hWnd,9876,16,0);
		}
		virtual void Paint(HDC dc) {			
			w->DrawAll();
			surf->Paint(dc);		
		}
		virtual LRESULT CALLBACK WndProc(UINT Msg,WPARAM wParam, LPARAM lParam)
		{
			LRESULT res = 0;
			switch(Msg)
			{
				/* mouse events*/
			case WM_TIMER:
				/*for(long i = 0;i<1000000;i++){
					((wg::CAutom2DWidget*)w)->Update();
				}*/
				InvalidateRect(hWnd,0,0);
				break;
			case WM_MOUSEMOVE:
			case WM_LBUTTONDOWN:
			case WM_LBUTTONUP:
				{
					Events e;
					e.e=wParam==MK_LBUTTON?Events::mpress:Msg==WM_LBUTTONUP?Events::mrelease:Events::mmove;
					e.x = GET_X_LPARAM(lParam);
					e.y = GET_Y_LPARAM(lParam);

					wg::CWidget *tw = w;
					u16 res=0;
					while(tw)
					{
						if(res|=tw->OnEvent(&e));//break;
						tw=(wg::CWidget*)tw->next;
					}	
					if(res!=0)
					{
						InvalidateRect(hWnd,0,0);
					}
				}
				break;
			}
			return 0;
		}
	};
};// sg
