//#include "surface.h"
//#include "Widget.h"
#include "autom2d.h"

namespace sg
{
	namespace wg
	{
		CAutom2DWidget::CAutom2DWidget(gr::CSurface *ss, u16 x, u16 y, u16 w, u16 h):
	CWidget(ss,x,y,w,h)
	{	
		
		for(int i=0;i<4;i++){
			part[i].x = 0;
			part[i].y = 0;
			state[i] = add_new;
		}
		t1 = new CMyThread(this,0);
		t2 = new CMyThread(this,1);
		t3 = new CMyThread(this,2);
		t4 = new CMyThread(this,3);
	}

	void CAutom2DWidget::Draw(void){
		static int once = 0;
		super::Draw();
		if(!once){
			once = 1;
			s->color = white;				
			s->FillRect(grect);
			s->color = black;	
			s->SetPixel(grect.w/2,grect.h/2);
		}
		//s->DrawRect(grect);
		/*s->color = white;
		int ox = part.x, oy = part.y;
		s->SetPixel(ox,oy);*/
		//Update();
		t1->Resume();
		t2->Resume();
		t3->Resume();
		//t4->Resume();


		/*s->color = red;
		s->SetPixel(ox, oy);*/
	}

	};
};
