#pragma once
#include "Widget.h"
#include "Thread.h"

namespace sg
{
	namespace wg
	{
		class CMyThread;
		class CAutom2DWidget : public CWidget {
		private:
			typedef CWidget super;
		public:
			CMyThread *t1,*t2,*t3,*t4;
			enum e_state{add_new, step};
			e_state state[4];
			Point part[4];

			CAutom2DWidget::CAutom2DWidget(gr::CSurface *ss, u16 x, u16 y, u16 w=300, u16 h=300);

			u32 GetPixel(i16 x, i16 y){
				if((x<0)|| (x>=grect.w) || (y<0) || (y>=grect.h)) {
					return 0xffffffff;
				}
				return s->GetPixel(x,y);
			}
			void SetPixel(i16 x, i16 y){
				if((x<0)|| (x>=grect.w) || (y<0) || (y>=grect.h)){
				return;
				}
				s->SetPixel(x,y);
			}

			virtual ~CAutom2DWidget(void)	{}

			void Update(Point *p, int i){
				switch(state[i])
				{
				case add_new:
					{
						int a = rand()%4;
						switch(a)
						{
						case 0 : p->x = 0; p->y = 0; break;
						case 1 : p->x = grect.w-1; p->y = 0; break;
						case 2 : p->x = 0; p->y = grect.h-1; break;
						case 3 : p->x = grect.w-1; p->y = grect.h-1; break;									  
						}
						state[i] = step;
					}

					break;
				case step:
					// check
					{
						int xm1 = p->x - 1;
						int ym1 = p->y - 1; 

						int xp1 = p->x + 1; 
						int yp1 = p->y + 1; 

						if( (GetPixel(p->x,yp1) == black) ||
							(GetPixel(p->x,ym1) == black) ||
							(GetPixel(xp1,p->y) == black) ||
							(GetPixel(xm1,p->y) == black) )
						{
							s->color = black;
							SetPixel(p->x, p->y);
							state[i] = add_new;
						} else {
							//update
							int a = rand();p->x += a > RAND_MAX/2? 1:-1;
							int b = rand();p->y += b > RAND_MAX/2? 1:-1;

							p->x = p->x <0 ? 1 : p->x > grect.w -1 ? grect.w -2 : p->x;
							p->y = p->y <0 ? 1 : p->y > grect.h -1 ? grect.h -2 : p->y;
						}
					}

					break;
				}
			}

			virtual void Draw(void);
		};

		class CMyThread : public siege::CThread
		{
		public:
			CAutom2DWidget *wg;
			int id;

			CMyThread(CAutom2DWidget *w, int i=0 ):wg(w),id(i){}
		
			DWORD WINAPI Run(void)
			{			
				while(1)
				{
					runs++;
					MStart();
					// execute job
					for(long i = 0;i<10000000;i++){
						wg->Update(&(wg->part[id]),id);
					}
					// job done sleep now
					MStop();
					if(end) break;
					Suspend();
				}
				return 0;
			}
		};
	};
};
