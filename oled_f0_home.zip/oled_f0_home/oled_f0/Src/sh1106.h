#include <stdint.h>
#include "Adafruit_GFX.h"

#define BLACK			( 0 )
#define WHITE			( 1 )
#define INVERSE 		( 2 )

#define  I2C_ADDRESS  	( 0x78 )

#define  LCDWIDTH		( 128 )
#define  LCDHEIGHT		( 64  )

#define  SETCONTRAST				( 0x81 )
#define  DISPLAYALLON_RESUME		( 0xA4 )
#define  DISPLAYALLON				( 0xA5 )

#define  NORMALDISPLAY 				( 0xA6 )
#define  INVERTDISPLAY 				( 0xA7 )

#define  DISPLAYOFF 				( 0xAE )
#define  DISPLAYON 					( 0xAF )

#define  SETDISPLAYOFFSET			( 0xD3 )
#define  SETCOMPINS 				( 0xDA )

#define  SETVCOMDETECT 				( 0xDB )

#define  SETDISPLAYCLOCKDIV 		( 0xD5 )
#define  SETPRECHARGE 				( 0xD9 )

#define  SETMULTIPLEX 				( 0xA8 )

#define  SETLOWCOLUMN 				( 0x00 )
#define  SETHIGHCOLUMN 				( 0x10 )

#define  SETSTARTLINE 				( 0x40 )

#define  COMSCANINC 				( 0xC0 )
#define  COMSCANDEC 				( 0xC8 )

#define  SEGREMAP 					( 0xA0 )



class sh1106 : public Adafruit_GFX {
public:	
	sh1106() : Adafruit_GFX(128,64) {}

	void begin();

	void command(uint8_t c);
	void command2(uint8_t c1,uint8_t c2);	

	void clearDisplay(void);
	void invertDisplay(uint8_t i);
	void display();

	void dim(bool dim);

	void drawPixel(int16_t x, int16_t y, uint16_t color);

	virtual void drawFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color);
	virtual void drawFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color);

private:

	inline void drawFastVLineInternal(int16_t x, int16_t y, int16_t h, uint16_t color);
	inline void drawFastHLineInternal(int16_t x, int16_t y, int16_t w, uint16_t color);
};
