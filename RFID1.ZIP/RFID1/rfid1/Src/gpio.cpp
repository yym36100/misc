#include "gpio.hpp"

cgpio::cgpio(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin):port(GPIOx),pin(GPIO_Pin)
{
}

	cgpio & cgpio::operator=(int a)
	{
		HAL_GPIO_WritePin(port,pin, a?GPIO_PIN_SET:GPIO_PIN_RESET);
		return *this;
	}
