/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  *
  * COPYRIGHT(c) 2016 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* USER CODE BEGIN Includes */
#include "gpio.hpp"
#include "mfrc522.h"
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
extern "C"{
	
SPI_HandleTypeDef hspi2;
UART_HandleTypeDef huart2;
	
}

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void Error_Handler(void);
static void MX_GPIO_Init(void);
static void MX_SPI2_Init(void);
static void MX_USART2_UART_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
uint8_t data[] = "start\n\r";

// http://infocenter.arm.com/help/index.jsp?topic=/com.arm.doc.arn0005r/index.html
// 1.16 Redefining low-level library functions to enable direct use of high-level library functions in the C library

volatile char term_codes[80] = "\33[=3\33[0;0H\33[K\33[2J\33[0;31;44m";

/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */
	cgpio ss(RFID_CS_GPIO_Port,RFID_CS_Pin),rst(RFID_RESET_GPIO_Port,RFID_RESET_Pin);
	MFRC522 mfrc522(ss,rst);

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI2_Init();
  MX_USART2_UART_Init();

  /* USER CODE BEGIN 2 */	
	//printf("start");
	mfrc522.PCD_Init();
	//printf("Scan PICC to see UID, SAK, type, and data blocks...\n\r");
	
	

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	data[0] = '.';
	data[1] = 0;
	int opt = 0;
	uint8_t rec = 0;
	
  while (1)
  {
  /* USER CODE END WHILE */
	  term_codes[79] = 0;
	  printf((const char*)term_codes);
	  HAL_Delay(100);
	  printf("Options:\n\r");
	  printf("1. Dump data from card\n\r");
	  printf("2. Write data to card\n\r");
	  scanf("%d",&opt);
	  printf("selected option: %d\n\r",opt);
	  HAL_Delay(100);
	  
	  switch(opt){
		  case 1:
			   printf((const char*)term_codes);
				printf("looking for card, press q to return to main menu...\n\r");
				while(1){
					printf(".");
					rec = 0;
					HAL_UART_Receive(&huart2,&rec,1,250);
					if(rec=='q') break;
					//HAL_Delay(250);					
				// Look for new cards
				if ( ! mfrc522.PICC_IsNewCardPresent()) {
					continue;
				}

				// Select one of the cards
				if ( ! mfrc522.PICC_ReadCardSerial()) {
					
					
					continue;
				}
				// Dump debug info about the card; PICC_HaltA() is automatically called
				mfrc522.PICC_DumpToSerial(&(mfrc522.uid)); 
				printf("\n\rwait 4s\n\r");
				HAL_Delay(4000);
			  }
			  break;
		  case 2:
		  {
			  while(1){
				  opt = 0;
				   printf((const char*)term_codes);
				  printf("enter value to write to the card (nonvalue chars return to main menu)\n\r");
				  scanf("%d",&opt);				 
				  if(opt == 0) break;
				  printf("value = %d \n\r looking for new card... (press q to return to previous menu)\n\r",opt);
				  while(1){
					  printf(".");
					  rec = 0;
					  HAL_UART_Receive(&huart2,&rec,1,250);
					  if(rec=='q') break;
					  
						#define println(x) printf("%s\n\r",x)
						#define F(x) x
						typedef uint8_t byte;
					  
						MFRC522::MIFARE_Key key;
						for (byte i = 0; i < 6; i++) key.keyByte[i] = 0xFF; 
						  				  
						 // Look for new cards
						if ( ! mfrc522.PICC_IsNewCardPresent()) { continue; }
							
						// Select one of the cardsqqqq
						if ( ! mfrc522.PICC_ReadCardSerial()) continue;
							
						printf(F("\n\rCard UID: "));    //Dump UID
						for (byte i = 0; i < mfrc522.uid.size; i++) { printf("%02x ",mfrc522.uid.uidByte[i]); } 
						
						printf(F("PICC type: "));   // Dump PICC type
						MFRC522::PICC_Type piccType = mfrc522.PICC_GetType(mfrc522.uid.sak);
						println(mfrc522.PICC_GetTypeName(piccType));
									 
							byte buffer[34];
							byte block;
							MFRC522::StatusCode status;
							byte len;
								

							printf("delay before write..\n\r");
							HAL_Delay(1000);
							// write data
							for (byte i = 0; i < 30; i++) buffer[i] = opt;
							
							block = 1;
							println(F("Authenticating using key A..."));
							status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, block, &key, &(mfrc522.uid));
							if (status != MFRC522::STATUS_OK) {
							   printf(F("PCD_Authenticate() failed: "));
							   println(mfrc522.GetStatusCodeName(status));
							   continue;
							}
							else println(F("PCD_Authenticate() success: "));
							
							// Write block
						status = mfrc522.MIFARE_Write(block, buffer, 16);
						if (status != MFRC522::STATUS_OK) {
							printf(F("MIFARE_Write() failed: "));
							println(mfrc522.GetStatusCodeName(status));
								continue;
						}
							else println(F("MIFARE_Write() success: "));

							println(" ");
							mfrc522.PICC_HaltA(); // Halt PICC
							mfrc522.PCD_StopCrypto1();  // Stop encryption on PCD 
						  
						  
				  }
				  				  
				  
			  }
		  }
			  break;
		  default:
			  printf("invalid option %d selected\n\r",opt);
			HAL_Delay(1000);
			break;
	  }
	  
	  
	

  /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }

  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* SPI2 init function */
static void MX_SPI2_Init(void)
{

  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }

}

/* USART2 init function */
static void MX_USART2_UART_Init(void)
{

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 19200;
  huart2.Init.WordLength = UART_WORDLENGTH_9B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_EVEN;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin : button_Pin */
  GPIO_InitStruct.Pin = button_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(button_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : RFID_IRQ_Pin */
  GPIO_InitStruct.Pin = RFID_IRQ_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(RFID_IRQ_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : RFID_RESET_Pin */
  GPIO_InitStruct.Pin = RFID_RESET_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(RFID_RESET_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : RFID_CS_Pin */
  GPIO_InitStruct.Pin = RFID_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
  HAL_GPIO_Init(RFID_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : led2_Pin led1_Pin */
  GPIO_InitStruct.Pin = led2_Pin|led1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, RFID_RESET_Pin|RFID_CS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, led2_Pin|led1_Pin, GPIO_PIN_RESET);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
