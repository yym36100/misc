#include <stdint.h>
#include "stm32f1xx_hal.h"

#ifndef __GPIO__HPP__
#define __GPIO__HPP__

class cgpio{
	public:
	GPIO_TypeDef* port;
	uint16_t pin;
	
	cgpio(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
	
	cgpio & operator=(int a);
	
};	


#endif //__GPIO__HPP__
