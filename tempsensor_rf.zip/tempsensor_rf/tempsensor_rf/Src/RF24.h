#ifndef __RF24_H__
#define __RF24_H__

#include <stdint.h>

typedef enum { RF24_PA_MIN = 0, RF24_PA_LOW, RF24_PA_HIGH, RF24_PA_MAX, RF24_PA_ERROR } rf24_pa_dbm_e;
typedef enum { RF24_1MBPS = 0, RF24_2MBPS, RF24_250KBPS } rf24_datarate_e;
typedef enum { RF24_CRC_DISABLED = 0, RF24_CRC_8, RF24_CRC_16 } rf24_crclength_e;

class RF24 {

private:

    bool wide_band;
    bool p_variant;
    uint8_t payload_size;
    bool ack_payload_available;
    bool dynamic_payloads_enabled;
    uint8_t ack_payload_length;
    uint64_t pipe0_reading_address;

	uint8_t spi_write_h(uint8_t txdata);
    void delayus_h(uint8_t delay);
	
protected:
    void set_csn(int mode);
    void set_ce(int level);

    uint8_t read_register(uint8_t reg, uint8_t* buf, uint8_t len);
    uint8_t read_register(uint8_t reg);

    uint8_t write_register(uint8_t reg, const uint8_t* buf, uint8_t len);
    uint8_t write_register(uint8_t reg, uint8_t value);

    uint8_t write_payload(const void* buf, uint8_t len);
    uint8_t read_payload(void* buf, uint8_t len);

    uint8_t flush_rx(void);
    uint8_t flush_tx(void);

public:
    uint8_t get_status(void);

    void print_status(uint8_t status);
    void print_observe_tx(uint8_t value);

    void print_byte_register(const char* name, uint8_t reg, uint8_t qty = 1);
    void print_address_register(const char* name, uint8_t reg, uint8_t qty = 1);

    void toggle_features(void);


public:

    RF24();

    void begin(void);

    /* Be sure to call openReadingPipe() first.  Do not call write() while
     * in this mode, without first calling stopListening().  Call
     * isAvailable() to check for incoming traffic, and read() to get it. */
    void startListening(void);

    /* Do this before calling write(). */
    void stopListening(void);

    /*  Be sure to call openWritingPipe() first to set the destination of where to write to. */
    bool write(const void* buf, uint8_t len);

    bool available(void);

    bool read(void* buf, uint8_t len);

    /* Only one pipe can be open at once, but you can change the pipe you'll listen to.  Do not call this while actively listening.
     * Remember to stopListening() first.
     *
     * @param address The 40-bit address of the pipe to open.  This can be any value whatsoever, as long as you are the only one writing to it
     * and only one other radio is listening to it.
     */
    void openWritingPipe(uint64_t address);

    /* Open a pipe for reading
     *
     * Up to 6 pipes can be open for reading at once.  Open all the reading pipes, and then call startListening().
     *
     * @warning Pipe 0 is also used by the writing pipe.  So if you open
     * pipe 0 for reading, and then startListening(), it will overwrite the
     * writing pipe.  Ergo, do an openWritingPipe() again before write(). */
    void openReadingPipe(uint8_t number, uint64_t address);

    /* @param delay How long to wait between each retry, in multiples of 250us,
     * max is 15.  0 means 250us, 15 means 4000us.
     * @param count How many retries before giving up, max 15
     */
    void setRetries(uint8_t delay, uint8_t count);
    void setChannel(uint8_t channel);
    void setPayloadSize(uint8_t size);
    uint8_t getPayloadSize(void);
    uint8_t getDynamicPayloadSize(void);
    void enableAckPayload(void);
    void enableDynamicPayloads(void);
    bool isPVariant(void);

    void setAutoAck(bool enable);
    void setAutoAck(uint8_t pipe, bool enable);

    void setPALevel(rf24_pa_dbm_e level);
    rf24_pa_dbm_e getPALevel(void);

    bool setDataRate(rf24_datarate_e speed);
    rf24_datarate_e getDataRate(void);

    void setCRCLength(rf24_crclength_e length);
    rf24_crclength_e getCRCLength(void);
    void disableCRC(void);

    void printDetails(void);
	void printEverything(void);

    void powerDown(void);
    void powerUp(void);

    bool available(uint8_t* pipe_num);

    void startWrite(const void* buf, uint8_t len);
    void writeAckPayload(uint8_t pipe, const void* buf, uint8_t len);
    bool isAckPayloadAvailable(void);

    void whatHappened(bool& tx_ok, bool& tx_fail, bool& rx_ready);

    bool testCarrier(void);
    bool testRPD(void);
};

#endif // __RF24_H__
