/*
 * BasicTerm.cpp
 * Provides basic ANSI/VT220 terminal control over a serial interface
 * Copyright 2011 Trannie Carter <borys@nottwo.org>
 * Licensed for use under the terms of the GNU Lesser General Public License v3
 */

#include "BasicTerm.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

BasicTerm::BasicTerm() {
 
}

int BasicTerm::available(void) {
    return 0;
}

int BasicTerm::peek(void) {
    return 0;
}

int BasicTerm::read(void) {
    return 0;
}

void BasicTerm::flush(void) {
    ;
}

int BasicTerm::write(uint8_t c) {
    uint8_t ret;

    if(c & BT_ALTCHAR) {
        printf(BT_START_ALTCHAR);
        putchar(c & ~BT_ALTCHAR);
        printf(BT_END_ALTCHAR);
        return ret;
    }

    return putchar(c);
}

void BasicTerm::init(void) {
   printf(("\x1b\x63")); 
}

void BasicTerm::cls(void) {
    printf(("\x1b[2J"));
}

void BasicTerm::position(uint8_t row, uint8_t col) {
    printf("\x1b[%d;%dH",row+1,col+1);    
}

void BasicTerm::show_cursor(bool show) {
    if(show) {
        printf("\x1b[?25h");
    } else {
        printf("\x1b[?25l");
    }
}

int16_t BasicTerm::get_key(void) {
    int16_t key;

    key = getchar();

    if(key == 0x1b) { /* escape sequence */
     
         key = getchar();

        switch(key) {
            case '[':
                  key = getchar();
                switch(key) {
                    case 'A':
                        return BT_KEY_UP;
                    case 'B':
                        return BT_KEY_DOWN;
                    case 'C':
                        return BT_KEY_RIGHT;
                    case 'D':
                        return BT_KEY_LEFT;
                    default:
                        return BT_KEY_UNKNOWN;
                }
            case 'O':
                  key = getchar();
                switch(key) {
                    case 'P':
                        return BT_KEY_F(1);
                    case 'Q':
                        return BT_KEY_F(2);
                    case 'R':
                        return BT_KEY_F(3);
                    case 'S':
                        return BT_KEY_F(4);
                    default:
                        return BT_KEY_UNKNOWN;
                }                
            default:
                return BT_KEY_UNKNOWN;
        } 
    }

    return key;
}

void BasicTerm::set_attribute(uint8_t attr) {
    if(attr & BT_REVERSE) {
        printf("\x1b[7m");
    }
    if(attr & BT_UNDERLINE) {
        printf("\x1b[4m");
    }
    if(attr & BT_BOLD) {
        printf("\x1b[1m");
    }
    if(attr & BT_BLINK) {
        printf("\x1b[5m");
    }
    if(attr == BT_NORMAL) {
        printf("\x1b[0m");
    }
}

void BasicTerm::set_color(uint8_t fg, uint8_t bg) {
    printf("\x1b[%d;%dm",30+fg,40+bg);    
}

void BasicTerm::beep(void) {
    ;
}
