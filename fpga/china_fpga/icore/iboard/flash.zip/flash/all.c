#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int main(void)
{
	FILE *fall,
		 *fhzk16,
		 *fhzk16f,
		 *fhzk12,
		 *fhzk24h,
		 *flogo;
	int i,j;
	int counter =0;

	unsigned char c;


	fhzk16 = fopen(".\\1_HZK16","rb");
	fhzk16f = fopen(".\\2_HZK16F","rb");
	fhzk12 = fopen(".\\3_HZK12","rb");
	fhzk24h = fopen(".\\4_HZK24H","rb");
	flogo = fopen(".\\5_LOGO.BIN","rb");

	fall = fopen(".\\all.bin","wb");


//hzk16
	while(!feof(fhzk16)){
			c =(unsigned char)fgetc(fhzk16);
			fputc(c,fall);
			counter ++;
	}
	
	while(counter <1024*64*5){
			fputc(0,fall);
			counter ++;
	}
//hzk16f
	while(!feof(fhzk16f)){
			c =(unsigned char)fgetc(fhzk16f);
			fputc(c,fall);
			counter ++;
	}
	
	while(counter <1024*64*10){
			fputc(0,fall);
			counter ++;
	}
//hzk12
	while(!feof(fhzk12)){
			c =(unsigned char)fgetc(fhzk12);
			fputc(c,fall);
			counter ++;
	}
	
	while(counter <1024*64*15){
			fputc(0,fall);
			counter ++;
	}
//hzk24h
	while(!feof(fhzk24h)){
			c =(unsigned char)fgetc(fhzk24h);
			fputc(c,fall);
			counter ++;
	}
	
	while(counter <1024*64*24){
			fputc(0,fall);
			counter ++;
	}
//logo
	while(!feof(flogo)){
			c =(unsigned char)fgetc(flogo);
			fputc(c,fall);
			counter ++;
	}
	
	while(counter <1024*64*28){
			fputc(0,fall);
			counter ++;
	}


	fclose(fhzk16);
	fclose(fhzk16f);
	fclose(fhzk12);
	fclose(fhzk24h);
	fclose(flogo);
	fclose(fall);

}
