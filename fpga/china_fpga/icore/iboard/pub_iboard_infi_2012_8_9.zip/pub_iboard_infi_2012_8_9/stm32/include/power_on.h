/*------------------------------------------------------
FILE NAME   : power_on.h
DESCRIPTION :  
VERSION     : 0.0.0 (C)XiaomaGee
AUTHOR      : XiaomaGee
CREATE DATE : 2010-6-3
MODIFY DATE :
LOGS        :-\
--------------------------------------------------------*/
#ifndef __power_on_h__
#define __power_on_h__

//-----------------Include files-------------------------//

 
 
//----------------- Define ------------------------------//



//----------------- Typedef------------------------------//


//----------------- Extern ------------------------------//

extern int power_on(void);
extern int show_logo(void);

#endif //__power_on_h__
