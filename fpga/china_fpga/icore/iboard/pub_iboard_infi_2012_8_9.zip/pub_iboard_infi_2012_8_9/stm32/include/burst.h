/*
 * FILE							: burst.h
 * DESCRIPTION			: This file is ....
 * Author						: XiaomaGee@Gmail.com
 * Copyright				:
 *
 * History
 * --------------------
 * Rev							: 0.00
 * Date							: 00/00/2012
 *
 * create.
 * --------------------
 */
#ifndef __burst_h__
#define __burst_h__

//----------------- Include files------------------------//


//----------------- Define ------------------------------//


//----------------- Typedef -----------------------------//
 typedef const struct  {
		int (* main)(void);
 }BURST_T;
	 
//----------------- Extern ------------------------------//
extern BURST_T burst;

#endif //__burst_h__
