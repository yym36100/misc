/*------------------------------------------------------
FILE NAME   : bignumber.h
DESCRIPTION : 
VERSION     : 0.0.0 (C)XiaomaGee
AUTHOR      : XiaomaGee
CREATE DATE : 2010-6-9
MODIFY DATE :
LOGS        :-\
--------------------------------------------------------*/

//---------------- Include files ------------------------//


//---------------- Function Prototype -------------------//


//---------------- Variable -----------------------------//
#ifndef __bignumber_h__
#define __bignumber_h__






typedef struct{
	char character;
	char const * dat;
}BIGNUMBER_T;




#endif