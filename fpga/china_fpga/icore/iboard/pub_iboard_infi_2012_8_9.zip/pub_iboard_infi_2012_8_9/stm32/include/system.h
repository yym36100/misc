/*------------------------------------------------------
FILE NAME   : system.h
DESCRIPTION : ---
VERSION     : 0.0.0 (C)XiaomaGee
AUTHOR      : XiaomaGee
CREATE DATE : 2011-2-21
MODIFY DATE :
LOGS        :-\r
--------------------------------------------------------*/
#ifndef __system_h__
#define __system_h__

//-----------------Include files-------------------------//


//----------------- Define ------------------------------//



//----------------- Typedef------------------------------//
extern int _system(void);

#endif //__system_h__
