/*------------------------------------------------------
FILE NAME   : rc_bignumber.c
DESCRIPTION : rc_bignumber
VERSION     : 0.0.0 (C)XiaomaGee
AUTHOR      : XiaomaGee
CREATE DATE : 2010-6-9
MODIFY DATE :
LOGS        :-\
--------------------------------------------------------*/

//---------------- Include files ------------------------//
#include "..\include\bignumber.h"

//---------------- Function Prototype -------------------//


//---------------- Variable -----------------------------//
const char bignumber_0[]={




 const BIGNUMBER_T rc_bignumber[]={
 [0].character='0',
 [1].dat=