/*
 * File				: main.c
 * Description	    : main file
 * Author	        : XiaomaGee@Gmail.com.
 * Copyright	    :  
 * 
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 08/13/2009
 * 
 * create.
 * -------------------
 */

//-----------------Include files-------------------------//
#include "..\include\hardware.h"
#include "..\include\music.h"

#include <stdio.h>

//-----------------Define--------------------------------//

//-----------------Function Prototype--------------------//
 
//-----------------Variable------------------------------//
 
//-----------------Function------------------------------//
 /*
 * Name				: main
 * Description		: ---
 * Author		    : XiaomaGee.
 * 
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 08/13/2009
 * 
 * create.
 * -------------------
 */
void main(void)
 {
  initialize_music();	
  while(1);
 }
