/*
 * File				: music.h
 * Description		:--
 * Author		    : XiaomaGee@Gmail.com.
 * Copyright		:  
 * 
 * History
 * -------------------
 * Rev	: 0.00
 * Date	: 08/13/2009
 * 
 * create.
 * -------------------
 */

#ifndef __music_h__
#define	__music_h__

//-----------------Include files-------------------------//
#include <reg52.h>

//-----------------define--------------------------------//
typedef struct{
	unsigned char h;
	unsigned char l;
}FREQ_T;				//����FREQ_T ���洢ʵ��ĳһƵ�ʵĶ�ʱ����ʼֵ����

typedef struct{
	FREQ_T * freq;
	unsigned char time;	//ĳһƵ�ʲ��ŵ�ʱ��
}NOTE_T;

#define	TIME_1_32	1
#define	TIME_1_16	2
#define	TIME_1_8	4
#define	TIME_1_4	8
#define	TIME_1_2	16
#define	TIME_1_1	32

//-----------------extern--------------------------------//
 
extern void initialize_music(void);	   //�����Ķ�������
 
extern  FREQ_T * s[];				 //* s[]�Ķ�������
 
#endif /* __music_h__ */
