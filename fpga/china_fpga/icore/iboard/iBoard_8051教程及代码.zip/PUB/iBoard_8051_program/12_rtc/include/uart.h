/*
 * File				: uart.h
 * Description		: This file is iBoard.8051 uart header.
 * Author			: XiaomaGee@Gmail.com.
 * Copyright		:  
 * 
 * History
 * -------------------
 * Rev	: 0.00
 * Date	: 04/10/2012
 * 
 * create.
 * -------------------
 */

#ifndef __uart_h__
#define	__uart_h__

//-----------------Include files-------------------------//
#include <reg52.h>

//-----------------define -------------------------------//

//-----------------extern -------------------------------//
 
extern void initialize_uart(long int BAUDRATE);
extern void send_string(char * /* ss */);
 
extern unsigned char idata receive_buffer[];
extern unsigned char receive_ok;

#endif /* __uart_h__ */
