/*
 * File				: main.c
 * Description		: This file is iBoard.8051 led driver.
 * Author			: XiaomaGee@Gmail.com.
 * Copyright		:  
 * 
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */

//-----------------Include files-------------------------//
#include "..\include\hardware.h"
#include "..\include\uart.h"
#include "..\include\ds1302.h"

#include <stdlib.h>
#include <stdio.h>

//-----------------Define--------------------------------//

//-----------------Function Prototype--------------------//
void initialize(void);
void initialize_timer0(void);
void nix_display_int(int,unsigned char );

//-----------------Variable------------------------------//
unsigned char idata nix_value[4] = { 17, 17, 17, 17 };

unsigned char code nix_tab[] = {
	0xc0, 0xf9, 0xa4, 0xb0,
	0x99, 0x92, 0x82, 0xf8,
	0x80, 0x90, 0x88, 0x83,
	0xc6, 0xa1, 0x86, 0x8e, //�����0~F����
	0xff, 0xbf              //��ʾ���ո񡱺͡�-��
};

//-----------------Function------------------------------//
/*
 * Name				: timer0_interrupt
 * Description		: ---
 * Author		    : XiaomaGee.
 * 
 * 	History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */
void timer0_interrupt(void) interrupt 1
{
	static unsigned char i = 0;

	TH0 = 0xf8;       //��ʱ2ms�ĳ�ʼֵ����
	TL0 = 0xcd;

	NIX_SEL0 = 1;
	NIX_SEL1 = 1;
	NIX_SEL2 = 1;
	NIX_SEL3 = 1;

	P0 = nix_value[i] > 99 ? nix_tab[nix_value[i] - 100] & 0x7f : nix_tab[nix_value[i]];

	if (i == 0) NIX_SEL3 = 0; //�����һλ�����֣���ѡͨ����ܵĵ�һλ
	else NIX_SEL3 = 1;

	if (i == 1) NIX_SEL2 = 0;
	else NIX_SEL2 = 1;

	if (i == 2) NIX_SEL1 = 0;
	else NIX_SEL1 = 1;

	if (i == 3) NIX_SEL0 = 0;
	else NIX_SEL0 = 1;

	i++;

	if (i > 3) i = 0;
}

/*
 * Name				: main
 * Description		: ---
 * Author		    : XiaomaGee.
 * 
 * 	History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */
void main(void)
{
	int i = 0,j;
	char buffer[30];
	unsigned char bak = 0;

	initialize();

	rtc.year = 12;	//����ʱ��12��2��29��23ʱ56��10��
	rtc.month = 2;
	rtc.day = 29;

	rtc.second = 10;
	rtc.minute = 56;
	rtc.hour = 23;

	set_ds1302((unsigned char*)&rtc);

	while (1) {
		if (i ++ % 1000 == 0) {
			i = 0;
			get_ds1302();
			if (bak != rtc.second) {
				sprintf(buffer, "RTC 20%02bu-%bu-%bu,%bu:%bu:%bu", rtc.year, rtc.month, rtc.day, rtc.hour, rtc.minute, rtc.second);
				send_string(buffer);	//��bufffer�����ݷ��͵����ڵ���������ʾ
				
				sprintf(buffer, "%bu%bu",rtc.hour, rtc.minute); //��ʾСʱ�ͷ���
				nix_display_int(atoi(buffer),j ++ % 2);

			}
			bak = rtc.second;
		}
	}
}

/*
 * Name				:initialize 
 * Description		: ---
 * Author		    : XiaomaGee.
 * 
 * 	History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */
void initialize(void)
{
	P0 = 0XFF;
	P1 = 0XFF;
	P2 = 0XFF;
	P3 = 0XFF;

	initialize_timer0();  //��ʱ��T0�ĳ�ʼ��
	initialize_uart(1200); //���ڵĳ�ʼ��
	initialize_ds1302();  //DS1302�ĳ�ʼ��
}

/*
 * Name				:initialize_timer0 
 * Description		: ---
 * Author		    : XiaomaGee.
 * 
 * 	History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */
void initialize_timer0(void) //��ʱ��T0�ĳ�ʼ��
{
	TMOD |= 0X01;
	TH0 = 0xf8;              //��ʱ2ms�ĳ�ʼֵ����
	TL0 = 0xcd;
	TR0 = 1;                 //������ʱ��T0
	ET0 = 1;                 //ʹ�ܶ�ʱ��T0�ж�

	EA = 1;                  //��ȫ���ж�
}

/*
 * Name				: nix_display_int
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
 void nix_display_int(int number,unsigned char flash)
 {
	char buffer[10];
	char i;
	
 	sprintf(buffer, "%4d", number);
	
	for (i = 0; i < 4; i++)
		if (buffer[i] == ' ') nix_value[i] = 16;
			else nix_value[i] = buffer[i] - '0';
			if(flash)nix_value[1] += 100;

 }
