/*
 * File				: ds1302.c
 * Description		: This file is iBoard.8051 uart driver demo.
 * Author			: XiaomaGee@Gmail.com.
 * Copyright		:
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */

//-----------------Include files-------------------------//
#include "..\include\hardware.h"
#include "..\include\ds1302.h"
#include <intrins.h>

//-----------------Define--------------------------------//
sbit ACC0 = ACC ^ 0;
sbit ACC7 = ACC ^ 7;

//----------------- Typedef -----------------------------//
RTC_T rtc;

//-----------------Function------------------------------//
/*
 * Name				: bcd2hex
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
unsigned char bcd2hex(unsigned char value)	
{
	unsigned char i;

	i = value & 0x0f;
	value >>= 4;
	value &= 0x0f;
	value *= 10.0;
	i += value;

	return i;
}

/*
 * Name				: hex2bcd
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
unsigned char hex2bcd(unsigned char value)	
{
	unsigned char i, j;

	i = value / 10;
	j = value % 10;

	return(j + (i << 4));
}

/*
 * Name				: dly
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void dly(void)  //��ʱ10us
{
	unsigned char i;
	for (i = 0; i < 10; i++) {
		_nop_();
		_nop_();
		_nop_();
	}
}

/*
 * Name				: read_byte
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
unsigned char  read_byte()  //��һ���ֽ�
{
	unsigned char i;
	for (i = 8; i > 0; i--) {
		ACC = ACC >> 1;		 //ACC��һ��8λ�Ĵ���
		DS1302_IO = 1;
		ACC7 = DS1302_IO;
		DS1302_SCLK = 1;
		DS1302_SCLK = 0;
	}
	return(ACC);
}

/*
 * Name				: write_byte
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void  write_byte(unsigned char tdata)  //дһ���ֽ�
{
	unsigned char i;
	ACC = tdata;
	for (i = 8; i > 0; i--) {
		DS1302_IO = ACC0;
		DS1302_SCLK = 1;
		DS1302_SCLK = 0;     
		ACC = ACC >> 1;
	}
}

/*
 * Name				: write_data_ds1302
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void write_data_ds1302(unsigned char taddr, unsigned char tdata)  //д����
{
	DS1302_RST = 0;
	DS1302_SCLK = 0;
	DS1302_RST = 1;
	dly();
	write_byte(taddr);
	write_byte(tdata);
	dly();
	DS1302_RST = 0;
	DS1302_SCLK = 1;
}

/*
 * Name				: read_data_ds1302
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
unsigned char read_data_ds1302(unsigned char taddr)  //������
{
	unsigned char tdata;

	DS1302_RST = 0;
	DS1302_SCLK = 0;
	DS1302_RST = 1;
	dly();
	write_byte(taddr);
	tdata = read_byte();
	dly();
	DS1302_RST = 0;
	DS1302_SCLK = 1;
	return(tdata);
}

/*
 * Name				: read_data_ds1302
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void set_ds1302(unsigned char *p1302)   //����ʱ�䣬��ֻ������һ�Σ�����д�ڻ�ȡʱ��֮ǰ
{
	unsigned char i;
	unsigned char taddr = 0x80;

	write_data_ds1302(0x8e, 0x00);                 

	for (i = 7; i > 0; i--) {
		write_data_ds1302(taddr, hex2bcd(*p1302));    
		p1302++;
		taddr += 2;
	}

	write_data_ds1302(0x8e, 0x80);        
}

/*
 * Name				: get_ds1302
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void get_ds1302()  //��ȡʱ��
{								   
	unsigned char k;
	unsigned char taddr = 0x81;
	unsigned char da = 0;
	unsigned char *p = &rtc.second;

	for (k = 0; k < 7; k++) {
		da = read_data_ds1302(taddr);
		p[k] = bcd2hex(da);
		taddr += 2;
	}
}

/*
 * Name				: initialize_ds1302
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void initialize_ds1302()  //��ʼ��
{
	DS1302_RST = 0;
	DS1302_SCLK = 0;
}