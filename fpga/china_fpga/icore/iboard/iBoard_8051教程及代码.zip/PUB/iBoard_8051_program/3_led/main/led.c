/*
 * File				: led.c
 * Description		: This file is iBoard.8051 led driver.
 * Author			: XiaomaGee@Gmail.com.
 * Copyright		:  
 * 
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */

//-----------------Include files-------------------------//
#include "..\include\hardware.h"

//-----------------Define--------------------------------//

//-----------------Function Prototype--------------------//
void initialize(void);

//-----------------Variable------------------------------//

//-----------------Function------------------------------//
/*
 * Name				: main
 * Description		: ---
 * Author		    : XiaomaGee.
 * 
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */
int main(void)
{
	long int i;
	
	initialize();		           //��I/O�ڳ�ʼ��
						           
	while(1){			   
		 for(i=0;i<10000;i++);	   //��ʱ
		LED = 0;				   //��P3.5��ֵΪ0��LED����
		for(i=0;i<10000;i++);
		LED = 1;				   //��P3.5��ֵΪ1��LED����
	}
}  

 /*
 * Name				: initialize
 * Description		: ---
 * Author		    : XiaomaGee.
 * 
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */
 void initialize(void)
 {
		P0 = 0XFF;		      //��ʼ��P0�˿ڣ�ȫ����1
		P1 = 0XFF;		      //��ʼ��P1�˿ڣ�ȫ����1
		P2 = 0XFF;		      //��ʼ��P2�˿ڣ�ȫ����1
		P3 = 0XFF;		      //��ʼ��P3�˿ڣ�ȫ����1
}
