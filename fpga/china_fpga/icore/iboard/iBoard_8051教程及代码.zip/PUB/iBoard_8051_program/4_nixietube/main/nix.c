/*
 * File				: nix.c
 * Description		: This file is iBoard.8051 nixietube driver.
 * Author			: XiaomaGee@Gmail.com.
 * Copyright		:  
 * 
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */

//-----------------Include files-------------------------//
#include "..\include\hardware.h"

//-----------------Define--------------------------------//

//-----------------Function Prototype--------------------//
void initialize(void);

//-----------------Variable------------------------------//
unsigned char code nix_tab[] = {
	0xc0, 0xf9, 0xa4, 0xb0,
	0x99, 0x92, 0x82, 0xf8,
	0x80, 0x90, 0x88, 0x83,
	0xc6, 0xa1, 0x86, 0x8e, // �������ʾ0-F�Ķ���
	0xff, 0xbf              // �ո�,-,
};

//-----------------Function------------------------------//
/*
 * Name				: main
 * Description	    : ---
 * Author			: XiaomaGee.
 * 
 * 	History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 * 
 * create.
 * -------------------
 */
int main(void)
{
	long int i;
	char j = 0;
	
	initialize();

	NIX_SEL0 = 0;	 //ѡͨ��4λ�����	
	NIX_SEL1 = 0;	 //ѡͨ��3λ�����	
	NIX_SEL2 = 0;	 //ѡͨ��2λ�����	
	NIX_SEL3 = 0;	 //ѡͨ��1λ�����	
	
	while(1){
		 P0 = nix_tab[j ++];
		 if(j> 15)j=0;
		 for(i=0;i<50000;i++);
	}
}

/*
 * Name				: initialize
 * Description		: ---
 * Author		    : XiaomaGee.
 * 
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */
 void initialize(void)
 {
		P0 = 0XFF;	//��ʼ��P0�˿ڣ�ȫ����1
		P1 = 0XFF;
		P2 = 0XFF;
		P3 = 0XFF;
}
