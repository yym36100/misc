/*
 * File				: main.c
 * Description		: This file is iBoard.8051 temperature driver demo.
 * Author			: XiaomaGee@Gmail.com.
 * Copyright		:
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */

//-----------------Include files-------------------------//
#include "..\include\hardware.h"
#include "..\include\uart.h"
#include "..\include\lm75.h"

#include <stdlib.h>
#include <stdio.h>

//-----------------Define--------------------------------//

//-----------------Function Prototype--------------------//
void initialize(void);
void initialize_timer0(void);
void nix_display_float(float /* number */);

//-----------------Variable------------------------------//
unsigned char idata nix_value[4] = { 17, 17, 17, 17 };

unsigned char code nix_tab[] = {
	0xc0, 0xf9, 0xa4, 0xb0,
	0x99, 0x92, 0x82, 0xf8,
	0x80, 0x90, 0x88, 0x83,
	0xc6, 0xa1, 0x86, 0x8e, //0~f
	0xff, 0xbf              // ,-,
};

//-----------------Function------------------------------//
/*
 * Name				: timer0_interrupt
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void timer0_interrupt(void) interrupt 1
{
	static unsigned char i = 0;

	TH0 = 0xf8; 
	TL0 = 0xcd;

	NIX_SEL0 = 1;
	NIX_SEL1 = 1;
	NIX_SEL2 = 1;
	NIX_SEL3 = 1;

	P0 = nix_value[i] > 99 ? nix_tab[nix_value[i] - 100] & 0x7f : nix_tab[nix_value[i]];

	if (i == 0) NIX_SEL3 = 0;
	else NIX_SEL3 = 1;

	if (i == 1) NIX_SEL2 = 0;
	else NIX_SEL2 = 1;

	if (i == 2) NIX_SEL1 = 0;
	else NIX_SEL1 = 1;

	if (i == 3) NIX_SEL0 = 0;
	else NIX_SEL0 = 1;

	i++;

	if (i > 3) i = 0;
}

 /*
 * Name				: main
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void main(void)
{
	long int i;
	char buffer[20];
	float temp;

	initialize();

	while (1) {
		if (i++ > 50000) {
		sprintf(buffer,"[T]=%.2f",temp=lm75_read());
		send_string(buffer);
		nix_display_float(temp);
		i = 0;
		}
	 }
}

/*
 * Name				: initialize
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void initialize(void)
{
	P0 = 0XFF;
	P1 = 0XFF;
	P2 = 0XFF;
	P3 = 0XFF;

	initialize_timer0();
	initialize_uart(19200);
}

/*
 * Name				: initialize_timer0
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev            	: 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void initialize_timer0(void)
{
	TMOD |= 0X01;
	TH0 = 0xf8;     //2ms
	TL0 = 0xcd;
	TR0 = 1;       //Start Timer0
	ET0 = 1;       //Enable Timer0 Interrupt

	EA = 1;        //Enable global interrupt
}

/*
 * Name				: nix_display_int
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void nix_display_float(float a)
{
	unsigned char idata buf[10];
	bit flag = 0;

	if (a < 0) {
		flag = 1;
		a = 0 - a;
		nix_value[0] = 17;           //�Ǹ����Ļ�������λ����ܣ���������ʾ��-��,
	}else nix_value[0] = 16;         //�������Ļ���ʾ�ո�

	if (a < 10) {
	    sprintf(buf, "%.2f", a);
	    nix_value[0] += 100;          //����λ�������ʾС���㣨������
		nix_value[1] = buf[0] - '0';  //nix_value[1] = buf[0] - '0'+100��ʾ��λС����
		nix_value[2] = buf[2] - '0';
		nix_value[3] = buf[3] - '0';
	}else if (a < 100) {
		sprintf(buf, "%.1f", a);
		nix_value[1] = buf[0] - '0';
		nix_value[2] = buf[1] - '0' + 100;//�ڶ�λ�������ʾС���㣨������
		nix_value[3] = buf[3] - '0';
	}else if (a < 1000) {
		sprintf(buf, "%.0f", a);
		nix_value[1] = buf[0] - '0';
		nix_value[2] = buf[1] - '0';
		nix_value[3] = buf[2] - '0';
	} else {			   
		nix_value[0] = 0xe;	             //��ʾ�ַ���E��
		nix_value[1] = 16;
		nix_value[2] = 16;
		nix_value[3] = 16;
	}	
}
