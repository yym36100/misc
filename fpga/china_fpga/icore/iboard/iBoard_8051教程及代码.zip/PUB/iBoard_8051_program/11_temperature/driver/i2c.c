/*
 * File					: i2c.c
 * Description			: This file is iBoard.8051 i2c driver.
 * Author				: XiaomaGee@Gmail.com.
 * Copyright			:
 *
 * History
 * -------------------
 * Rev	: 0.00
 * Date	: 04/10/2012
 *
 * create.
 * -------------------
 */


//---------------- Include files ------------------------//

#include "..\include\i2c.h"
#include "..\include\hardware.h"
#include <intrins.h>

//---------------- Function Prototype -------------------//

static unsigned char read(void);
static int write(unsigned char dat);
static int start(void);
static int stop(void);

static int ack(char);
int read_nbyte(unsigned char sla, unsigned char suba, unsigned char *s, unsigned char no);
int write_nbyte(unsigned char sla, unsigned char suba, unsigned char *s, unsigned char no);

//---------------- Variable -----------------------------//

static bit ack_flag = 0;

//-----------------Function------------------------------//
/*
 * Name					: delay
 * Description			: ---
 * Author				: XiaomaGee.
 *
 *      History
 * -------------------
 * Rev					: 0.00
 * Date					: 04/10/2012
 *
 * create.
 * -------------------
 */
void delay(void)  
{
	_nop_();  //�ӳ�һ����������
}
/*
 * Name					: start
 * Description			: ---
 * Author				: XiaomaGee.
 *
 *      History
 * -------------------				   
 * Rev					: 0.00
 * Date					: 04/10/2012
 *
 * create.
 * -------------------
 */
 static
int start(void)	   //��ʼλ
{
	SDA_ON;
 
 	delay();

	SCL_ON;
	delay();

	SDA_OFF;
	delay();

	SCL_OFF;
	delay();

	return 0;
}
/*
 * Name					: stop
 * Description			: ---
 * Author				: XiaomaGee.
 *
 *      History
 * -------------------
 * Rev					: 0.00
 * Date					: 04/10/2012
 *
 * create.
 * -------------------
 */
static
int stop(void)	 //ֹͣλ
{
	SDA_OFF;
	delay();

	SCL_ON;

	delay();

	SDA_ON;
	delay();

	return 0;
}
/*
 * Name					: ack
 * Description			: ---
 * Author				: XiaomaGee.
 *
 *      History
 * -------------------
 * Rev					: 0.00
 * Date					: 04/10/2012
 *
 * create.
 * -------------------
 */
static int
ack(char a)		  
{
	if (a) {
		SDA_OFF;
	}else {
		SDA_ON;
	}
	delay();
	SCL_ON;
	delay();
	SCL_OFF;

	delay();

	return 0;
}
/*
 * Name					: write
 * Description			: ---
 * Author				: XiaomaGee.
 *
 *      History
 * -------------------
 * Rev					: 0.00
 * Date					: 04/10/2012
 *
 * create.
 * -------------------
 */
static int
write(unsigned char dat)//дһ֡����
{
	unsigned char i = 8;

	for (i = 0; i < 8; i++) { 
		if ((dat << i) & 0x80) SDA_ON;  //д�ֽ�
		else SDA_OFF;
		delay();
		SCL_ON;
		delay();
		SCL_OFF;
	}
	SDA_ON;
	delay();

	delay();
	SCL_ON;

	delay();
	if (SDA) ack_flag = 0;
	else ack_flag = 1;   	//д��֮��Ӧ��
	SCL_OFF;

	delay();

	return 0;
}
/*
 * Name					: read
 * Description			: ---
 * Author				: XiaomaGee.
 *
 *      History
 * -------------------
 * Rev					: 0.00
 * Date					: 04/10/2012
 *
 * create.
 * -------------------
 */
static unsigned char read(void)
{
	unsigned char dat;
	unsigned char i;

	dat = 0;

	SDA_ON;  

	for (i = 0; i < 8; i++) {  //��ȡ��λֵ����Ҫ����˵��
		delay();
		SCL_OFF; 
		delay();
		SCL_ON;  
		delay();		   
		dat <<= 1;	  
		if (SDA == 1) dat += 1; 
		delay();
	}
	SCL_OFF;
	delay();

	return(dat); 
}
/*
 * Name					: read_nbyte
 * Description			: ---
 * Author				: XiaomaGee.
 *
 *      History
 * -------------------
 * Rev					: 0.00
 * Date					: 04/10/2012
 *
 * create.
 * -------------------
 */
int
read_nbyte(unsigned char sla, unsigned char suba, unsigned char *s, unsigned char no) //��n���ֽ��ӳ���
{
	unsigned char i;

	start(); 
	write(sla);  //д�ӻ���ַ��slaĩβΪ��0����˵������"д"
	if (ack_flag == 0) return(0);
	write(suba);  // д��ָ���ֽڡ�
	if (ack_flag == 0) return(0);
	start();
	write(sla + 1);	//д�ӻ���ַ����1��slaĩβΪ��1����˵�����ԡ�����
	if (ack_flag == 0) return(0); //ack_flag
	for (i = 0; i < no - 1; i++) {//������no-2��
		*s = read();  
		ack(1);//Ӧ��
		s++;  
	}
	*s = read();//����n-1����
	ack(0);	 //	Ӧ��0�����ͷ�����
	stop();

	return 0;	   
}
