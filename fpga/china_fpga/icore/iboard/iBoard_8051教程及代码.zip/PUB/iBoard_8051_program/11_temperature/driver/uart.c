/*
 * File				: uart.c
 * Description		: This file is iBoard.8051 uart driver demo.
 * Author		    : XiaomaGee@Gmail.com.
 * Copyright		:
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */

//-----------------Include files-------------------------//
#include "..\include\hardware.h"
#include "..\include\uart.h"

//-----------------Define--------------------------------//
#define CRYSTAL         11059200.0

//-----------------Function Prototype--------------------//
void initialize_uart(long int BAUDRATE);
void send_string(char * /* ss */);

//-----------------Variable------------------------------//

unsigned char idata receive_buffer[20];
unsigned char receive_ok = 0;

//-----------------Function------------------------------//
/*
 * Name				: uart_interrupt
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void uart_interrupt(void) interrupt 4
{
	static unsigned char idata count = 0;

	RI = 0;
	receive_buffer[count++] = SBUF;

	if (receive_buffer[count - 1] == '\n') {
		receive_ok = 1;
		receive_buffer[count] = '\0';
		count = 0;
	}
}

/*
 * Name				: initialize_uart
 * Description	    : baudrate range 1200 ~ 57600
 * Author		    : XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void initialize_uart(long int BAUDRATE)
{
	float temp;
	unsigned char bps;

	TMOD |= 0X20;
	PCON |= 0x80;
	SCON = 0X50;

	temp = CRYSTAL;
	temp /= BAUDRATE;
	temp /= 32.;

	temp /= 12.;

	temp *= 2.;

	temp = 256. - temp;
	bps = (unsigned char)temp;

	TH1 = bps;
	TL1 = bps;

	TR1 = 1;
	ES = 1;
	EA = 1;
	PS = 1; //uart ���ȼ����
}

/*
 * Name				: send_string
 * Description	    : ---
 * Author           : XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void send_string(char *ss)
{
	unsigned char i = 0;

	ES = 0;
	while (ss[i] != '\0') {
		SBUF = ss[i];
		while (!TI) ;
		TI = 0;
		i++;
	}
	ES = 1;
}
