/*------------------------------------------------------
   FILE NAME   : adc.c
   DESCRIPTION : adc driver
   VERSION     : 0.0.0 (C)XiaomaGee
   AUTHOR      : XiaomaGee
   CREATE DATE : 2010-9-10
   MODIFY DATE :
   LOGS        :-\
   --------------------------------------------------------*/


//-----------------Include files-------------------------//


#include "..\include\i2c.h"
#include "..\include\lm75.h"


//-----------------Function------------------------------//
/*
 * Name					: lm75_read
 * Description			: ---
 * Author				: XiaomaGee.
 *
 *      History
 * -------------------
 * Rev	: 0.00
 * Date	: 04/10/2012
 *
 * create.
 * -------------------
 */
float
lm75_read(void)
{
	short int dat;
	float f;

	read_nbyte(LM75, 0, (unsigned char*)(&dat), 2);	//��ȡLM75A�ϵ��¶�

	f = dat;
	f /= 32.0;	//��ȥ����λ
	f *= 0.125;	 //ת��Ϊʵ�ʵ��¶�

	return f;
}
