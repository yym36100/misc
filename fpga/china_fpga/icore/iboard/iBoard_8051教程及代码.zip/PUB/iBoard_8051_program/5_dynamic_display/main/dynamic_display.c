 /*
 * File				: dynamic_display.c
 * Description		: This file is iBoard.8051 dynamic_display driver.
 * Author			: XiaomaGee@Gmail.com.
 * Copyright		:  
 * 
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */

//-----------------Include files-------------------------//
#include "..\include\hardware.h"
#include <intrins.h>

//-----------------Define--------------------------------//

//-----------------Function Prototype--------------------//
void initialize(void);
void delay(void);

//-----------------Variable------------------------------//
unsigned char code nix_tab[] = {
	0xc0, 0xf9, 0xa4, 0xb0,
	0x99, 0x92, 0x82, 0xf8,
	0x80, 0x90, 0x88, 0x83,
	0xc6, 0xa1, 0x86, 0x8e, //�������0~F�Ķ���
	0xff, 0xbf              // �ո�� �� 
};

//-----------------Function------------------------------//
/*
 * Name				: main
 * Description		: ---
 * Author		    : XiaomaGee.
 * 
 * 	History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */
 int main(void)
  {
     char j = 0;
  
     initialize();
   
      while (1) {

         NIX_SEL0 = 1;		//ѡͨ����ܵ�1λ
         NIX_SEL1 = 1;		
         NIX_SEL2 = 1;		
         NIX_SEL3 = 0;
         P0 = nix_tab[1];   
         delay();

         NIX_SEL0 = 1;		//ѡͨ����ܵ�2λ
         NIX_SEL1 = 1;		
         NIX_SEL2 = 0;		
         NIX_SEL3 = 1;
         P0 = nix_tab[2];
         delay();

         NIX_SEL0 = 1;		 //ѡͨ����ܵ�3λ
         NIX_SEL1 = 0;		
         NIX_SEL2 = 1;		
         NIX_SEL3 = 1;
         P0 = nix_tab[3];
         delay();

         NIX_SEL0 = 0;		 //ѡͨ����ܵ�4λ
         NIX_SEL1 = 1;		
         NIX_SEL2 = 1;		
         NIX_SEL3 = 1;
         P0 = nix_tab[4];
         delay();
    }
 }

 /*
 * Name				: delay
 * Description		: ---
 * Author			: XiaomaGee.
 * 
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */
 void delay(void)           //��ʱ 
 {
     unsigned char i,j;
	 
     for (i=0; i<200; i++){
		 for(j = 0; j<20;j++);
	 }
 }

/*
 * Name				: initialize
 * Description		: ---
 * Author			: XiaomaGee.
 * 
 * 	History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */
 void initialize(void)
 {
		P0 = 0XFF;		   //��ʼ��P0�˿ڣ�ȫ����1
		P1 = 0XFF;		   //��ʼ��P1�˿ڣ�ȫ����1
		P2 = 0XFF;		   //��ʼ��P2�˿ڣ�ȫ����1
		P3 = 0XFF;		   //��ʼ��P3�˿ڣ�ȫ����1
}
