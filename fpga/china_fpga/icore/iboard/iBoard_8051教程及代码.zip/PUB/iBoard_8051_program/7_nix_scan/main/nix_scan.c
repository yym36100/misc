/*
 * File				: nix_scan.c
 * Description		: This file is iBoard.8051 nix_scan driver.
 * Author			: XiaomaGee@Gmail.com.
 * Copyright		:
 *
 * History
 * -------------------
 * Rev	: 0.00
 * Date	: 04/10/2012
 *
 * create.
 * -------------------
 */

//-----------------Include files-------------------------//
#include "..\include\hardware.h"
#include <stdlib.h>
#include <stdio.h>

//-----------------Define--------------------------------//

//-----------------Function Prototype--------------------//
void initialize(void);
void initialize_timer0(void);
void nix_display_int(int);

//-----------------Variable------------------------------//
unsigned char idata nix_value[4];

unsigned char code nix_tab[] = {
	0xc0, 0xf9, 0xa4, 0xb0,
	0x99, 0x92, 0x82, 0xf8,
	0x80, 0x90, 0x88, 0x83,
	0xc6, 0xa1, 0x86, 0x8e, //�����0~F�Ķ���
	0xff, 0xbf              //��ʾ�ո��-,
};

//-----------------Function------------------------------//
/*
 * Name				: timer0_interrup
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 *      History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void timer0_interrupt(void) interrupt 1
{
	static unsigned char i = 0;

	TH0 = 0xf8; //��ʱ2ms�ĳ�ʼֵ����
	TL0 = 0xcd;

	NIX_SEL0 = 1;
	NIX_SEL1 = 1;
	NIX_SEL2 = 1;
	NIX_SEL3 = 1;

	P0 = nix_value[i] > 99 ? nix_tab[nix_value[i] - 100] & 0x7f : nix_tab[nix_value[i]];

	if (i == 0) NIX_SEL3 = 0;	//�����һλ�����֣���ѡͨ����ܵĵ�һλ
	else NIX_SEL3 = 1;

	if (i == 1) NIX_SEL2 = 0;
	else NIX_SEL2 = 1;

	if (i == 2) NIX_SEL1 = 0;
	else NIX_SEL1 = 1;

	if (i == 3) NIX_SEL0 = 0;
	else NIX_SEL0 = 1;

	i++;

	if (i > 3) i = 0;
}

/*
 * Name					: main
 * Description	: ---
 * Author				: XiaomaGee.
 *
 *      History
 * -------------------
 * Rev					: 0.00
 * Date					: 04/10/2012
 *
 * create.
 * -------------------
 */
void main(void)
{
	int number = 0;
	long int i;

	initialize();

	while (1) {
		for (i = 0; i < 2000; i++);	  //��ʱ
		
		nix_display_int(number ++);	  //����ܵ����ּ�1
		if (number > 9999) number = 0;
	}
}

/*
 * Name				: initialize
 * Description	    : ---
 * Author		    : XiaomaGee.
 *
 *      History
 * -------------------
 * Rev	: 0.00
 * Date	: 04/10/2012
 *
 * create.
 * -------------------
 */
void initialize(void)
{
	P0 = 0XFF;
	P1 = 0XFF;
	P2 = 0XFF;
	P3 = 0XFF;

	initialize_timer0(); //��ʱ��T0��ʼ��
}

/*
 * Name				: initialize_timer0
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void initialize_timer0(void)
{
	TMOD |= 0X01;
	TH0 = 0xf8;   //��ʱ2ms�ĳ�ʼֵ����
	TL0 = 0xcd;
	TR0 = 1;     //������ʱ��T0
	ET0 = 1;     //ʹ�ܶ�ʱ��T0�ж�

	EA = 1;      //��ȫ���ж�
}

/*
 * Name					: nix_display_int
 * Description	        : ---
 * Author				: XiaomaGee.
 *
 * History
 * -------------------
 * Rev               	: 0.00
 * Date	                : 04/10/2012
 *
 * create.
 * -------------------
 */
 void nix_display_int(int number)
 {
	char buffer[10];
	char i;
	
 	sprintf(buffer, "%4d", number);				 //������ת��Ϊ4Ϊ�ַ�����
	
	for (i = 0; i < 4; i++)
		if (buffer[i] == ' ') nix_value[i] = 16; //��������ʾ�ո�
			else nix_value[i] = buffer[i] - '0'; //���ַ�ת��Ϊ����
 }
