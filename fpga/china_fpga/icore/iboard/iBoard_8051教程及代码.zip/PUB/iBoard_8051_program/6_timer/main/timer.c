/*
 * File				: timer.c
 * Description		: This file is iBoard.8051 led driver.
 * Author			: XiaomaGee@Gmail.com.
 * Copyright		:  
 * 
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */

//-----------------Include files-------------------------//
#include "..\include\hardware.h"

//-----------------Define--------------------------------//

//-----------------Function Prototype--------------------//
void initialize(void);
void initialize_timer0(void);
//-----------------Variable------------------------------//

//-----------------Function------------------------------//
/*
 * Name				: main
 * Description		: ---
 * Author		    : XiaomaGee.
 * 
 * 	History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */
int main(void)
{
	initialize();

	while(1);
}

/*
 * Name				: initialize
 * Description		: ---
 * Author		    : XiaomaGee.
 * 
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 * 
 * create.
 * -------------------
 */
 void initialize(void)
 {
		P0 = 0XFF;
		P1 = 0XFF;
		P2 = 0XFF;
		P3 = 0XFF;

	  initialize_timer0();	 //��ʱ��T0��ʼ��
}

/*
 * Name				: initialize_timer0
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void initialize_timer0(void)
{
	TMOD |= 0X01;
	TH0 = (65536-46083)/256; 
	TL0 = (65536-46083)%256;  //��ʱ50ms
	TR0 = 1;                  //������ʱ��T0
	ET0 = 1;                  //ʹ�ܶ�ʱ��T0�ж�

	EA = 1;                   //��ȫ���ж�
}

 /*
 * Name				: timer0_interrup
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void timer0_interrupt(void) interrupt 1
{
	TF0=0;
	LED = !LED;
	TH0 = (65536-46083)/256; 
	TL0 = (65536-46083)%256;
}
