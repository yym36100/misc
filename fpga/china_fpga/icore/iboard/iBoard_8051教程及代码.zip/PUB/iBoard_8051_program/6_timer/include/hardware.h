/*
 * File				: hardware.h
 * Description		: This file is iBoard.8051 hardware define.
 * Author			: XiaomaGee@Gmail.com.
 * Copyright		:  
 * 
 * History
 * -------------------
 * Rev	            : 0.00
 * Date            	: 04/10/2012
 * 
 * create.
 * -------------------
 */

#ifndef __hardware_h__
#define	__hardware_h__

//-----------------Include files-------------------------//
#include <reg52.h>

//-----------------define--------------------------------//

sbit RTC_RST = P2 ^ 6;                                   
sbit RTC_DIO = P2 ^ 4;                                    
sbit RTC_SCLK = P2 ^ 3;

sbit LED = P3 ^ 5;

sbit NIX_SEL0 = P1 ^ 1;
sbit NIX_SEL1 = P1 ^ 2;
sbit NIX_SEL2 = P1 ^ 3;
sbit NIX_SEL3 = P1 ^ 4;

sbit BEEP = P3 ^ 4;

sbit DS1302_SCLK = P1 ^ 5;
sbit DS1302_IO = P3 ^ 6;
sbit DS1302_RST = P3 ^ 7;

sbit SDA = P3 ^ 2;
sbit SCL = P3 ^ 3;

sbit KEYOUT0 = P2 ^ 4;
sbit KEYOUT1 = P2 ^ 5;
sbit KEYOUT2 = P2 ^ 6;
sbit KEYOUT3 = P2 ^ 7;

sbit KEYDOWN = P2 ^ 3;
sbit KEYUP = P1 ^ 0;

#endif /* __hardware_h__ */
