/*
 * File				: key.c
 * Description		: This file is iBoard.8051 key driver demo.
 * Author			: XiaomaGee@Gmail.com.
 * Copyright		:
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */

//-----------------Include files-------------------------//
#include "..\include\hardware.h"
#include <stdlib.h>
#include <stdio.h>

//-----------------Define--------------------------------//

//-----------------Function Prototype--------------------//
void initialize(void);
void initialize_timer0(void);
void nix_display_int(int /* number */);
unsigned char read_key(void);

//-----------------Variable------------------------------//
unsigned char idata nix_value[4];
unsigned char event = 0;

unsigned char code nix_tab[] = {
	0xc0, 0xf9, 0xa4, 0xb0,
	0x99, 0x92, 0x82, 0xf8,
	0x80, 0x90, 0x88, 0x83,
	0xc6, 0xa1, 0x86, 0x8e, //0~f
	0xff, 0xbf              //�ո�,-,
};

//-----------------Function------------------------------//
/*
 * Name				: timer0_interrupt
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void timer0_interrupt(void) interrupt 1
{
	static unsigned char i = 0;
	static unsigned char key_code_bak = 0;
	unsigned char key_code;
	static int counter = 0;

	TH0 = 0xf8;         //2ms
	TL0 = 0xcd;

	NIX_SEL0 = 1;
	NIX_SEL1 = 1;
	NIX_SEL2 = 1;
	NIX_SEL3 = 1;

	P0 = nix_value[i] > 99 ? nix_tab[nix_value[i] - 100] & 0x7f : nix_tab[nix_value[i]];

	if (i == 0) NIX_SEL3 = 0;
	else NIX_SEL3 = 1;

	if (i == 1) NIX_SEL2 = 0;
	else NIX_SEL2 = 1;

	if (i == 2) NIX_SEL1 = 0;
	else NIX_SEL1 = 1;

	if (i == 3) NIX_SEL0 = 0;
	else NIX_SEL0 = 1;

	i++;

	if (i > 3) i = 0;

	counter++;

	if (counter >= 50) {          //ÿ��100ms ���а���ɨ��
		counter = 0;
		key_code = read_key();	  //��ȡ����ֵ

		if (key_code == key_code_bak || key_code == 0) { // key_code_bakΪ����ֵ�ı���
			goto end;
		}
		event = key_code;
 end: key_code_bak = key_code;
	}
}

/*
 * Name				: main
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void main(void)
{
	initialize();
	nix_display_int(0);

	while (1) {
		if (event) {  //����а������£����������ʾ��������ֵ
			nix_display_int(event);
			event = 0;
		}
	}
}

/*
 * Name				: initialize
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void initialize(void)
{
	P0 = 0XFF;
	P1 = 0XFF;
	P2 = 0XFF;
	P3 = 0XFF;

	initialize_timer0();
}

/*
 * Name				: initialize_timer0
 * Description	    : ---
 * Author		    : XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void initialize_timer0(void)
{
	TMOD |= 0X01;
	TH0 = 0xf8;    //��ʱ����ʱ2ms�ĸ���ֵ�ķ���
	TL0 = 0xcd;
	TR0 = 1;       //������ʱ��T0
	ET0 = 1;       //�򿪶�ʱ��T0�ж�

	EA = 1;        //��ȫ���ж�
}

/*
 * Name				: nix_display_int
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void nix_display_int(int number)
{
	char buffer[10];
	char i;

	sprintf(buffer, "%4d", number);

	for (i = 0; i < 4; i++)
		if (buffer[i] == ' ') nix_value[i] = 16;	//���Ϊ�գ���ʲôҲ����ʾ
		else nix_value[i] = buffer[i] - '0';		//����Ӧ���ַ�ת��Ϊ����
}

/*
 * Name				: read_key
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
unsigned char read_key(void)
{
	unsigned char i;
	unsigned char code weight[4] = { 0x7f, 0xbf, 0xdf, 0xef };//����P2�ڳ�ʼ��״̬

	if (KEYDOWN == 0) return KEY_DOWN;
	if (KEYUP == 0) return KEY_UP;

	for (i = 0; i < 4; i++) {
		P2 = weight[i];		
		if ((P2 & 0x0f) != 0x0f) return P2;	                  //����а������£��򷵻ض�ȡ��P2�ڵĵ�ƽ
	}
	
	return 0;
}
