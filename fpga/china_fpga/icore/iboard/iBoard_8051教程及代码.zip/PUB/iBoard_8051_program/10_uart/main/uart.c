/*
 * File				: uart.c
 * Description		: This file is iBoard.8051 uart driver demo.
 * Author			: XiaomaGee@Gmail.com.
 * Copyright		:
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */

//-----------------Include files-------------------------//
#include "..\include\hardware.h"
#include <stdlib.h>
#include <stdio.h>

//-----------------Define--------------------------------//
#define CRYSTAL         11059200.0

//-----------------Function Prototype--------------------//
void initialize(void);
void initialize_timer0(void);
void initialize_uart(long int baudrate);
void nix_display_int(int /* number */);
void send_string(char * /* ss */);

//-----------------Variable------------------------------//
unsigned char idata nix_value[4] = { 17, 17, 17, 17 };
unsigned char idata receive_buffer[20];
unsigned char receive_ok = 0;

unsigned char code nix_tab[] = {
	0xc0, 0xf9, 0xa4, 0xb0,
	0x99, 0x92, 0x82, 0xf8,
	0x80, 0x90, 0x88, 0x83,
	0xc6, 0xa1, 0x86, 0x8e, //0~f
	0xff, 0xbf              //�ո�,-,
};

//-----------------Function------------------------------//
/*
 * Name				: timer0_interrupt
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void timer0_interrupt(void) interrupt 1
{
	static unsigned char i = 0;

	TH0 = 0xf8;     //��ʱ2ms
	TL0 = 0xcd;

	NIX_SEL0 = 1;
	NIX_SEL1 = 1;
	NIX_SEL2 = 1;
	NIX_SEL3 = 1;

	P0 = nix_value[i] > 99 ? nix_tab[nix_value[i] - 100] & 0x7f : nix_tab[nix_value[i]];

	if (i == 0) NIX_SEL3 = 0;
	else NIX_SEL3 = 1;

	if (i == 1) NIX_SEL2 = 0;
	else NIX_SEL2 = 1;

	if (i == 2) NIX_SEL1 = 0;
	else NIX_SEL1 = 1;

	if (i == 3) NIX_SEL0 = 0;
	else NIX_SEL0 = 1;

	i++;

	if (i > 3) i = 0;
}

/*
 * Name				: uart_interrupt
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void uart_interrupt(void) interrupt 4
{
	static unsigned char idata count = 0;

	RI = 0;	
	receive_buffer[count++] = SBUF;

	if (receive_buffer[count - 1] == '\n') {
		receive_ok = 1;
		receive_buffer[count] = '\0';
		count = 0;
	}
}

/*
 * Name				: main
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev				: 0.00
 * Date				: 04/10/2012
 *
 * create.
 * -------------------
 */
void main(void)
{
	long int i;
 
	initialize();

	while (1) {
	
	if (i++ > 50000) {
			send_string("Hello iBoard!");
			i = 0;
		}
	
		if (receive_ok) {	
			receive_ok = 0;
		    nix_display_int(atoi(receive_buffer));
	     }
	}
}

/*
 * Name				: initialize
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void initialize(void)
{
	P0 = 0XFF;
	P1 = 0XFF;
	P2 = 0XFF;
	P3 = 0XFF;

	initialize_timer0();
	initialize_uart(1200);
}

/*
 * Name				: initialize_timer0
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void initialize_timer0(void)
{
	TMOD |= 0X01;
	TH0 = 0xf8; 	    //��ʱ2ms��ʼֵ����
	TL0 = 0xcd;
	TR0 = 1; 			//������ʱ��T0
	ET0 = 1; 			//������ʱ��T0�ж�

	EA = 1; 			//��ȫ���ж�
}

/*
 * Name				: initialize_uart
 * Description	    : baudrate range 1200 ~ 57600
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void initialize_uart(long int baudrate)
{
	float temp;
	unsigned char bps;

	TMOD |= 0X20;  //T1������ʽ2
	PCON |= 0x80;  //SMOD=1,�����ʼӱ�
	SCON = 0X50;   //SM0SM1=1,���ڹ�����ʽ1��REN=1���������ڽ�������

	temp = CRYSTAL;
	temp /= baudrate;
	temp /= 32.;

	temp /= 12.;

	temp *= 2.;

	temp = 256. - temp;
	bps = (unsigned char)temp;

	TH1 = bps;
	TL1 = bps;

	TR1 = 1;   //����T1
	ES = 1;	   //���������ж�
	EA = 1;	   //�������ж�
	PS = 1;    //����Ϊ������ȼ��ж�
}

/*
 * Name				: nix_display_int
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void nix_display_int(int number)
{
	char buffer[10];
	char i;

	if (number > 9999 || number < 0) { 
		nix_value[0] = 16;
		nix_value[1] = 16;
		nix_value[2] = 16;
		nix_value[3] = 0x0e;
		return;
	}

	sprintf(buffer, "%4d", number);

	for (i = 0; i < 4; i++)
		if (buffer[i] == ' ') nix_value[i] = 16;
		else nix_value[i] = buffer[i] - '0';
}

/*
 * Name				: send_string
 * Description	    : ---
 * Author			: XiaomaGee.
 *
 * History
 * -------------------
 * Rev	            : 0.00
 * Date	            : 04/10/2012
 *
 * create.
 * -------------------
 */
void send_string(char *ss)
{
	unsigned char i = 0;
			     
	ES = 0;	             //��ֹ�����ж�
	while (ss[i] != '\0') {
		SBUF = ss[i];
		while (!TI) ;
		TI = 0;	         //CPU��Ӧ�жϣ���������0
		i++;
	}
	ES = 1;	             //���������ж�
}
