//nvic.c

#include "..\include\stm32f10x_reg.h"
#include "..\include\nvic.h"

static int initialize(void);

SYSNVIC_T nvic={
	.initialize=initialize,
};
static int initialize(void)
{
	/* Set the Vector Table base location at 0x08000000 */
	SCB->VTOR.W = ((unsigned long)0x08000000);

	//uart0	
  //  NVIC->IPR10.W=0x00000000;
 //   NVIC->ISER2.W=0x00000020;


	return 0;  
}

