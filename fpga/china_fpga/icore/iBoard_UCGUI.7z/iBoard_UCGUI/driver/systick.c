#include "..\include\stm32f10x_reg.h"
#include "..\include\config.h"
#include "..\include\systick.h"	





static int initialize(void);


SYS_TICK_T systick={
	.initialize=initialize,
	.counter=0	
};


static int initialize(void)
{	
		SYSTICK->LOAD.B.RELOAD=72000*10;	   //5ms
		SYSTICK->CTRL.B.ENABLE=1;
		SYSTICK->CTRL.B.TICKINT=1;
		SYSTICK->CTRL.B.CLKSOURCE=1;

	return 0;
}

int SysTick_Handler(void)
{
	systick.counter+=10;

	return 0;
}
