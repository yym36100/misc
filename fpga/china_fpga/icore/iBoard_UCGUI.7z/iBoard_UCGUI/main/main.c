/*
  ��iBoard ����ѧ�á� ucgui ��ֲ����
  ���ͣ�XiaomaGee.cnblogs.com
  ��̳��www.oshcn.com
  ���̣�i-Board.taobao.com
  QQȺ��204255896	165201798	215053598	215054675	215055211

  */

#include "..\include\stm32f10x_reg.h"
#include "..\include\nvic.h"
#include "..\include\rcc.h"
#include "..\include\systick.h"
#include "..\include\mco.h"
#include "..\include\fsmc.h"
#include "..\include\evtft.h"
#include "..\include\pwm.h"
#include "..\usb_include\usb.h"
#include "..\usb_include\usb_command.h"


#include "gui.h"
#include "..\guidemo\guidemo.h"
#include "wm.h"
#include "FRAMEWIN.h"
#include "LISTBOX.h"
#include "button.h"
#include <string.h>


//void calc(void)
//{
//	int id;
//	int x, y;
//	int bx, by;
//
//	int x0 = 0, y0 = 20, yStep = 15, i;
//
//	WM_HWIN Win1;
//	WM_HWIN B_1, B_2, B_3, B_4, B_5, B_6, B_7, B_8, B_9, B_0, B_DOT, B_ENT, B_CLR;
//	WM_HWIN Edit1;
//
//
//	bx = 80;
//	by = 45;
//
//	x = 10;
//	y = 45;
//
//	Win1 = WM_CreateWindow(0, 0, 470, 262, WM_CF_SHOW, NULL, 0);
//	WM_SelectWindow(Win1);
//
//	GUI_SetColor(GUI_WHITE);
//	GUI_SetBkColor(GUI_BLACK);
//	GUI_SetFont(&GUI_Font32_ASCII);
//	GUI_Clear();
//
//
//	B_1 = BUTTON_Create(x, y, bx, by, 1, WM_CF_SHOW);
//	B_2 = BUTTON_Create(x + 75, y, bx, by, 2, WM_CF_SHOW);
//	B_3 = BUTTON_Create(x + 150, y, bx, by, 3, WM_CF_SHOW);
//
//	B_4 = BUTTON_Create(x, y + 40, bx, by, 4, WM_CF_SHOW);
//	B_5 = BUTTON_Create(x + 75, y + 40, bx, by, 5, WM_CF_SHOW);
//	B_6 = BUTTON_Create(x + 150, y + 40, bx, by, 6, WM_CF_SHOW);
//
//	B_7 = BUTTON_Create(x, y + 80, bx, by, 7, WM_CF_SHOW);
//	B_8 = BUTTON_Create(x + 75, y + 80, bx, by, 8, WM_CF_SHOW);
//	B_9 = BUTTON_Create(x + 150, y + 80, bx, by, 9, WM_CF_SHOW);
//
//	B_DOT = BUTTON_Create(x, y + 120, bx, by, 11, WM_CF_SHOW);
//	B_0 = BUTTON_Create(x + 75, y + 120, bx, by, 10, WM_CF_SHOW);
//	B_CLR = BUTTON_Create(x + 150, y + 120, bx, by, 12, WM_CF_SHOW);
//
//	B_ENT = BUTTON_Create(x, y + 160, 230, 40, 13, WM_CF_SHOW);
//
//	BUTTON_SetFont(B_1, &GUI_Font24B_ASCII);
//	BUTTON_SetFont(B_2, &GUI_Font24B_ASCII);
//	BUTTON_SetFont(B_3, &GUI_Font24B_ASCII);
//	BUTTON_SetFont(B_4, &GUI_Font24B_ASCII);
//	BUTTON_SetFont(B_5, &GUI_Font24B_ASCII);
//	BUTTON_SetFont(B_6, &GUI_Font24B_ASCII);
//	BUTTON_SetFont(B_7, &GUI_Font24B_ASCII);
//	BUTTON_SetFont(B_8, &GUI_Font24B_ASCII);
//	BUTTON_SetFont(B_9, &GUI_Font24B_ASCII);
//	BUTTON_SetFont(B_0, &GUI_Font24B_ASCII);
//	BUTTON_SetFont(B_CLR, &GUI_Font16B_ASCII);
//	BUTTON_SetFont(B_DOT, &GUI_Font24B_ASCII);
//	BUTTON_SetFont(B_ENT, &GUI_Font24B_ASCII);
//	BUTTON_SetText(B_1, "1");
//	BUTTON_SetText(B_2, "2");
//	BUTTON_SetText(B_3, "3");
//	BUTTON_SetText(B_4, "4");
//	BUTTON_SetText(B_5, "5");
//	BUTTON_SetText(B_6, "6");
//	BUTTON_SetText(B_7, "7");
//	BUTTON_SetText(B_8, "8");
//	BUTTON_SetText(B_9, "9");
//	BUTTON_SetText(B_0, "0");
//	BUTTON_SetText(B_DOT, ".");
//	BUTTON_SetText(B_CLR, "-");
//	BUTTON_SetTextColor(B_ENT, 0, GUI_RED);
//	BUTTON_SetText(B_ENT, "Enter");
//
//
//
//	Edit1 = EDIT_CreateAsChild(x, y - 40, 230, 35, Win1, GUI_ID_OK, WM_CF_SHOW, 12);
//	EDIT_SetText(Edit1, "-1.23456");
//	EDIT_SetFont(Edit1, &GUI_Font32B_ASCII);
//	EDIT_SetTextAlign(Edit1, GUI_TA_RIGHT);
//
//
//	WM_Paint(Edit1);
//
//	BUTTON_SetState(B_4, BUTTON_STATE_PRESSED);
//}

int main(void)
{
	int i;

	rcc.initialize();
	nvic.initialize();
	systick.initialize();
	fsmc.initialize();
	usb.initialize();

	for (i = 0; i < 5000000; i++) ;

	lcd.initialize();
	pwm.initialize(100);

	GUI_Init();


//calc();

	FRAMEWIN_Create("// iBoard //", NULL, WM_CF_SHOW, 400, 150, 70, 40);

	GUI_Exec();

  
	while (1) {
		GUIDEMO_main();
	}
}
