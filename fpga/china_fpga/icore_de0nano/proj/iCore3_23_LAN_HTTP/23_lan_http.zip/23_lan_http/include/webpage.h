#ifndef __WEBPAGE_H
#define __WEBPAGE_H
#define ALLOCATION_HTML  "<!DOCTYPE HTML>"\
"<html>"\
"<head>"\
"<title>iCore3</title>"\
"<style type='text/css'>"\
"body{font-family:arial}"\
"</style>"\
"<script type = 'text/javascript'>"\
"function data()"\
"{"\
"var xmlhttp;"\
"if(window.XMLHttpRequest)"\
"{"\
"xmlhttp=new XMLHttpRequest();"\
"}"\
"else"\
"{"\
"xmlhttp=new ActiveXObject(\"Microsoft.XMLHTTP\");"\
"}"\
"xmlhttp.onreadystatechange=function()"\
"{"\
"if (xmlhttp.readyState==4 && xmlhttp.status==200)"\
"{"\
"document.getElementById(\"myDiv\").innerHTML=xmlhttp.responseText;"\
"}"\
"};"\
"xmlhttp.open(\"GET\",\"/demo_get.asp\",true);"\
"xmlhttp.send();"\
"}"\
"</script>"\
"<script type = 'text/javascript'>"\
"function func()"\
"{"\
"data();"\
"setTimeout('func()',500);"\
"}"\
"setTimeout('func()',500);"\
"</script>"\
"</head>"\
"<body onload = 'func()'>"\
"<div style = 'background:#00007f;color:#afafaf;padding:2px 10px;' id = 'header'>"\
"<p><font size ='8' style='font-weight:bold'>iCore3</font></p>"\
"</div>"\
"<h2>ADC POWER MONITOR</h2>"\
"<div style = 'padding:5px 10px;' id='myDiv'></div>"\
"<div style = 'background:#00007f;color:#afafaf;padding:2px 10px;' id = 'footer'>"\
"<h4>E-mail: ChinaGingko@163.com</h4>"\
"<h4>TEL: 0379-63002125   15516367209</h4>"\
"<h4>Sales Link: <a href = 'http://icore.taobao.com' target = '_blank' >htttp://icore.taobao.com</a></h4>"\
"<h4 style = 'font-style:italic'>Made & Designed in CHINA. GINGKO Technology Co.,Ltd.</h4>"\
"</div>"\
"</body>"\
"</html>"\

#endif
