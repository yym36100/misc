#ifndef GUI_H_
#define GUI_H_

#include "alt_video_display.h"
#include "touch_spi.h"

void GUI(alt_video_display *pDisplay, TOUCH_HANDLE *pTouch);


#endif /*GUI_H_*/
