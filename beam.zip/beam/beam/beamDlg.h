// beamDlg.h : header file
//

#pragma once
#include "afxwin.h"



// CbeamDlg dialog
class CMyWnd : public CWnd
{
public:
	CRect r;
	int state;
	int step;
	int fgc,bgc;
	int offset;
	CMyWnd(){
		state = 1;
		step = 10;
		bgc = 0;
		fgc = 0xffffff;
		offset = 0;
	}

	afx_msg void OnPaint( ){



		this->GetClientRect(r);
		switch(state)
		{
		case 0: 
			{
				CPaintDC dc(this);
				FillRect(dc,r,CBrush(HS_DIAGCROSS ,rand()));
				TextOut(dc,0,0,"alma",4);
				CPen pen = CPen(1,1,0xffffff);
				dc.SelectObject(pen);
				dc.MoveTo(0,100);
				LineTo(dc,100,100);
			}
			break;
		case 1: DrawHLines();break;
		case 2: DrawVLines();break;
	    case 3: DrawChecker();break;
		case 4: DrawChecker2();break;
		case 5: DrawGrid();break;
		case 6: DrawGradient1();break;
		case 7: DrawGradientr();break;
		case 8: DrawGradientg();break;
		case 9: DrawGradientb();break;
		}
	}
protected:
	void DrawGradient1(){
		CPaintDC dc(this);
		FillRect(dc,r,CBrush(bgc));
		CPen pen = CPen(1,1,0xffffff);
		dc.SelectObject(pen);
		pen.DeleteObject();
		int c;
		for(int i=0+offset;i<r.bottom;i+=1){
			c = (int)(i * 255.0/(float)r.bottom);
			pen.CreatePen(0,0,RGB(c,c,c));
			dc.SelectObject(pen);
			dc.MoveTo(0,i);
			dc.LineTo(r.right,i);
			pen.DeleteObject();
		}
	}
	void DrawGradientb(){
		CPaintDC dc(this);
		FillRect(dc,r,CBrush(bgc));
		CPen pen = CPen(1,1,0xffffff);
		dc.SelectObject(pen);
		pen.DeleteObject();
		int c;
		for(int i=0+offset;i<r.bottom;i+=1){
			c = (int)(i * 255.0/(float)r.bottom);
			pen.CreatePen(0,0,RGB(0,0,c));
			dc.SelectObject(pen);
			dc.MoveTo(0,i);
			dc.LineTo(r.right,i);
			pen.DeleteObject();
		}
	}
	void DrawGradientr(){
		CPaintDC dc(this);
		FillRect(dc,r,CBrush(bgc));
		CPen pen = CPen(1,1,0xffffff);
		dc.SelectObject(pen);
		pen.DeleteObject();
		int c;
		for(int i=0+offset;i<r.bottom;i+=1){
			c = (int)(i * 255.0/(float)r.bottom);
			pen.CreatePen(0,0,RGB(c,0,0));
			dc.SelectObject(pen);
			dc.MoveTo(0,i);
			dc.LineTo(r.right,i);
			pen.DeleteObject();
		}
	}
	void DrawGradientg(){
		CPaintDC dc(this);
		FillRect(dc,r,CBrush(bgc));
		CPen pen = CPen(1,1,0xffffff);
		dc.SelectObject(pen);
		pen.DeleteObject();
		int c;
		for(int i=0+offset;i<r.bottom;i+=1){
			c = (int)(i * 255.0/(float)r.bottom);
			pen.CreatePen(0,0,RGB(0,c,0));
			dc.SelectObject(pen);
			dc.MoveTo(0,i);
			dc.LineTo(r.right,i);
			pen.DeleteObject();
		}
	}
	void DrawHLines(){
		CPaintDC dc(this);
		FillRect(dc,r,CBrush(bgc));
		CPen pen = CPen(1,1,0xffffff);
		dc.SelectObject(pen);
		for(int i=0+offset;i<r.bottom;i+=step){
			dc.MoveTo(0,i);
			dc.LineTo(r.right,i);
		}
	}
	void DrawVLines(){
		CPaintDC dc(this);
		FillRect(dc,r,CBrush(bgc));
		CPen pen = CPen(1,1,0xffffff);
		dc.SelectObject(pen);
		for(int i=0+offset;i<r.right;i+=step){
			dc.MoveTo(i,0);
			dc.LineTo(i,r.bottom);
		}
	}
	void DrawChecker(){
		CPaintDC dc(this);
		FillRect(dc,r,CBrush(bgc));
		for(int y=0+offset;y<r.bottom;y+=step){
			for(int x=((y/step)&1)*step+offset;x<r.right;x+=step*2){
				FillRect(dc,CRect(x,y,x+step,y+step),CBrush(fgc));
			}
		}
	}
	void DrawChecker2(){
		CPaintDC dc(this);
		FillRect(dc,r,CBrush(bgc));
		for(int y=0+offset;y<r.bottom;y+=step){
			for(int x=((y/step)&1)*step+offset;x<r.right;x+=step*2){
				FillRect(dc,CRect(x,y,x+offset,y+offset),CBrush(fgc));
			}
		}
	}
	void DrawGrid(){
		CPaintDC dc(this);
		FillRect(dc,r,CBrush(bgc));
		CPen pen = CPen(1,1,0xffffff);
		dc.SelectObject(pen);
		for(int i=0+offset;i<r.bottom;i+=step){
			dc.MoveTo(0,i);
			dc.LineTo(r.right,i);
		}
		for(int i=0+offset;i<r.right;i+=step){
			dc.MoveTo(i,0);
			dc.LineTo(i,r.bottom);
		}
	}

	DECLARE_MESSAGE_MAP()
};

class CbeamDlg : public CDialog
{
	// Construction
public:
	CbeamDlg(CWnd* pParent = NULL);	// standard constructor

	// Dialog Data
	enum { IDD = IDD_BEAM_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


	// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	CListBox m_mylistbox;
	int nrmonitors;
	CRect myMonitors[6];
	CMyWnd *m_mywindow;
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButton6();
};
