// beamDlg.cpp : implementation file
//

#include "stdafx.h"
#include "beam.h"
#include "beamDlg.h"

#include <windows.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

	// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CbeamDlg dialog




CbeamDlg::CbeamDlg(CWnd* pParent /*=NULL*/)
: CDialog(CbeamDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	nrmonitors = 0;
	CMyWnd *m_mywindow = 0;
}

void CbeamDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_mylistbox);
}

BEGIN_MESSAGE_MAP(CbeamDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CbeamDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CbeamDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CbeamDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &CbeamDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, &CbeamDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON6, &CbeamDlg::OnBnClickedButton6)
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CMyWnd, CWnd)	
	ON_WM_PAINT()	
	//}}AFX_MSG_MAP	
END_MESSAGE_MAP()


// CbeamDlg message handlers

BOOL CbeamDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CbeamDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CbeamDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CbeamDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

BOOL CALLBACK myMonitorEnumProc(
								HMONITOR hMonitor,
								HDC      hdcMonitor,
								LPRECT   lprcMonitor,
								LPARAM   dwData
								)
{
	CbeamDlg *self;
	self = (CbeamDlg*)dwData;
	char buffer[100];
	self->myMonitors[self->nrmonitors] = CRect(*lprcMonitor);
	
	sprintf(buffer,"monitor %d found (%d,%d,%d,%d)",self->nrmonitors++,lprcMonitor->left,lprcMonitor->top,lprcMonitor->right,lprcMonitor->bottom );
	self->m_mylistbox.AddString(buffer);

	return true;
}

void CbeamDlg::OnBnClickedButton1()
{
	BOOL res;
	
	if(this->nrmonitors == 0)
	{
	m_mylistbox.AddString("Searching for monitors");
	res = EnumDisplayMonitors( NULL, NULL,myMonitorEnumProc,(LPARAM)this);
	m_mywindow = new CMyWnd();
	RECT r={10,10,100,100};
	/*virtual BOOL Create(LPCTSTR lpszClassName,
	LPCTSTR lpszWindowName, DWORD dwStyle,
	const RECT& rect,
	CWnd* pParentWnd, UINT nID,
	CCreateContext* pContext = NULL);*/
	//m_mywindow->Create("#32770","my window",WS_OVERLAPPEDWINDOW,r,this->GetParent(),1234);
	//m_mywindow->CreateEx(WS_EX_CLIENTEDGE,_T("STATIC"), _T("Hi"),WS_OVERLAPPEDWINDOW,r,this,1234);
	//m_mywindow->ShowWindow(1);

	//m_mywindow->CreateEx(0, _T("#32770"), _T("Hi"), WS_POPUP/*WS_OVERLAPPEDWINDOW*/, this->myMonitors[1].left, this->myMonitors[1].top, 430,430, m_hWnd, (HMENU)0);
	m_mywindow->CreateEx(0, _T("#32770"), _T("Hi"), WS_POPUP/*WS_OVERLAPPEDWINDOW*/, this->myMonitors[0].left, this->myMonitors[0].top,  200, 200, m_hWnd, (HMENU)0);
	m_mywindow->ShowWindow(1);
	m_mywindow->UpdateWindow();
	m_mylistbox.AddString("window created on monitor 1");
	}
	else{
		m_mylistbox.AddString("updating existing window");
		m_mywindow->InvalidateRect(0,0);
		//m_mywindow->UpdateWindow();
	}
}

void CbeamDlg::OnBnClickedButton2()
{
	//on plus
	if(m_mywindow){
		m_mywindow->step++;
		m_mywindow->InvalidateRect(0,0);
	}
}

void CbeamDlg::OnBnClickedButton3()
{
	//on minus
	if(m_mywindow){
		m_mywindow->step--;
		m_mywindow->InvalidateRect(0,0);
	}
}

void CbeamDlg::OnBnClickedButton4()
{
	// TODO: Add your control notification handler code here
	if(m_mywindow){
		m_mywindow->offset++;
		if(m_mywindow->offset>10)m_mywindow->offset = 0;
		m_mywindow->InvalidateRect(0,0);
	}
}

void CbeamDlg::OnBnClickedButton5()
{
	// state+
	if(m_mywindow){
		m_mywindow->state++;
		m_mywindow->InvalidateRect(0,0);
	}
}

void CbeamDlg::OnBnClickedButton6()
{
	// state-
	if(m_mywindow){
		m_mywindow->state--;
		m_mywindow->InvalidateRect(0,0);
	}
}
